import torch
from collections import OrderedDict

# ================= 你的路径 =================
# 输入：A800 上跑出来的预训练权重 (带 warmup 的那个)
source_path = "/root/autodl-tmp/model_best_warmup.pth"
# 输出：适配 4090 微调的权重
target_path = "/root/autodl-tmp/finetune_ready_final.pth"
# ===========================================

print(f"🔧 正在执行 A800 -> 4090 权重适配...")
print(f"📄 目标：严格遵循论文代码逻辑，剔除工程包装，保留核心参数。")

try:
    checkpoint = torch.load(source_path, map_location='cpu')

    # 兼容处理
    if 'state_dict' in checkpoint:
        raw_state_dict = checkpoint['state_dict']
    else:
        raw_state_dict = checkpoint

    new_state_dict = OrderedDict()

    print("-" * 50)
    for k, v in raw_state_dict.items():
        name = k

        # 1. 【去包装】移除 A800 多卡训练产生的 module. 前缀
        # 这不影响参数数值，只是还原参数原本的名字
        if name.startswith('module.'):
            name = name[7:]

        # 2. 【按论文逻辑剔除】
        # VLP 阶段有 MIM (predict_patch) 和上采样 (up/down)
        # VLCI 阶段 (vlci.py) 没有这些层，必须剔除，否则报错
        if 'predict_patch' in name or 'up.' in name or 'down.' in name:
            continue

        # 3. 【保留核心】
        # 保留 Encoder, Decoder, Embeddings 等核心 Transformer 参数
        new_state_dict[name] = v

    # 4. 【按代码逻辑封装】
    # FinetuneTrainer.py 要求权重文件里必须有 'state_dict' 这个 key
    final_checkpoint = {
        'state_dict': new_state_dict,
        'epoch': checkpoint.get('epoch', 0),
        'monitor_best': checkpoint.get('monitor_best', 0)
    }

    torch.save(final_checkpoint, target_path)
    print(f"✅ 适配完成！")
    print(f"💾 已保存到: {target_path}")
    print("-" * 50)
    print("👉 请立刻去修改 finetune.json 的 load_model_path 为这个新路径！")

except Exception as e:
    print(f"❌ 错误: {e}")