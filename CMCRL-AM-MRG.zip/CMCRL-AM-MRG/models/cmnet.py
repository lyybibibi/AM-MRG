import torch
import torch.nn as nn
import os
import numpy as np
import torch.nn.functional as F
from modules.modules4cmnet import DiseaseAwareTokenMining, CausalInterventionLayer


class CMNet(nn.Module):
    def __init__(self, args, tokenizer):
        super(CMNet, self).__init__()
        self.args = args
        self.tokenizer = tokenizer

        # ---------------------------------------------------------------
        # 1. 视觉提取器
        # ---------------------------------------------------------------
        from SwinCheX.models.build import build_model as build_swin
        from SwinCheX.config import get_config
        swin_config = get_config(args)
        self.visual_encoder = build_swin(swin_config)

        # Stage 2: 冻结视觉主干
        print(">>> [CMNet] Freezing Visual Encoder for Stage 2 (Eval Mode)...")
        for param in self.visual_encoder.parameters():
            param.requires_grad = False
        self.visual_encoder.eval()

        v_dim = getattr(self.visual_encoder, 'num_features', 768)
        d_model = getattr(args, 'd_model', 768)
        vocab_size = len(tokenizer.token2idx)

        # ---------------------------------------------------------------
        # 2. 缝合部分 (AM-MRG + Hopfield)
        # ---------------------------------------------------------------
        self.visual_mining = DiseaseAwareTokenMining(dim=v_dim, num_tokens=32)

        self.feat_norm = nn.LayerNorm(v_dim)
        self.query_conv = nn.Linear(v_dim, v_dim, bias=False)
        self.key_conv = nn.Linear(v_dim, v_dim, bias=False)
        self.val_conv = nn.Linear(v_dim, v_dim, bias=False)

        vis_mem_path = getattr(args, 'vis_mem_path', 'visual_memory_bank_iu.npy')
        if os.path.exists(vis_mem_path):
            print(f">>> [CMNet] Loading Confounder Z from: {vis_mem_path}")
            vmb_data = np.load(vis_mem_path)
            if np.isnan(vmb_data).any() or np.isinf(vmb_data).any():
                vmb_data = np.nan_to_num(vmb_data, nan=0.0, posinf=1.0, neginf=-1.0)
            self.register_buffer('visual_memory_bank', torch.from_numpy(vmb_data).float())
        else:
            print(">>> [CMNet] Warning: Memory Bank not found, using random.")
            self.register_buffer('visual_memory_bank', torch.randn(2048, v_dim))

        self.causal_intervention = CausalInterventionLayer(dim=v_dim)
        self.alpha = nn.Parameter(torch.tensor(0.1))

        # ---------------------------------------------------------------
        # 3. 解码器
        # ---------------------------------------------------------------
        self.vis_proj = nn.Linear(v_dim, d_model) if v_dim != d_model else nn.Identity()

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model, nhead=8, dim_feedforward=2048,
            dropout=0.1, batch_first=True, norm_first=True
        )
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=3)
        self.tgt_embed = nn.Embedding(vocab_size, d_model)
        self.fc_out = nn.Linear(d_model, vocab_size)

    def forward_visual_token_level(self, x):
        with torch.no_grad():
            ve = self.visual_encoder
            x = ve.patch_embed(x)
            if getattr(ve, 'ape', False): x = x + ve.absolute_pos_embed
            x = ve.pos_drop(x)
            for layer in ve.layers: x = layer(x)
            x = ve.norm(x)
            if torch.isnan(x).any(): x = torch.nan_to_num(x)
        return x

    def forward(self, images, targets=None, mode='train'):
        B, V = images.shape[0], images.shape[1]
        images = images.view(B * V, 3, 224, 224)
        v_tokens = self.forward_visual_token_level(images)
        v_tokens = v_tokens.contiguous().view(B, -1, v_tokens.size(-1))

        m_feat = self.visual_mining(v_tokens)

        if hasattr(self, 'visual_memory_bank'):
            M = self.feat_norm(m_feat)
            Z_raw = self.visual_memory_bank
            Z = F.normalize(Z_raw, p=2, dim=-1, eps=1e-6)

            q = self.query_conv(M)
            k = self.key_conv(Z)
            v_proj = self.val_conv(Z_raw)

            scale = q.size(-1) ** -0.5
            scores = torch.matmul(q, k.T) * scale
            scores = torch.clamp(scores, min=-10, max=10)
            attn = torch.softmax(scores, dim=-1)

            z_confounder = torch.matmul(attn, v_proj)
            m_deconfounded = self.causal_intervention(m_feat, z_confounder)
            m_feat = m_feat + self.alpha * m_deconfounded

        memory = self.vis_proj(m_feat)
        memory = torch.nan_to_num(memory)
        memory = F.layer_norm(memory, [memory.size(-1)])

        if mode == 'train' and targets is not None:
            tgt_mask = self.generate_square_subsequent_mask(targets.size(1)).to(targets.device)
            tgt_embedded = self.tgt_embed(targets)
            output = self.decoder(tgt_embedded, memory, tgt_mask=tgt_mask)
            logits = self.fc_out(output)
            if torch.isnan(logits).any(): logits = torch.nan_to_num(logits)
            return logits
        else:
            return self.beam_search(memory)

    def generate_square_subsequent_mask(self, sz):
        mask = (torch.triu(torch.ones(sz, sz)) == 1).transpose(0, 1)
        mask = mask.float().masked_fill(mask == 0, -1e9).masked_fill(mask == 1, float(0.0))
        return mask

    def beam_search(self, memory, beam_size=3, max_len=60, length_penalty=1.0):
        """
        高级 Beam Search，加入 Length Penalty
        """
        batch_size = memory.size(0)
        device = memory.device
        SOS_TOKEN = 1
        EOS_TOKEN = 2

        memory = memory.repeat_interleave(beam_size, dim=0)
        seq = torch.full((batch_size * beam_size, 1), SOS_TOKEN, dtype=torch.long, device=device)
        top_k_scores = torch.zeros((batch_size, beam_size), device=device)
        top_k_scores[:, 1:] = -1e9
        top_k_scores = top_k_scores.view(-1)

        for t in range(max_len):
            tgt_emb = self.tgt_embed(seq)
            output = self.decoder(tgt_emb, memory)
            output = output[:, -1, :]
            log_probs = F.log_softmax(self.fc_out(output), dim=-1)

            scores = top_k_scores.unsqueeze(1) + log_probs
            scores = scores.view(batch_size, -1)

            best_scores, best_indices = scores.topk(beam_size, dim=1)

            vocab_size = log_probs.size(1)
            beam_indices = best_indices.div(vocab_size, rounding_mode='floor')
            token_indices = best_indices % vocab_size

            new_seq = []
            for b in range(batch_size):
                for k in range(beam_size):
                    prev_beam_idx = b * beam_size + beam_indices[b, k]
                    prev_sequence = seq[prev_beam_idx]
                    new_token = token_indices[b, k].unsqueeze(0)
                    new_seq.append(torch.cat([prev_sequence, new_token]))

            seq = torch.stack(new_seq)
            top_k_scores = best_scores.view(-1)

        final_sequences = seq.view(batch_size, beam_size, -1)
        final_scores = top_k_scores.view(batch_size, beam_size)

        # --- Length Penalty Logic ---
        # Score = log_prob / (length ^ penalty)
        lengths = torch.tensor([len(s) for s in seq]).to(device).view(batch_size, beam_size)
        penalty = torch.pow(lengths.float(), length_penalty)
        final_scores = final_scores / penalty

        best_beam_idx = final_scores.argmax(dim=1)

        best_sequences = []
        for b in range(batch_size):
            best_sequences.append(final_sequences[b, best_beam_idx[b]])
        best_sequences = torch.stack(best_sequences)

        # Post-processing (Truncate at EOS)
        output_cleaned = []
        for i in range(batch_size):
            s = best_sequences[i]
            eos_indices = (s == EOS_TOKEN).nonzero(as_tuple=True)[0]
            if len(eos_indices) > 0:
                s = s[:eos_indices[0]]
            output_cleaned.append(s)

        max_actual_len = max([len(x) for x in output_cleaned])
        final_tensor = torch.zeros((batch_size, max_actual_len), dtype=torch.long, device=device)
        for i in range(batch_size):
            length = len(output_cleaned[i])
            if length > 0:
                final_tensor[i, :length] = output_cleaned[i]

        return final_tensor