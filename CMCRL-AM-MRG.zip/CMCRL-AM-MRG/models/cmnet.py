import torch
import torch.nn as nn
import argparse
from transformers import LlamaForCausalLM, AutoTokenizer
from modules.modules4cmnet import MemoryEnhancedVDM


class CMNet(nn.Module):
    def __init__(self, args, tokenizer=None):
        super(CMNet, self).__init__()

        # 1. 兼容性处理 (防止报错 AttributeError)
        if isinstance(args, dict):
            args = argparse.Namespace(**args)

        self.args = args
        self.tokenizer = tokenizer

        self.visual_dim = getattr(args, 'visual_dim', 768)
        self.llm_dim = 4096
        memory_size = getattr(args, 'memory_size', 6000)

        self.vdm = MemoryEnhancedVDM(embed_dim=self.visual_dim, memory_size=memory_size)

        self.proj = nn.Sequential(
            nn.Linear(self.visual_dim, self.llm_dim),
            nn.LayerNorm(self.llm_dim),
            nn.GELU(),
            nn.Linear(self.llm_dim, self.llm_dim)
        )

        # --- [核心修改] 强制使用 FP16 加载 ---
        print(f"Loading LLM from {args.llm_path} in FP16 (Half Precision)...")
        self.llm = LlamaForCausalLM.from_pretrained(
            args.llm_path,
            torch_dtype=torch.float16,  # <--- 这一行救命！显存占用减半
            low_cpu_mem_usage=True
        )

        # 冻结参数
        for param in self.llm.parameters():
            param.requires_grad = False

        # 开启梯度检查点 (进一步省显存)
        if hasattr(self.llm, "gradient_checkpointing_enable"):
            self.llm.gradient_checkpointing_enable()

    def forward(self, visual_tokens, input_ids=None, attention_mask=None, mode='train'):
        # 1. 视觉特征处理
        f_star = self.vdm(visual_tokens)
        visual_embeds = self.proj(f_star)

        if mode == 'train':
            text_embeds = self.llm.model.embed_tokens(input_ids)

            # [关键] 类型对齐：如果 LLM 是 fp16，投影出来的特征也要转 fp16
            if text_embeds.dtype != visual_embeds.dtype:
                visual_embeds = visual_embeds.to(text_embeds.dtype)

            inputs_embeds = torch.cat([visual_embeds, text_embeds], dim=1)

            batch_size = visual_embeds.shape[0]
            visual_len = visual_embeds.shape[1]
            empty_targets = torch.ones([batch_size, visual_len], dtype=torch.long).to(visual_tokens.device) * -100
            targets = torch.cat([empty_targets, input_ids], dim=1)

            if attention_mask is not None:
                vis_mask = torch.ones([batch_size, visual_len]).to(visual_tokens.device)
                attention_mask = torch.cat([vis_mask, attention_mask], dim=1)

            outputs = self.llm(
                inputs_embeds=inputs_embeds,
                attention_mask=attention_mask,
                labels=targets
            )
            return outputs.loss
        else:
            visual_embeds = visual_embeds.to(self.llm.dtype)
            return self.generate(visual_embeds)

    def generate(self, visual_embeds):
        # 强制参数：逼迫模型开口说话
        max_len = 80  # 放宽上限
        min_len = 20  # 【关键】强制下限，必须生成至少 20 个 token，防止它闭嘴

        output_ids = self.llm.generate(
            inputs_embeds=visual_embeds,

            # --- 核心策略 ---
            num_beams=1,  # 保持贪婪搜索 (Greedy)，最稳
            do_sample=False,

            # --- 修正惩罚项 ---
            repetition_penalty=1.2,  # 【回调】从 2.0 降到 1.2，太高会让模型不敢用词
            no_repeat_ngram_size=3,  # 保持防复读
            length_penalty=1.0,  # 【关键修正】改回 1.0，不要惩罚长度！

            # --- 范围限制 ---
            max_length=max_len,
            min_length=min_len,
            early_stopping=True,

            use_cache=True
        )
        return output_ids
