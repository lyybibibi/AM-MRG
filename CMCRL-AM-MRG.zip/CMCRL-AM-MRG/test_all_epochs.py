import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
import argparse
import os
import json
import re
import pandas as pd
import numpy as np  # [新增] 必须导入 numpy，否则后面的 isinstance(..., np.ndarray) 会报错
from torchvision import transforms

# 导入项目组件
from models.cmnet import CMNet
from utils.tokenizers import Tokenizer

try:
    from utils.dataset import IuxrayMultiImageDataset
except ImportError:
    pass

# 尝试导入指标计算
try:
    from metric.metrics import compute_scores
except ImportError:
    print("!!! Warning: metric folder not found. Scores will be empty.")
    compute_scores = None


def natural_sort_key(s):
    """自然排序：确保 epoch_2 在 epoch_10 前面"""
    return [int(text) if text.isdigit() else text.lower() for text in re.split('([0-9]+)', s)]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image_dir', type=str, required=True)
    parser.add_argument('--ann_path', type=str, required=True)
    parser.add_argument('--cfg', type=str, required=True)
    # 这里改成传入 checkpoints 文件夹路径
    parser.add_argument('--ckpt_dir', type=str, required=True, help="Path to folder containing .pth files")
    parser.add_argument('--vis_mem_path', type=str, default='visual_memory_bank_iu.npy')
    parser.add_argument('--batch_size', type=int, default=16)
    parser.add_argument('--save_csv', type=str, default='results/all_epochs_metrics.csv')
    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f">>> [AutoTest] Device: {device}")

    # 1. 初始化配置与数据 (只做一次)
    with open(args.cfg, 'r') as f:
        full_config = json.load(f)

    # Config patch
    import SwinCheX.config as swin_config_module
    from yacs.config import CfgNode as CN
    def patched_update_config(config, args_obj):
        config.defrost()
        if not hasattr(config, 'NIH'): config.NIH = CN()
        config.NIH.num_mlp_heads = 1
        config.NIH.num_classes = 14
        config.freeze()
        return config

    swin_config_module.update_config = patched_update_config

    # Tokenizer
    data_config = full_config['data']
    data_config["threshold"] = data_config.get("threshold", 3)
    data_config["ann_path"] = args.ann_path
    tokenizer = Tokenizer(data_config)
    if not hasattr(tokenizer, 'encode'): tokenizer.encode = tokenizer.__call__
    vocab_len = len(tokenizer.token2idx)

    # Dataset
    val_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
    ])
    test_dataset = IuxrayMultiImageDataset(data_config, tokenizer, split='test', transform=val_transform)

    def test_collate_fn(batch):
        # 仅用于测试的 Collate
        ids, images, gt_ids = [], [], []
        for item in batch:
            ids.append(item[0])
            images.append(item[1])
            gt_ids.append(item[2])
        return ids, torch.stack(images), gt_ids

    test_loader = DataLoader(test_dataset, batch_size=args.batch_size, shuffle=False,
                             num_workers=4, collate_fn=test_collate_fn)

    # Model Init (Load structure once)
    for k, v in full_config['model'].items():
        setattr(args, k, v)
    model = CMNet(args, tokenizer)

    # Resize embedding if needed
    if model.tgt_embed.num_embeddings != vocab_len:
        d_model = getattr(args, 'd_model', 768)
        model.tgt_embed = torch.nn.Embedding(vocab_len, d_model)
        model.fc_out = torch.nn.Linear(d_model, vocab_len)

    model = model.to(device)

    # 2. 扫描所有 Checkpoints
    ckpt_files = [f for f in os.listdir(args.ckpt_dir) if f.endswith('.pth')]
    ckpt_files.sort(key=natural_sort_key)  # 自然排序

    if len(ckpt_files) == 0:
        print("No checkpoints found!")
        return

    print(f">>> [AutoTest] Found {len(ckpt_files)} checkpoints. Starting batch evaluation...")

    all_results = []

    # 3. 循环测试
    for ckpt_file in ckpt_files:
        epoch_name = ckpt_file.replace('.pth', '')
        ckpt_path = os.path.join(args.ckpt_dir, ckpt_file)

        print(f"\n>>> ------------------------------------------------")
        print(f">>> Testing: {epoch_name}")

        # 加载权重
        try:
            checkpoint = torch.load(ckpt_path, map_location='cpu')
            state_dict = checkpoint.get('state_dict', checkpoint)
            new_sd = {k.replace('module.', ''): v for k, v in state_dict.items()}
            model.load_state_dict(new_sd, strict=False)
            model.eval()
        except Exception as e:
            print(f"!!! Error loading {ckpt_file}: {e}")
            continue

        # 推理
        results = {}
        gts = {}

        with torch.no_grad():
            for batch in tqdm(test_loader, desc=f"Infer {epoch_name}", leave=False):
                ids, images, gt_token_ids = batch
                images = images.to(device)

                # 使用 Beam Search (beam_size=3)
                # 注意：如果 cmnet.json 或 model 内部默认 beam_size 不是你想要的，可以在这里修改
                # 例如：output_ids = model(images, mode='sample', update_opts={'beam_size': 3})
                output_ids = model(images, mode='sample')

                for i in range(len(ids)):
                    img_id = ids[i]

                    # 预测结果解码
                    pred_text = tokenizer.decode(output_ids[i].cpu().numpy().tolist())

                    # -----------------------------------------------------------
                    # [Strict Logic] 严谨的数据类型适配，符合多模态缝合策略
                    # -----------------------------------------------------------
                    # 获取当前样本的 token IDs
                    target_data = gt_token_ids[i]

                    # 1. 判定是否为 PyTorch Tensor (常见于经过 Collate 补齐的数据)
                    if isinstance(target_data, torch.Tensor):
                        target_data = target_data.cpu().numpy().tolist()

                    # 2. 判定是否为 Numpy Array (常见于从缓存文件加载的数据)
                    elif isinstance(target_data, np.ndarray):
                        target_data = target_data.tolist()

                    # 3. 判定是否为 List (常见于 DataLoader 的原始输出)
                    elif isinstance(target_data, list):
                        # 深度检查：如果 List 内部还是 Tensor (如未堆叠的 Tensor list)
                        if len(target_data) > 0 and isinstance(target_data[0], torch.Tensor):
                            target_data = [t.item() for t in target_data]
                        # 否则保持原样

                    # [Decoding] 执行解码
                    # Tokenizer 内部会自动忽略 <pad>, <bos>, <eos>
                    gt_text = tokenizer.decode(target_data)
                    # -----------------------------------------------------------

                    results[img_id] = [pred_text]
                    gts[img_id] = [gt_text]

        # 计算指标
        if compute_scores:
            scores = compute_scores(gts, results)
            # 打印关键指标
            print(
                f"    CIDEr: {scores['CIDEr']:.4f} | BLEU_4: {scores['BLEU_4']:.4f} | ROUGE_L: {scores['ROUGE_L']:.4f}")

            # 记录数据
            row = {'Epoch': epoch_name}
            row.update(scores)
            all_results.append(row)
        else:
            print("    Metrics skipped.")

    # 4. 汇总与保存
    if all_results:
        df = pd.DataFrame(all_results)

        # 保存 CSV
        os.makedirs(os.path.dirname(args.save_csv), exist_ok=True)
        df.to_csv(args.save_csv, index=False)
        print(f"\n>>> [Done] All metrics saved to {args.save_csv}")

        # 找出 CIDEr 最高的 Epoch
        best_epoch = df.loc[df['CIDEr'].idxmax()]

        print("\n" + "=" * 50)
        print("🏆  BEST MODEL IDENTIFIED  🏆")
        print("=" * 50)
        print(f"Best Checkpoint : {best_epoch['Epoch']}")
        print(f"CIDEr           : {best_epoch['CIDEr']:.4f}")
        print(f"BLEU_1          : {best_epoch['BLEU_1']:.4f}")
        print(f"BLEU_4          : {best_epoch['BLEU_4']:.4f}")
        print(f"ROUGE_L         : {best_epoch['ROUGE_L']:.4f}")
        print("=" * 50)


if __name__ == '__main__':
    main()