import torch
from torch.utils.data import DataLoader
from tqdm import tqdm
import argparse
import os
import json
import numpy as np
from torchvision import transforms
from PIL import Image

# 导入项目组件
from models.cmnet import CMNet
from utils.tokenizers import Tokenizer

# 兼容 Dataset 导入
try:
    from utils.dataset import IuxrayMultiImageDataset
except ImportError:
    pass

# 尝试导入指标计算库
try:
    from metric.metrics import compute_scores
except ImportError:
    print("!!! Warning: metric folder not found or dependencies missing. Only generation will run.")
    compute_scores = None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image_dir', type=str, required=True)
    parser.add_argument('--ann_path', type=str, required=True)
    parser.add_argument('--cfg', type=str, required=True)
    parser.add_argument('--checkpoint', type=str, required=True)
    parser.add_argument('--vis_mem_path', type=str, default='visual_memory_bank_iu.npy')
    parser.add_argument('--batch_size', type=int, default=8)
    parser.add_argument('--save_path', type=str, default='results/iu_xray_stage2_generated.json')
    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f">>> [Test] Running on device: {device}")

    # 1. 加载配置
    with open(args.cfg, 'r') as f:
        full_config = json.load(f)

    # 劫持 Swin 配置
    import SwinCheX.config as swin_config_module
    from yacs.config import CfgNode as CN
    def patched_update_config(config, args_obj):
        config.defrost()
        if not hasattr(config, 'NIH'): config.NIH = CN()
        config.NIH.num_mlp_heads = 1
        config.NIH.num_classes = 14
        config.freeze()
        return config

    swin_config_module.update_config = patched_update_config

    # 2. 初始化 Tokenizer
    data_config = full_config['data']
    data_config["threshold"] = data_config.get("threshold", 3)
    data_config["ann_path"] = args.ann_path

    print(">>> [Tokenizer] Loading Vocabulary...")
    tokenizer = Tokenizer(data_config)
    # 修复 Tokenizer 接口
    if not hasattr(tokenizer, 'encode'): tokenizer.encode = tokenizer.__call__

    vocab_len = len(tokenizer.token2idx)
    print(f">>> [Tokenizer] Vocab Size: {vocab_len}")

    # 3. 初始化模型
    for k, v in full_config['model'].items():
        setattr(args, k, v)

    model = CMNet(args, tokenizer)

    # 修正 Embedding 大小 (必须与训练时一致)
    if model.tgt_embed.num_embeddings != vocab_len:
        print(f">>> [Model Fix] Resizing Embedding to {vocab_len}")
        d_model = getattr(args, 'd_model', 768)
        model.tgt_embed = torch.nn.Embedding(vocab_len, d_model)
        model.fc_out = torch.nn.Linear(d_model, vocab_len)

    # 4. 加载训练好的权重
    if os.path.exists(args.checkpoint):
        print(f">>> [Loading] Loading Checkpoint: {args.checkpoint}")
        ckpt = torch.load(args.checkpoint, map_location='cpu')

        # 兼容不同的保存格式
        if 'state_dict' in ckpt:
            state_dict = ckpt['state_dict']
        else:
            state_dict = ckpt

        # 移除可能的 module. 前缀
        new_sd = {k.replace('module.', ''): v for k, v in state_dict.items()}

        # 加载权重 (strict=True 确保完全匹配，因为这是测试)
        msg = model.load_state_dict(new_sd, strict=False)
        print(f">>> [Loaded] Missing keys: {len(msg.missing_keys)}, Unexpected keys: {len(msg.unexpected_keys)}")
    else:
        print(f"!!! [Error] Checkpoint not found: {args.checkpoint}")
        return

    model = model.to(device)
    model.eval()

    # 5. 准备测试数据
    val_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
    ])

    # 注意这里 split='test'
    test_dataset = IuxrayMultiImageDataset(data_config, tokenizer, split='test', transform=val_transform)

    def test_collate_fn(batch):
        # 简单的 Collate，不处理 Targets padding，因为测试时只需要 Image
        from torch.utils.data.dataloader import default_collate
        new_batch = []
        for item in batch:
            # item: (id, image, report_ids, mask, seq_len)
            img_id = item[0]
            img = item[1]
            report_ids = item[2]
            new_batch.append((img_id, img, torch.LongTensor(report_ids)))

        # 手动堆叠 image
        images = torch.stack([x[1] for x in new_batch])
        ids = [x[0] for x in new_batch]
        gt_ids = [x[2] for x in new_batch]

        return ids, images, gt_ids

    test_loader = DataLoader(
        test_dataset, batch_size=args.batch_size, shuffle=False,
        num_workers=4, collate_fn=test_collate_fn
    )

    # 6. 开始生成
    print(f">>> [Inference] Starting generation on {len(test_dataset)} samples...")

    results = {}
    gts = {}

    with torch.no_grad():
        for batch in tqdm(test_loader):
            ids, images, gt_token_ids = batch
            images = images.to(device)

            # 调用生成方法 (自动触发因果干预和Memory检索)
            # generate_simple 返回 [B, SeqLen]
            # 确保 CMNet 的 forward 逻辑在 mode!='train' 时调用 generate_simple
            output_ids = model(images, mode='sample')

            # 解码
            for i in range(len(ids)):
                img_id = ids[i]

                # 预测结果解码
                pred_tokens = output_ids[i].cpu().numpy().tolist()
                pred_text = tokenizer.decode(pred_tokens)

                # 真实结果解码 (Ground Truth)
                gt_tokens = gt_token_ids[i].numpy().tolist()
                gt_text = tokenizer.decode(gt_tokens)

                results[img_id] = [pred_text]
                gts[img_id] = [gt_text]

    # 7. 保存结果
    os.makedirs(os.path.dirname(args.save_path), exist_ok=True)
    with open(args.save_path, 'w') as f:
        json.dump({"predictions": results, "targets": gts}, f, indent=4)
    print(f">>> [Saved] Results saved to {args.save_path}")

    # 8. 计算指标
    if compute_scores is not None:
        print(">>> [Evaluating] Calculating Metrics...")
        # compute_scores 接受两个 dict: {id: [pred]}, {id: [gt]}
        scores = compute_scores(gts, results)
        print("\n" + "=" * 40)
        print("   CMCRL-AM-MRG Evaluation Results")
        print("=" * 40)
        for key, value in scores.items():
            print(f"{key}: {value:.4f}")
        print("=" * 40)
    else:
        print("Skipping metrics calculation (module missing).")


if __name__ == '__main__':
    main()