import torch
import torch.nn as nn
import torch.nn.functional as F
from modules.modules4transformer import EncoderLayer, SublayerConnection, \
    MultiHeadedAttention, LayerNorm, PositionwiseFeedForward, clones
from modules.coatnet import Transformer as DownSamplingTrans
import math
from modules.Qformer import BertConfig, BertLMHeadModel
# 修改 modules/modules4vlci.py 顶部的导入
from modules.modules4transformer import EncoderLayer, SublayerConnection, \
    MultiHeadedAttention, LayerNorm, PositionwiseFeedForward, clones, Encoder
    # ↑↑↑ 确保这里加了 "Encoder"

class AF(nn.Module):
    """
    Attention Fuse Module
    """
    def __init__(self, embed_dim):
        super(AF, self).__init__()
        self.embed_dim = embed_dim
        self.q = nn.Linear(embed_dim, embed_dim)
        self.out = nn.Linear(embed_dim, embed_dim)

    def forward(self, q, k, v, proj=False):
        if proj:
            q = self.q(q)
            qk = torch.matmul(q, k.transpose(-1, -2)) / math.sqrt(self.embed_dim)
            score = qk.softmax(dim=-1)
            out = score.matmul(v)
            out = self.out(out)
        else:
            qk = torch.matmul(q, k.transpose(-1, -2))
            score = qk.softmax(dim=-1)
            out = score.matmul(v)
        return out


class FDIntervention(nn.Module):
    """
    Front-Door Intervention Module
    """
    def __init__(self, embed_dim):
        super(FDIntervention, self).__init__()
        self.embed_dim = embed_dim
        self.af_1 = AF(embed_dim)
        self.af_2 = AF(embed_dim)

    def forward(self, feature, mediator, proj=False):
        v = self.af_1(mediator, feature, feature, proj)
        out = self.af_2(feature, mediator, v, proj)
        return out


class LGFM(nn.Module):
    """
    Local-Global Fuse Module
    """
    def __init__(self, embed_dim):
        super(LGFM, self).__init__()
        self.embed_dim = embed_dim
        self.norm_l = LayerNorm(embed_dim)
        self.norm_g = LayerNorm(embed_dim)
        self.gelu = nn.GELU()
        self.llf = MultiHeadedAttention(8, embed_dim)
        self.lgf = MultiHeadedAttention(8, embed_dim)
        self.proj = nn.Linear(embed_dim * 2, embed_dim)
        self.norm = LayerNorm(embed_dim)
        self.fc = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 4),
            nn.Linear(embed_dim * 4, embed_dim),
        )

    def forward(self, fl, fg):
        fl = self.norm_l(fl)
        fg = self.norm_g(fg)
        fll = fl + self.llf(fl, fl, fl)
        flg = fl + self.lgf(fl, fg, fg)
        out = self.proj(torch.cat([fll, flg], dim=-1))
        out = self.norm(out)
        out = out + self.fc(out)
        return out


class CrossLayer(EncoderLayer):
    """
    composed by a cross-attention layer and feed-forward network
    """
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super(CrossLayer, self).__init__(embed_dim, num_heads, ff_dim, dropout)

    def forward(self, x, y):
        x = self.sublayer_attn(x, lambda x: self.attn(x, y, y, None))
        x = self.sublayer_ff(x, self.feed_forward)
        return x


class PartAttention(nn.Module):
    """
    @article{he2021transfg,
    title={TransFG: A Transformer Architecture for Fine-grained Recognition},
    author={He, Ju and Chen, Jie-Neng and Liu, Shuai and Kortylewski, Adam and Yang, Cheng and Bai, Yutong and Wang, Changhu and Yuille, Alan},
    journal={arXiv preprint arXiv:2103.07976},
    year={2021}
    }
    """
    def __init__(self):
        super(PartAttention, self).__init__()

    def forward(self, x, k=6):
        """
        x -> list: the attention list from the encoder
        k: select the top k attention score and their index from each head
        """
        length = len(x)
        last_map = x[0]
        for i in range(1, length):
            last_map = torch.matmul(x[i], last_map)
        last_map = last_map[:, :, 0, 1:]
        max_attn, max_inx = last_map.sort(2, descending=True)
        max_inx = max_inx[:, :, :k].reshape([last_map.size(0), -1])
        max_attn = max_attn[:, :, :k].reshape([last_map.size(0), -1])
        return max_attn, max_inx


class LocalSample(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout=0.):
        super(LocalSample, self).__init__()
        self.part_select = PartAttention()
        self.causal_layer = CaaM(embed_dim, num_heads, ff_dim, dropout)

    def forward(self, x, attn, k):
        """
        x: all visual tokens
        attn: attention from encoder
        k: select k local feature

        fl: k local feature without [CLS] token
        """
        part_attn, part_inx = self.part_select(attn, k)
        part_inx = part_inx + 1
        parts = []
        B, num = part_inx.shape
        for i in range(B):
            parts.append(x[i, part_inx[i, :]])
        fl = torch.stack(parts).squeeze(1)
        fl = torch.cat([x[:, :1], fl], dim=1)
        fl = self.causal_layer(fl)[:, 1:]
        return fl


# 修改 modules/modules4vlci.py
# 替换原本的 DiseaseSpecificMediator 类

# modules/modules4vlci.py

class DiseaseSpecificMediator(nn.Module):
    def __init__(self, embed_dim, num_heads, num_queries=32, cross_attention_freq=2):
        super(DiseaseSpecificMediator, self).__init__()

        bert_dim = 768
        self.target_dim = embed_dim  # 512

        # 【改进 1】升级输入投影层 (Adapter)
        # 从简单的 Linear 改为: Linear -> LayerNorm -> GELU -> Linear
        # 这样能更平滑地把 ResNet 特征“翻译”给 BERT
        self.proj_in = nn.Sequential(
            nn.Linear(embed_dim, bert_dim),
            nn.LayerNorm(bert_dim),
            nn.GELU()
            # 注意：这里不需要第二个 Linear，因为我们要的就是 768
        )

        # 【改进 2】升级输出投影层
        self.proj_out = nn.Sequential(
            nn.Linear(bert_dim, embed_dim),
            nn.LayerNorm(embed_dim)
            # 加个 Norm 让输出给 Decoder 的特征更稳定
        )

        # 初始化 Queries
        self.query_tokens = nn.Parameter(torch.zeros(1, num_queries, bert_dim))

        # 加载 BERT (保持你之前的本地路径逻辑)
        bert_path = "/root/projects/CMCRL-main/bert-base-uncased"
        self.encoder_config = BertConfig.from_pretrained(bert_path)
        self.encoder_config.encoder_width = bert_dim
        self.encoder_config.hidden_size = bert_dim
        self.encoder_config.num_attention_heads = 12
        self.encoder_config.query_length = num_queries
        self.encoder_config.cross_attention_freq = cross_attention_freq

        self.Qformer = BertLMHeadModel.from_pretrained(bert_path, config=self.encoder_config)

        # 清理 BERT 无用头 (保持不变)
        self.Qformer.cls = None
        self.Qformer.bert.embeddings.word_embeddings = None
        self.Qformer.bert.embeddings.position_embeddings = None
        for layer in self.Qformer.bert.encoder.layer:
            layer.output = None
            layer.intermediate = None

        # 权重初始化
        self._init_weights()

    def _init_weights(self):
        # 专门初始化投影层
        for m in self.proj_in.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None: nn.init.constant_(m.bias, 0)
        for m in self.proj_out.modules():
            if isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight)
                if m.bias is not None: nn.init.constant_(m.bias, 0)
        nn.init.normal_(self.query_tokens, std=0.02)

    def forward(self, image_embeds):
        # [B, L, 512] -> [B, L, 768]
        image_embeds = self.proj_in(image_embeds)

        image_atts = torch.ones(image_embeds.size()[:-1], dtype=torch.long).to(image_embeds.device)
        query_tokens = self.query_tokens.expand(image_embeds.shape[0], -1, -1)

        query_output = self.Qformer.bert(
            query_embeds=query_tokens,
            encoder_hidden_states=image_embeds,
            encoder_attention_mask=image_atts,
            return_dict=True,
        )

        disease_features = query_output.last_hidden_state

        # [B, Q, 768] -> [B, Q, 512]
        disease_features = self.proj_out(disease_features)

        return disease_features





class GlobalSample(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super(GlobalSample, self).__init__()
        self.global_sample = DownSamplingTrans(embed_dim, embed_dim, (7, 7), downsample=True)

    def forward(self, x):
        img = x[:, 1:, :]
        B, L, N = img.size()
        img = img.reshape([-1, 14, 14, N])

        img = img.permute(0, 3, 1, 2)
        img = self.global_sample(img)
        img = img.permute(0, 2, 3, 1)

        fg = img.reshape([B, -1, N])
        return fg


class CausalAttention(nn.Module):
    def __init__(self, h, d_model, dropout=0.1):
        super(CausalAttention, self).__init__()
        assert d_model % h == 0
        self.d_k = d_model // h
        self.h = h
        self.linears = clones(nn.Linear(d_model, d_model), 4)
        self.attn = None
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, x):
        q = x
        k = x
        v = x

        nbatches = q.size(0)
        q, k, v = \
            [l(x).view(nbatches, -1, self.h, self.d_k).transpose(1, 2)
             for l, x in zip(self.linears, (q, k, v))]

        d_k = q.size(-1)

        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(d_k)
        p_attn = F.softmax(-scores, dim=-1)
        p_attn_comp = F.softmax(scores, dim=-1)

        self.attn = p_attn
        p_attn = self.dropout(p_attn)
        p_attn_comp = self.dropout(p_attn_comp)
        out = torch.matmul(p_attn, v)
        out = out.transpose(1, 2).contiguous().view(nbatches, -1, self.h * self.d_k)
        out = self.linears[-1](out)
        out_comp = torch.matmul(p_attn_comp, v)
        out_comp = out_comp.transpose(1, 2).contiguous().view(nbatches, -1, self.h * self.d_k)
        out_comp = self.linears[-1](out_comp)
        return out, out_comp


class CaaMSublayerConnection(nn.Module):
    def __init__(self, embed_dim, dropout):
        super(CaaMSublayerConnection, self).__init__()
        self.norm = LayerNorm(embed_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, sublayer):
        attn, attn_comp = sublayer(self.norm(x))
        attn = self.dropout(attn)
        attn_comp = self.dropout(attn_comp)
        return x + attn, attn_comp


class CaaM(nn.Module):
    """
    @inproceedings{wang2021causal,
    title={Causal Attention for Unbiased Visual Recognition},
    author={Wang, Tan and Zhou, Chang and Sun, Qianru and Zhang, Hanwang},
    booktitle={Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV)},
    year={2021}
    }
    """
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super(CaaM, self).__init__()
        self.attn = CausalAttention(num_heads, embed_dim, dropout)
        self.feed_forward = PositionwiseFeedForward(embed_dim, ff_dim, dropout)
        self.sublayer_attn = CaaMSublayerConnection(embed_dim, dropout)
        self.sublayer_ff = SublayerConnection(embed_dim, dropout)

    def forward(self, x, mask=None):
        x, x_comp = self.sublayer_attn(x, lambda x: self.attn(x))
        x = self.sublayer_ff(x, self.feed_forward)
        x = x + self.sublayer_ff(x_comp, self.feed_forward)
        return x


class VDM(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout=.1):
        super(VDM, self).__init__()
        self.fuse = LGFM(embed_dim)
        self.intervene = FDIntervention(embed_dim)

    def forward(self, x, fl=None, fg=None, mode='y', proj=False):
        """
        fl: local feature
        fg: global feature
        """
        if mode == 'y':
            mt = self.fuse(fl, fg)
            out = self.intervene(x, mt, proj)
        else:
            out = 0
        return out + x


class LDM(nn.Module):
    def __init__(self, embed_dim):
        super(LDM, self).__init__()
        self.embed_dim = embed_dim
        self.fuse_v = CrossLayer(embed_dim, 8, 4*embed_dim, .1)
        self.fuse_t = CrossLayer(embed_dim, 8, 4*embed_dim, .1)
        self.norm = LayerNorm(embed_dim)
        self.intervene = FDIntervention(embed_dim)

    def forward(self, x, text, vis, mode, proj):
        if mode == 'n':
            out = 0
        else:
            mediator = self.fuse_t(vis, text)
            mediator = self.fuse_v(mediator, vis) + mediator
            mediator = self.norm(mediator)
            if mode == 'y':
                out = self.intervene(x, mediator, proj)
            else:
                out = 0
        return out + x


class CausalEncoder(Encoder):
    def __init__(self, embed_dim, num_layer, num_heads, ff_dim, dropout, mode='none'):
        super(CausalEncoder, self).__init__(embed_dim, num_layer, num_heads, ff_dim, dropout)
        self.mode = mode

        # 视觉去偏模块 (保持不变)
        self.do = VDM(embed_dim, num_heads, ff_dim, dropout)

        # 全局采样模块 (保持不变)
        self.global_sample = GlobalSample(embed_dim, num_heads, ff_dim, dropout)

        # ------------------- 核心修改点 -------------------
        # [旧代码] self.local_sample = LocalSample(...)

        # [新代码] 使用显式疾病语义 Mediator (基于 Q-Former)
        # num_queries=32 对应您在 DiseaseSpecificMediator 设置的默认值
        self.disease_mediator = DiseaseSpecificMediator(embed_dim, num_heads, num_queries=32)
        # ------------------------------------------------

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            # 使用 Xavier Uniform 初始化 (遵循 ViT 标准)
            torch.nn.init.xavier_uniform_(m.weight)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)

    def forward(self, h, mask=None, pos=None, k=6, proj=False):
        """
        h: [Batch, Length, Dim] 视觉特征输入
        mask: 掩码
        pos: 位置编码
        k: (已弃用) 旧版 LocalSample 的 top-k 参数
        """
        attn = []
        for layer in self.layers:
            h = layer(h, mask)
            attn.append(layer.attn.attn)

        # 添加位置编码 (Add Positional Embedding)
        if h.size(1) > 197:
            h = h + torch.cat([pos, pos[:, 1:, :]], dim=1)
        else:
            h = h + pos

        # ------------------- 核心修改点 -------------------
        # [旧代码] fl = self.local_sample(h, attn, k)

        # [新代码] 获取显式疾病语义特征
        # fl 的形状现在是 [Batch, Num_Queries(32), Dim]
        fl = self.disease_mediator(h)
        # ------------------------------------------------

        # 获取全局特征
        fg = self.global_sample(h)

        # 构造 Mediator 字典
        # 这里的 'local' 现在实际上包含了 "Disease Semantic Features"
        mediator = {"local": fl, "global": fg, 'attn': attn}

        # 执行因果干预 (Visual De-confounding)
        # VDM 模块会自动处理 fl 和 fg 的融合与干预
        h = self.do(h, fl=fl, fg=fg, mode=self.mode, proj=proj)

        h = self.norm(h)
        return h, mediator