import torch
import torch.nn as nn
import torch.nn.functional as F


class DiseaseAwareTokenMining(nn.Module):
    def __init__(self, dim=768, num_tokens=32):
        super().__init__()
        actual_dim = dim if dim is not None else 768
        self.query = nn.Parameter(torch.randn(1, num_tokens, actual_dim))
        nn.init.normal_(self.query, std=0.02)  # 使用较小的初始化方差
        self.attn = nn.MultiheadAttention(embed_dim=actual_dim, num_heads=8, batch_first=True)
        self.norm = nn.LayerNorm(actual_dim)

    def forward(self, x):
        b = x.shape[0]
        q = self.query.expand(b, -1, -1)
        # 加上 NaN 检查
        if torch.isnan(x).any(): x = torch.nan_to_num(x)
        m, _ = self.attn(q, x, x)
        return self.norm(m)


class CausalInterventionLayer(nn.Module):
    def __init__(self, dim=768):
        super().__init__()
        actual_dim = dim if dim is not None else 768
        self.gate = nn.Sequential(
            nn.Linear(actual_dim * 2, actual_dim),
            nn.LayerNorm(actual_dim),
            nn.Sigmoid()
        )
        self.proj = nn.Linear(actual_dim, actual_dim)
        self.norm = nn.LayerNorm(actual_dim)

    def forward(self, M, Z):
        # 拼接前再次清洗，防止脏数据传播
        M = torch.nan_to_num(M)
        Z = torch.nan_to_num(Z)

        combined = torch.cat([M, Z], dim=-1)
        g = self.gate(combined)
        m_hat = M - g * Z
        return self.norm(self.proj(m_hat))