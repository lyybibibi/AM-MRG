import torch
import torch.nn as nn
import torch.nn.functional as F

# 确保 hopfield_layers 文件夹在根目录下
from hopfield_layers.hflayers import Hopfield


class MemoryEnhancedVDM(nn.Module):
    """
    Memory-Enhanced Visual Deconfounding Module (ME-VDM)
    结合了 VLCI 的前门干预思想与 AM-MRG 的 Hopfield 记忆机制。
    """

    def __init__(self, embed_dim, memory_size=6000, beta=4.0):
        super(MemoryEnhancedVDM, self).__init__()

        self.embed_dim = embed_dim

        # --- 1. Hopfield Memory Network (建模混淆因子 Z) ---
        # 修复: 必须同时关闭 affine 参数，否则会触发 AssertError

        self.hopfield_z = Hopfield(
            input_size=embed_dim,
            stored_pattern_size=embed_dim,
            pattern_projection_size=embed_dim,
            output_size=embed_dim,
            hidden_size=64,

            num_heads=1,
            scaling=beta,

            # [核心修复] 关闭归一化的同时，必须显式关闭 affine
            normalize_stored_pattern=False,
            normalize_stored_pattern_affine=False,

            normalize_state_pattern=False,
            normalize_state_pattern_affine=False,

            normalize_pattern_projection=False,
            normalize_pattern_projection_affine=False,

            # 重要：确保输入 batch 是第一维
            batch_first=True
        )

        # --- 2. Causal Fusion Layer (执行前门干预) ---
        # 将 Mediator (M) 和 Confounder (Z) 融合，计算 P(Y|M, Z)
        self.fusion_gate = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim),
            nn.Sigmoid()  # 门控机制
        )
        self.fusion_proj = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim),
            nn.LayerNorm(embed_dim)
        )

        # --- 3. Memory Bank Buffer ---
        self.register_buffer('memory_bank', torch.zeros(memory_size, embed_dim))
        self.is_memory_initialized = False

    def forward(self, disease_aware_tokens):
        """
        Args:
            disease_aware_tokens: [Batch, Num_Diseases, Dim] (即 Mediator M)
        Returns:
            deconfounded_features: [Batch, Num_Diseases, Dim] (即干预后的特征 F*)
        """
        batch_size = disease_aware_tokens.size(0)

        # --- Step 1: 记忆检索 (Retrieve Z) ---
        if not self.is_memory_initialized:
            # 如果未初始化(如在sanity check阶段)，返回零向量避免报错
            z_confounder = torch.zeros_like(disease_aware_tokens)
        else:
            # memory_bank: [Memory_Size, Dim]
            # 我们需要将其作为 Hopfield 的 stored_pattern
            # 这里的 stored_pattern 和 pattern_projection 都是 memory_bank

            # 注意：Hopfield 模块会自动处理广播，但为了安全起见，我们手动扩展 batch
            memory_bank_expanded = self.memory_bank.unsqueeze(0).expand(batch_size, -1, -1)

            # 调用 forward，传入 tuple: (stored_pattern, state_pattern, pattern_projection)
            # state_pattern (Query) = disease_aware_tokens (M)
            # stored_pattern (Key) = memory_bank
            # pattern_projection (Value) = memory_bank
            z_confounder = self.hopfield_z((memory_bank_expanded, disease_aware_tokens, memory_bank_expanded))

        # --- Step 2: 因果干预融合 (Front-Door Intervention) ---
        # 拼接 M 和 Z
        combined = torch.cat([disease_aware_tokens, z_confounder], dim=-1)

        # 使用门控融合 (Gated Fusion)
        gate = self.fusion_gate(combined)
        features = self.fusion_proj(combined)

        # 最终特征 = 融合特征 * 门控 + 原始特征 (残差连接)
        deconfounded_features = features * gate + disease_aware_tokens

        return deconfounded_features

    def update_memory(self, all_train_features):
        """
        核心工具函数：在训练开始前，将全量训练集的 Visual Tokens 存入 Memory Bank。
        all_train_features: Tensor [Total_Samples, Dim] 或 [Total_Samples * Num_Diseases, Dim]
        """
        # 确保特征数量不超过设定的 memory_size，如果超过则采样
        num_features = all_train_features.size(0)
        max_size = self.memory_bank.size(0)

        if num_features > max_size:
            # 随机采样以填充记忆库
            indices = torch.randperm(num_features)[:max_size]
            selected_features = all_train_features[indices]
        else:
            selected_features = all_train_features

        # 更新 Buffer
        current_device = self.memory_bank.device
        # 确保维度匹配
        if selected_features.size(1) != self.embed_dim:
            print(f"Warning: Memory update dim mismatch. Expected {self.embed_dim}, got {selected_features.size(1)}")
            return

        self.memory_bank[:selected_features.size(0)] = selected_features.detach().to(current_device)
        self.is_memory_initialized = True
        print(f"Memory Bank Initialized with {selected_features.size(0)} slots.")