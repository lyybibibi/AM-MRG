import torch
import numpy as np
from torchvision import transforms
from torch.utils.data import DataLoader
from .dataset import IuxrayMultiImageDataset, MimiccxrSingleImageDataset, MixSingleImageDataset


class R2DataLoader(DataLoader):
    def __init__(self, args, tokenizer, split, shuffle):
        self.args = args

        # --- [核心修复] 兼容字典和Namespace对象 ---
        if isinstance(args, dict):
            self.dataset_name = args['dataset_name']
            self.batch_size = args['batch_size']
            self.num_workers = args['num_workers']
        else:
            self.dataset_name = args.dataset_name
            self.batch_size = args.batch_size
            self.num_workers = args.num_workers
        # --------------------------------------

        self.tokenizer = tokenizer
        self.split = split
        self.shuffle = shuffle

        # 图像预处理 (虽然 Stage 2 读的是特征，但如果 fallback 到读图，这里有用)
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize((0.485, 0.456, 0.406),
                                 (0.229, 0.224, 0.225))])

        # 根据数据集名称选择 Dataset 类
        if self.dataset_name == 'iu_xray':
            self.dataset = IuxrayMultiImageDataset(self.args, self.tokenizer, self.split, transform=self.transform)
        elif self.dataset_name == 'mimic_cxr':
            self.dataset = MimiccxrSingleImageDataset(self.args, self.tokenizer, self.split, transform=self.transform)
        else:
            self.dataset = MixSingleImageDataset(self.args, self.tokenizer, self.split, transform=self.transform)

        super(R2DataLoader, self).__init__(
            self.dataset,
            batch_size=self.batch_size,
            shuffle=self.shuffle,
            num_workers=self.num_workers,
            collate_fn=self.collate_fn
        )

    @staticmethod
    def collate_fn(data):
        # 解包数据: (image_id, image, report_ids, report_masks, seq_length)
        images_id, images, reports_ids, reports_masks, seq_lengths = zip(*data)

        # 堆叠图片/特征 Tensor
        images = torch.stack(images, 0)

        # 动态 Padding 逻辑
        # 找到当前 Batch 中最长的序列长度
        max_seq_len = max(seq_lengths)

        # 初始化全 0 矩阵 (Padding ID 通常为 0)
        target_ids = np.zeros((len(reports_ids), max_seq_len), dtype=int)
        target_masks = np.zeros((len(reports_ids), max_seq_len), dtype=int)

        # 填充数据
        for i, report_ids in enumerate(reports_ids):
            target_ids[i, :len(report_ids)] = report_ids
            target_masks[i, :len(report_ids)] = 1

        return images_id, images, torch.LongTensor(target_ids), torch.LongTensor(target_masks), torch.LongTensor(
            seq_lengths)