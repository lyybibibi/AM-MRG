import json
import re
from collections import Counter


class Tokenizer(object):
    """
    [修复版 Tokenizer]
    1. 引入了明确的 Special Tokens (0=PAD, 1=BOS, 2=EOS, 3=UNK)。
    2. __call__ 方法会自动添加 BOS 和 EOS，防止全 0 数据导致的 Loss=NaN。
    """

    def __init__(self, args):
        self.ann_path = args["ann_path"]
        self.threshold = args["threshold"]
        self.dataset_name = args.get("dataset_name", "iu_xray")

        # 设置清洗函数
        if self.dataset_name == 'iu_xray':
            self.clean_report = self.clean_report_iu_xray
        elif self.dataset_name == 'mimic_cxr':
            self.clean_report = self.clean_report_mimic_cxr
        elif self.dataset_name == 'ffa_ir':
            self.clean_report = self.clean_report_ffa_ir
        else:
            self.clean_report = self.clean_report_iu_xray

        with open(self.ann_path, 'r') as f:
            self.ann = json.load(f)

        # --- [关键修复] 定义特殊 Token ID ---
        self.pad_token_id = 0
        self.bos_token_id = 1
        self.eos_token_id = 2
        self.unk_token_id = 3

        self.token2idx, self.idx2token = self.create_vocabulary()

    def create_vocabulary(self):
        total_tokens = []
        # 根据数据集不同，Key 可能不同
        if self.dataset_name == 'ffa_ir':
            _report_key = 'En_Report'
            for example in self.ann['train']:
                # ffa_ir 是字典结构 {id: {...}}
                if isinstance(self.ann['train'], dict):
                    report = self.ann['train'][example][_report_key]
                else:
                    report = example[_report_key]
                tokens = self.clean_report(report).split()
                total_tokens.extend(tokens)
        else:
            _report_key = 'report'
            for example in self.ann['train']:
                tokens = self.clean_report(example[_report_key]).split()
                total_tokens.extend(tokens)

        counter = Counter(total_tokens)
        vocab = [k for k, v in counter.items() if v >= self.threshold]
        vocab.sort()

        # --- 构建映射表 (预留前4位) ---
        token2idx = {
            '<pad>': 0,
            '<bos>': 1,
            '<eos>': 2,
            '<unk>': 3
        }
        idx2token = {
            0: '<pad>',
            1: '<bos>',
            2: '<eos>',
            3: '<unk>'
        }

        for idx, token in enumerate(vocab):
            # 如果原始 vocab 里有 <unk>，跳过它，因为我们已经手动加了
            if token == '<unk>': continue

            real_idx = len(token2idx)  # 动态增加
            token2idx[token] = real_idx
            idx2token[real_idx] = token

        return token2idx, idx2token

    def clean_report_iu_xray(self, report):
        if not report: return ""
        report_cleaner = lambda t: t.replace('..', '.').replace('..', '.').replace('..', '.').replace('1. ', '') \
            .replace('. 2. ', '. ').replace('. 3. ', '. ').replace('. 4. ', '. ').replace('. 5. ', '. ') \
            .replace(' 2. ', '. ').replace(' 3. ', '. ').replace(' 4. ', '. ').replace(' 5. ', '. ') \
            .strip().lower().split('. ')
        sent_cleaner = lambda t: re.sub('[.,?;*!%^&_+():-\[\]{}]', '', t.replace('"', '').replace('/', '').
                                        replace('\\', '').replace("'", '').strip().lower())
        tokens = [sent_cleaner(sent) for sent in report_cleaner(report) if sent_cleaner(sent) != []]
        report = ' . '.join(tokens) + ' .'
        return report

    def clean_report_mimic_cxr(self, report):
        if not report: return ""
        report_cleaner = lambda t: t.replace('\n', ' ').replace('__', '_').replace('__', '_').replace('__', '_') \
            .replace('__', '_').replace('__', '_').replace('__', '_').replace('__', '_').replace('  ', ' ') \
            .replace('  ', ' ').replace('  ', ' ').replace('  ', ' ').replace('  ', ' ').replace('  ', ' ') \
            .replace('..', '.').replace('..', '.').replace('..', '.').replace('..', '.').replace('..', '.') \
            .replace('..', '.').replace('..', '.').replace('..', '.').replace('1. ', '').replace('. 2. ', '. ') \
            .replace('. 3. ', '. ').replace('. 4. ', '. ').replace('. 5. ', '. ').replace(' 2. ', '. ') \
            .replace(' 3. ', '. ').replace(' 4. ', '. ').replace(' 5. ', '. ') \
            .strip().lower().split('. ')
        sent_cleaner = lambda t: re.sub('[.,?;*!%^&_+():-\[\]{}]', '', t.replace('"', '').replace('/', '')
                                        .replace('\\', '').replace("'", '').strip().lower())
        tokens = [sent_cleaner(sent) for sent in report_cleaner(report) if sent_cleaner(sent) != []]
        report = ' . '.join(tokens) + ' .'
        return report

    def clean_report_ffa_ir(self, report):
        if not report: return ""
        report_cleaner = lambda t: t.replace('\n', ' ').replace('__', '_').replace('__', '_').replace('__', '_') \
            .replace('__', '_').replace('__', '_').replace('__', '_').replace('__', '_').replace('  ', ' ') \
            .replace('  ', ' ').replace('  ', ' ').replace('  ', ' ').replace('  ', ' ').replace('  ', ' ') \
            .replace('..', '.').replace('..', '.').replace('..', '.').replace('..', '.').replace('..', '.') \
            .replace('..', '.').replace('..', '.').replace('..', '.').replace('1. ', '').replace('. 2. ', '. ') \
            .replace('. 3. ', '. ').replace('. 4. ', '. ').replace('. 5. ', '. ').replace(' 2. ', '. ') \
            .replace(' 3. ', '. ').replace(' 4. ', '. ').replace(' 5. ', '. ') \
            .strip().lower().split('. ')
        sent_cleaner = lambda t: re.sub('[.,?;*!%^&_+():-\[\]{}]', '', t.replace('"', '').replace('/', '')
                                        .replace('\\', '').replace("'", '').strip().lower())
        tokens = [sent_cleaner(sent) for sent in report_cleaner(report) if sent_cleaner(sent) != []]
        report = ' . '.join(tokens) + ' .'
        return report

    def get_token_by_id(self, id):
        return self.idx2token.get(id, '<unk>')

    def get_id_by_token(self, token):
        if token not in self.token2idx:
            return self.token2idx['<unk>']
        return self.token2idx[token]

    def get_vocab_size(self):
        return len(self.token2idx)

    def __call__(self, report):
        tokens = self.clean_report(report).split()
        ids = []
        for token in tokens:
            ids.append(self.get_id_by_token(token))

        # --- [关键修复] 添加起止符 ---
        # 以前是 [0] + ids + [0] (全Pad导致NaN)
        # 现在是 [1] + ids + [2] (BOS...EOS)
        ids = [self.bos_token_id] + ids + [self.eos_token_id]
        return ids

    def encode(self, report):
        return self.__call__(report)

    def decode(self, ids):
        txt = ''
        for i, idx in enumerate(ids):
            # 解码时跳过 pad, bos, eos
            if idx in [self.pad_token_id, self.bos_token_id, self.eos_token_id]:
                continue

            if i >= 1:
                txt += ' '
            txt += self.idx2token.get(idx, '<unk>')
        return txt.strip()

    def decode_batch(self, ids_batch):
        out = []
        for ids in ids_batch:
            out.append(self.decode(ids))
        return out


class MixTokenizer(object):
    """
    [原始 MixTokenizer]
    为了兼容性保留此代码，防止 `import MixTokenizer` 报错。
    """

    def __init__(self, args):
        self.ann_path = {'iu_xray': "/root/autodl-tmp/iu_xray/annotation.json",
                         'mimic_cxr': "/root/autodl-tmp/mimic_cxr/annotation.json"}
        self.threshold = {'iu_xray': 3,
                          'mimic_cxr': 10}
        self.dataset_name = args.get('dataset_name', 'iu_xray')
        # 简单的 try-except 防止路径不存在报错
        try:
            self.ann = {'iu_xray': json.loads(open(self.ann_path['iu_xray'], 'r').read()),
                        'mimic_cxr': json.loads(open(self.ann_path['mimic_cxr'], 'r').read())}
        except Exception as e:
            print(f"Warning: MixTokenizer failed to load annotations: {e}")
            self.ann = {'iu_xray': {'train': []}, 'mimic_cxr': {'train': []}}

        self.token2idx, self.idx2token = self.create_vocabulary()

    def create_vocabulary(self):
        total_tokens_iu_xray = []
        total_tokens_mimic_cxr = []

        if 'train' in self.ann['iu_xray']:
            for example in self.ann['iu_xray']['train']:
                tokens = self.clean_report_iu_xray(example['report']).split()
                for token in tokens:
                    total_tokens_iu_xray.append(token)

        if 'train' in self.ann['mimic_cxr']:
            for example in self.ann['mimic_cxr']['train']:
                tokens = self.clean_report_mimic_cxr(example['report']).split()
                for token in tokens:
                    total_tokens_mimic_cxr.append(token)

        counter_iu_xray = Counter(total_tokens_iu_xray)
        counter_mimic_cxr = Counter(total_tokens_mimic_cxr)

        vocab = [k for k, v in counter_iu_xray.items() if v >= self.threshold['iu_xray']] + ['<unk>']
        vocab += [k for k, v in counter_mimic_cxr.items() if v >= self.threshold['mimic_cxr'] and k not in vocab]
        vocab.sort()

        token2idx, idx2token = {}, {}
        for idx, token in enumerate(vocab):
            token2idx[token] = idx + 1
            idx2token[idx + 1] = token
        return token2idx, idx2token

    def clean_report_iu_xray(self, report):
        report_cleaner = lambda t: t.replace('..', '.').replace('..', '.').replace('..', '.').replace('1. ', '') \
            .replace('. 2. ', '. ').replace('. 3. ', '. ').replace('. 4. ', '. ').replace('. 5. ', '. ') \
            .replace(' 2. ', '. ').replace(' 3. ', '. ').replace(' 4. ', '. ').replace(' 5. ', '. ') \
            .strip().lower().split('. ')
        sent_cleaner = lambda t: re.sub('[.,?;*!%^&_+():-\[\]{}]', '', t.replace('"', '').replace('/', '').
                                        replace('\\', '').replace("'", '').strip().lower())
        tokens = [sent_cleaner(sent) for sent in report_cleaner(report) if sent_cleaner(sent) != []]
        report = ' . '.join(tokens) + ' .'
        return report

    def clean_report_mimic_cxr(self, report):
        report_cleaner = lambda t: t.replace('\n', ' ').replace('__', '_').replace('__', '_').replace('__', '_') \
            .replace('__', '_').replace('__', '_').replace('__', '_').replace('__', '_').replace('  ', ' ') \
            .replace('  ', ' ').replace('  ', ' ').replace('  ', ' ').replace('  ', ' ').replace('  ', ' ') \
            .replace('..', '.').replace('..', '.').replace('..', '.').replace('..', '.').replace('..', '.') \
            .replace('..', '.').replace('..', '.').replace('..', '.').replace('1. ', '').replace('. 2. ', '. ') \
            .replace('. 3. ', '. ').replace('. 4. ', '. ').replace('. 5. ', '. ').replace(' 2. ', '. ') \
            .replace(' 3. ', '. ').replace(' 4. ', '. ').replace(' 5. ', '. ') \
            .strip().lower().split('. ')
        sent_cleaner = lambda t: re.sub('[.,?;*!%^&_+():-\[\]{}]', '', t.replace('"', '').replace('/', '')
                                        .replace('\\', '').replace("'", '').strip().lower())
        tokens = [sent_cleaner(sent) for sent in report_cleaner(report) if sent_cleaner(sent) != []]
        report = ' . '.join(tokens) + ' .'
        return report

    def get_token_by_id(self, id):
        return self.idx2token[id]

    def get_id_by_token(self, token):
        if token not in self.token2idx:
            return self.token2idx['<unk>']
        return self.token2idx[token]

    def get_vocab_size(self):
        return len(self.token2idx)

    def __call__(self, report, dataset='iu_xray'):
        if dataset == 'iu_xray':
            tokens = self.clean_report_iu_xray(report).split()
        else:
            tokens = self.clean_report_mimic_cxr(report).split()
        ids = []
        for token in tokens:
            ids.append(self.get_id_by_token(token))
        ids = [0] + ids + [0]
        return ids

    def decode(self, ids):
        txt = ''
        for i, idx in enumerate(ids):
            if idx > 0:
                if i >= 1:
                    txt += ' '
                txt += self.idx2token[idx]
            else:
                break
        return txt

    def decode_batch(self, ids_batch):
        out = []
        for ids in ids_batch:
            out.append(self.decode(ids))
        return out