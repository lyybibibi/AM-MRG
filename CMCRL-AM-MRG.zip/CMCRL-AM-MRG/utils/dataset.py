import os
import json
import torch
from PIL import Image
from PIL import ImageFile
from torch.utils.data import Dataset
import numpy as np

ImageFile.LOAD_TRUNCATED_IMAGES = True


class BaseDataset(Dataset):
    def __init__(self, args, tokenizer, split, transform=None):
        # 兼容 Namespace 和 Dict 配置
        if isinstance(args, dict):
            self.image_dir = args.get("image_dir")
            self.ann_path = args.get("ann_path")
            self.max_seq_length = args.get("max_seq_length")
            self.dataset_name = args.get("dataset_name")
            self.visual_features_dir = args.get("visual_features_dir", "")
        else:
            self.image_dir = args.image_dir
            self.ann_path = args.ann_path
            self.max_seq_length = args.max_seq_length
            self.dataset_name = getattr(args, "dataset_name", "")
            self.visual_features_dir = getattr(args, "visual_features_dir", "")

        self.split = split
        self.tokenizer = tokenizer
        self.transform = transform

        # 加载标注
        with open(self.ann_path, 'r') as f:
            self.ann = json.load(f)

        # 获取对应 split 的数据
        self.examples = self.ann[self.split]

        # 特殊数据集处理
        if self.dataset_name == 'ffa_ir':
            self.dict2list4ffair()

        # --- [核心修复] 预处理所有报告 ---
        for i in range(len(self.examples)):
            # 1. 自动查找 report 文本，防止 Key 错误
            report = self.examples[i].get('report', self.examples[i].get('caption', ""))

            # 2. 使用新版 Tokenizer 编码 (自动加 BOS/EOS)
            # 注意：新 Tokenizer 是可调用的对象
            tokenized_ids = tokenizer(report)

            # 3. 截断处理 (保留 EOS 是好的，但为了兼容性先硬截断)
            if len(tokenized_ids) > self.max_seq_length:
                tokenized_ids = tokenized_ids[:self.max_seq_length]

            self.examples[i]['ids'] = tokenized_ids
            self.examples[i]['mask'] = [1] * len(self.examples[i]['ids'])

    def __len__(self):
        return len(self.examples)

    def dict2list4ffair(self):
        examples_list = []
        for k, v in self.examples.items():
            v['id'] = k
            v['image_path'] = v.pop('Image_path')
            v['report'] = v.pop('En_Report')
            examples_list.append(v)
        self.examples = examples_list


class IuxrayMultiImageDataset(BaseDataset):
    def __getitem__(self, idx):
        example = self.examples[idx]
        image_id = example['id']
        # 确保 image_path 是列表
        image_path = example.get('image_path', [])
        if isinstance(image_path, str): image_path = [image_path]
        if not image_path: image_path = [str(image_id)]  # 兜底

        # --- [IU X-ray 专用] 读取双图特征 ---
        if self.visual_features_dir and os.path.exists(self.visual_features_dir):
            feature_list = []
            for img_name in image_path:
                file_name = os.path.splitext(os.path.basename(img_name))[0]
                feature_path = os.path.join(self.visual_features_dir, self.split, f"{file_name}.npy")
                try:
                    feat = np.load(feature_path)  # [49, 768]
                    feature_list.append(torch.from_numpy(feat))
                except Exception:
                    feature_list.append(torch.zeros(49, 768))

            if len(feature_list) == 1:
                feature_list.append(feature_list[0])
            elif len(feature_list) == 0:
                feature_list.append(torch.zeros(49, 768))
                feature_list.append(torch.zeros(49, 768))

            image = torch.stack(feature_list, dim=0).view(-1, 768)

        else:
            # --- [核心修复] 更健壮的 JPG 读取 ---
            def load_single_image(path_suffix):
                # 尝试拼接完整路径
                full_path = os.path.join(self.image_dir, path_suffix)

                # 自动尝试补全后缀
                if not os.path.exists(full_path):
                    if os.path.exists(full_path + '.png'):
                        full_path += '.png'
                    elif os.path.exists(full_path + '.jpg'):
                        full_path += '.jpg'

                try:
                    img = Image.open(full_path).convert('RGB')
                    if self.transform is not None:
                        img = self.transform(img)
                    return img
                except Exception as e:
                    # print(f"Warning: Failed to load {full_path}, using black image.")
                    return torch.zeros((3, 224, 224))

            image_1 = load_single_image(image_path[0])
            if len(image_path) > 1:
                image_2 = load_single_image(image_path[1])
            else:
                image_2 = image_1.clone()  # 复制第一张

            image = torch.stack((image_1, image_2), 0)

        report_ids = example['ids']
        report_masks = example['mask']
        seq_length = len(report_ids)

        # 返回原始定义的 5 元素元组
        sample = (image_id, image, report_ids, report_masks, seq_length)
        return sample


class MimiccxrSingleImageDataset(BaseDataset):
    def __getitem__(self, idx):
        example = self.examples[idx]
        image_id = example['id']
        image_path = example.get('image_path', [])
        if isinstance(image_path, str): image_path = [image_path]
        if not image_path: image_path = [str(image_id)]

        if self.visual_features_dir and os.path.exists(self.visual_features_dir):
            file_name = os.path.splitext(os.path.basename(image_path[0]))[0]
            feature_path = os.path.join(self.visual_features_dir, self.split, f"{file_name}.npy")
            try:
                visual_feats = np.load(feature_path)
                image = torch.from_numpy(visual_feats)
            except Exception:
                image = torch.zeros(49, 768)
        else:
            try:
                full_path = os.path.join(self.image_dir, image_path[0])
                # 后缀补全
                if not os.path.exists(full_path):
                    if os.path.exists(full_path + '.jpg'):
                        full_path += '.jpg'
                    elif os.path.exists(full_path + '.png'):
                        full_path += '.png'

                image = Image.open(full_path).convert('RGB')
            except Exception:
                image = Image.new('RGB', (224, 224), (0, 0, 0))

            if self.transform is not None:
                image = self.transform(image)

        report_ids = example['ids']
        report_masks = example['mask']
        seq_length = len(report_ids)

        sample = (image_id, image, report_ids, report_masks, seq_length)
        return sample


class MixSingleImageDataset(Dataset):
    pass