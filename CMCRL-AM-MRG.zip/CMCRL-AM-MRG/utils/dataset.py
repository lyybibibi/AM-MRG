import os
import json
import torch
from PIL import Image
from PIL import ImageFile
from torch.utils.data import Dataset
import numpy as np

ImageFile.LOAD_TRUNCATED_IMAGES = True


class BaseDataset(Dataset):
    def __init__(self, args, tokenizer, split, transform=None):
        if isinstance(args, dict):
            self.image_dir = args.get("image_dir")
            self.ann_path = args.get("ann_path")
            self.max_seq_length = args.get("max_seq_length")
            self.dataset_name = args.get("dataset_name")
            self.visual_features_dir = args.get("visual_features_dir", "")
        else:
            self.image_dir = args.image_dir
            self.ann_path = args.ann_path
            self.max_seq_length = args.max_seq_length
            self.dataset_name = getattr(args, "dataset_name", "")
            self.visual_features_dir = getattr(args, "visual_features_dir", "")

        self.split = split
        self.tokenizer = tokenizer
        self.transform = transform
        self.ann = json.loads(open(self.ann_path, 'r').read())

        self.examples = self.ann[self.split]
        if self.dataset_name == 'ffa_ir': self.dict2list4ffair()

        for i in range(len(self.examples)):
            report = self.examples[i]['report']
            tokenized_ids = tokenizer.encode(report)
            if len(tokenized_ids) > self.max_seq_length:
                tokenized_ids = tokenized_ids[:self.max_seq_length]
            self.examples[i]['ids'] = tokenized_ids
            self.examples[i]['mask'] = [1] * len(self.examples[i]['ids'])

    def __len__(self):
        return len(self.examples)

    def dict2list4ffair(self):
        examples_list = []
        for k, v in self.examples.items():
            v['id'] = k
            v['image_path'] = v.pop('Image_path')
            v['report'] = v.pop('En_Report')
            examples_list.append(v)
        self.examples = examples_list


class IuxrayMultiImageDataset(BaseDataset):
    def __getitem__(self, idx):
        example = self.examples[idx]
        image_id = example['id']
        image_path = example['image_path']  # list of filenames

        # --- [IU X-ray 专用] 读取双图特征 ---
        if self.visual_features_dir and os.path.exists(self.visual_features_dir):
            feature_list = []
            for img_name in image_path:
                file_name = os.path.splitext(os.path.basename(img_name))[0]
                feature_path = os.path.join(self.visual_features_dir, self.split, f"{file_name}.npy")
                try:
                    feat = np.load(feature_path)  # [49, 768]
                    feature_list.append(torch.from_numpy(feat))
                except Exception:
                    feature_list.append(torch.zeros(49, 768))

            # 补齐两张图
            if len(feature_list) == 1:
                feature_list.append(feature_list[0])
            elif len(feature_list) == 0:  # 极端容错
                feature_list.append(torch.zeros(49, 768))
                feature_list.append(torch.zeros(49, 768))

            # 拼接: [2, 49, 768] -> Flatten -> [98, 768]
            image = torch.stack(feature_list, dim=0).view(-1, 768)

        else:
            # 读取原始 JPG
            try:
                image_1 = Image.open(os.path.join(self.image_dir, image_path[0])).convert('RGB')
                if len(image_path) > 1:
                    image_2 = Image.open(os.path.join(self.image_dir, image_path[1])).convert('RGB')
                else:
                    image_2 = image_1
            except FileNotFoundError:
                image_1 = Image.new('RGB', (224, 224), (0, 0, 0))
                image_2 = Image.new('RGB', (224, 224), (0, 0, 0))

            if self.transform is not None:
                image_1 = self.transform(image_1)
                image_2 = self.transform(image_2)
            image = torch.stack((image_1, image_2), 0)

        report_ids = example['ids']
        report_masks = example['mask']
        seq_length = len(report_ids)
        sample = (image_id, image, report_ids, report_masks, seq_length)
        return sample


class MimiccxrSingleImageDataset(BaseDataset):
    def __getitem__(self, idx):
        example = self.examples[idx]
        image_id = example['id']
        image_path = example['image_path']

        # --- [MIMIC 专用] 读取单图特征 ---
        if self.visual_features_dir and os.path.exists(self.visual_features_dir):
            file_name = os.path.splitext(os.path.basename(image_path[0]))[0]
            feature_path = os.path.join(self.visual_features_dir, self.split, f"{file_name}.npy")
            try:
                visual_feats = np.load(feature_path)
                image = torch.from_numpy(visual_feats)
            except Exception:
                image = torch.zeros(49, 768)
        else:
            try:
                image = Image.open(os.path.join(self.image_dir, image_path[0])).convert('RGB')
            except FileNotFoundError:
                image = Image.new('RGB', (224, 224), (0, 0, 0))
            if self.transform is not None:
                image = self.transform(image)

        report_ids = example['ids']
        report_masks = example['mask']
        seq_length = len(report_ids)
        sample = (image_id, image, report_ids, report_masks, seq_length)
        return sample


class MixSingleImageDataset(Dataset):
    # (此部分保持原样或忽略，暂不使用混合数据集)
    pass