import torch
import os
import glob

# 修改成你的 checkpoint 目录
checkpoint_dir = "results/iu_xray/cmnet"
pattern = "checkpoint_epoch_*.pth"   # 匹配你的命名

files = sorted(glob.glob(os.path.join(checkpoint_dir, pattern)))

print(f"找到 {len(files)} 个 checkpoint 文件")
print("Epoch\tTrain Loss\tVal Loss\tBest Val Loss\t其他关键信息")
print("-" * 60)

for f in files:
    try:
        ckpt = torch.load(f, map_location='cpu')
        epoch = ckpt.get('epoch', '未知')
        
        # 尝试提取常见 loss 键（根据项目不同调整键名）
        train_loss = ckpt.get('train_loss', ckpt.get('loss', 'N/A'))
        val_loss = ckpt.get('val_loss', ckpt.get('valid_loss', 'N/A'))
        best_loss = ckpt.get('best_val_loss', ckpt.get('best_loss', 'N/A'))
        
        # 如果有其他指标也可以加
        bleu = ckpt.get('bleu_4', 'N/A')
        cider = ckpt.get('CIDEr', 'N/A')
        
        print(f"{epoch:4}\t{train_loss:8}\t{val_loss:8}\t{best_loss:8}\tBLEU-4: {bleu}\tCIDEr: {cider}")
        
    except Exception as e:
        print(f"文件 {os.path.basename(f)} 加载失败: {e}")