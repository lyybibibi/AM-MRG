import os
import torch
import numpy as np
import faiss
from tqdm import tqdm
import argparse
import json
from collections import OrderedDict
# 引入项目模块
from utils.dataloaders import R2DataLoader
from utils.tokenizers import Tokenizer
from models.vlci import VLCI  # 假设你用 VLCI 训练的权重，或者 Baseline


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--c', type=str, default='config/iu_xray/vlci.json', help='配置文件路径')
    parser.add_argument('--load_model_path', type=str, required=True, help='已训练好的 .pth 权重路径')
    return parser.parse_args()


def load_json_args(path):
    json_str = ''
    with open(path, 'r') as f:
        for line in f:
            # 处理 JSON 中的注释（支持 // 开头的注释）
            line = line.split('//')[0] + '\n'
            json_str += line
    defaults = json.loads(json_str, object_pairs_hook=OrderedDict)
    dict_args = {}
    # 核心逻辑：把 "data", "model", "trainer" 等子字典里的内容全部“拍平”到最外层
    for key in defaults.keys():
        dict_args.update(defaults[key])
    return dict_args


def build_index():
    args_cli = parse_args()
    args = load_json_args(args_cli.c)
    # 强制覆盖：使用训练集，不打乱，不做数据增强（为了特征稳定）
    args['load_model_path'] = args_cli.load_model_path

    # 1. 初始化
    print("正在初始化模型和数据加载器...")
    tokenizer = Tokenizer(args)
    # ================= 🚑 修正后的终极补丁 =================
    # 我们不再检查 tokenizer 对象的属性，而是直接检查和修改 args 配置
    # 这是控制模型 Embedding 层大小的唯一真理
    TARGET_VOCAB_SIZE = 4348

    # 这里的键名通常是 "vocab_size"
    if args.get('vocab_size') != TARGET_VOCAB_SIZE:
        print(f"\n[Auto-Fix] 强制同步词表大小: {args.get('vocab_size')} -> {TARGET_VOCAB_SIZE}")
        args['vocab_size'] = TARGET_VOCAB_SIZE

    # 为了防止某些特殊写法的 model 确实去读 tokenizer.vocab_size，我们手动给它挂一个属性
    tokenizer.vocab_size = TARGET_VOCAB_SIZE
    # ================= 🚑 补丁结束 =================

    model = VLCI(args, tokenizer).cuda()

    # 2. 加载权重
    print(f"加载权重: {args['load_model_path']}")
    checkpoint = torch.load(args['load_model_path'], map_location='cpu')
    # 这里的 strict=False 是为了防止一些不匹配，通常没问题
    model.load_state_dict(checkpoint['state_dict'], strict=False)
    model.eval()

    # 3. 提取特征
    print("开始提取全量训练集特征...")
    all_feats = []
    all_report_ids = []

    with torch.no_grad():
        for batch in tqdm(dataloader):
            # images: [B, 3, 224, 224]
            image_ids, images, report_ids, report_masks = batch
            images = images.cuda()

            # --- 关键点：获取特征 ---
            # VLCI/Baseline 的 vis_embed 返回的是 [B, L, D] (序列特征)
            # 我们需要一个全局向量 [B, D] 来做检索

            # 1. 提取序列特征
            patch_feats = model.vis_embed(images)  # [B, 49, 512] 假设 7x7 patches

            # 2. 全局池化 (Mean Pooling)
            # 这一步把一张图变成一个 512 维的向量
            global_feat = patch_feats.mean(dim=1)

            # 3. L2 归一化 (这对于计算余弦相似度至关重要)
            global_feat = torch.nn.functional.normalize(global_feat, p=2, dim=1)

            all_feats.append(global_feat.cpu().numpy())

            # 收集对应的报告 Token ID，用于后续检索到特征后查阅文本
            # 注意：需将其转为 numpy 列表
            # 这里简单处理，实际应用可能需要存原始文本
            all_report_ids.extend(report_ids.numpy())

    # 4. 构建 Faiss 索引
    all_feats = np.concatenate(all_feats, axis=0)  # [N, 512]
    print(f"特征提取完毕，形状: {all_feats.shape}")

    # 使用内积索引 (Inner Product)。因为特征已经归一化，内积等价于余弦相似度
    index = faiss.IndexFlatIP(all_feats.shape[1])
    index.add(all_feats)

    # 5. 保存
    save_dir = 'data/index'
    os.makedirs(save_dir, exist_ok=True)

    index_path = os.path.join(save_dir, f"{args['dataset_name']}_train.index")
    reports_path = os.path.join(save_dir, f"{args['dataset_name']}_reports.npy")

    faiss.write_index(index, index_path)
    np.save(reports_path, np.array(all_report_ids, dtype=object))

    print(f"索引已保存至: {index_path}")
    print("下一步：可以去实现 'Hard Negative Mining' 了！")


if __name__ == '__main__':
    build_index()