import os
# 设置国内镜像源
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
from huggingface_hub import snapshot_download

print("开始下载 bert-base-uncased 到本地目录...")
snapshot_download(
    repo_id="bert-base-uncased",
    local_dir="/root/projects/CMCRL-main/bert-base-uncased",
    ignore_patterns=["*.h5", "*.ot", "*.msgpack"], # 只下载 pytorch 权重
    local_dir_use_symlinks=False
)
print("下载完成！")