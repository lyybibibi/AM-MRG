"""
trainer
"""
from .BaseTrainer import Trainer
from .PretrainTrainer import Trainer as PTrainer
from .FinetuneTrainer import Trainer as FTrainer

