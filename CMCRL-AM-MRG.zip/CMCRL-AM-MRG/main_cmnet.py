import torch
import argparse
import numpy as np
import os
import random
import json
from tqdm import tqdm
from torch.optim import AdamW
from torch.optim.lr_scheduler import StepLR
from transformers import AutoTokenizer
from collections import OrderedDict
# --- [修改1] 引入 wandb ---
import wandb

from models.cmnet import CMNet
from utils.dataloaders import R2DataLoader
import os  # <--- 确保引入 os

# 【新增】直接设置环境变量，跳过交互登录
# 请把引号里的内容替换为您刚才复制的 API Key
os.environ["WANDB_API_KEY"] = "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"
# 例如: os.environ["WANDB_API_KEY"] = "7d8f9a2b3c4d5e6f..."

def set_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True


def load_json_args(path):
    json_str = ''
    with open(path, 'r') as f:
        for line in f:
            line = line.split('//')[0] + '\n'
            json_str += line
    defaults = json.loads(json_str, object_pairs_hook=OrderedDict)
    dict_args = {}
    is_nested = any(isinstance(v, dict) for v in defaults.values())
    if is_nested:
        for key, value in defaults.items():
            if isinstance(value, dict):
                dict_args.update(value)
            else:
                dict_args[key] = value
    else:
        dict_args = defaults
    return dict_args


def initialize_memory_bank(model, data_loader, device):
    model.eval()
    print(f"[Memory Init] Start initializing Memory Bank...")
    all_features = []
    total_stored = 0
    target_size = model.vdm.memory_bank.size(0)

    with torch.no_grad():
        for i, batch in enumerate(tqdm(data_loader)):
            if isinstance(batch, (list, tuple)):
                images = batch[1].to(device)
            else:
                images = batch['images'].to(device)
            features = images.view(-1, images.size(-1))
            all_features.append(features.cpu())
            total_stored += features.size(0)
            if total_stored >= target_size * 2:
                break
    if len(all_features) > 0:
        all_features = torch.cat(all_features, dim=0)
        model.vdm.update_memory(all_features)
    else:
        print("Warning: No features collected for memory bank!")


def train_one_epoch(model, data_loader, optimizer, epoch, device, args):
    model.train()
    total_loss = 0
    acc_steps = getattr(args, 'accumulation_steps', 1)
    optimizer.zero_grad()

    pbar = tqdm(data_loader, desc=f"Epoch {epoch}")
    for step, batch in enumerate(pbar):
        if isinstance(batch, (list, tuple)):
            visual_tokens = batch[1].to(device)
            input_ids = batch[2].to(device)
            attention_mask = batch[3].to(device)
        else:
            visual_tokens = batch['images'].to(device)
            input_ids = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)

        loss = model(visual_tokens, input_ids, attention_mask, mode='train')
        loss = loss / acc_steps
        loss.backward()

        if (step + 1) % acc_steps == 0:
            optimizer.step()
            optimizer.zero_grad()

        total_loss += loss.item() * acc_steps

        # --- [修改2] 实时记录 Step Loss 到 wandb (可选) ---
        # wandb.log({"loss_step": loss.item() * acc_steps})

        pbar.set_postfix({'loss': f"{total_loss / (step + 1):.4f}"})

    return total_loss / len(data_loader)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--c', type=str, required=True, help='config file path')
    args_cli = parser.parse_args()

    args_dict = load_json_args(args_cli.c)
    args = argparse.Namespace(**args_dict)

    # --- [修改3] 初始化 wandb ---
    # project: 项目名称 (在网页上显示的大分类)
    # name: 本次实验名称 (例如 lr=3e-5)
    # config: 自动把您的参数上传，方便以后查看这次用了什么参数
    wandb.init(
        project="CMCRL-IU-Xray",
        name=f"lr_{args.lr}_ep_{args.epochs}",
        config=args_dict
    )

    set_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"Loading Tokenizer from {args.llm_path} ...")
    tokenizer = AutoTokenizer.from_pretrained(args.llm_path, use_fast=False)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    print("Creating DataLoaders...")
    train_dataloader = R2DataLoader(args, tokenizer, split='train', shuffle=True)

    print("Building Model...")
    model = CMNet(args, tokenizer)
    model.to(device)

    initialize_memory_bank(model, train_dataloader, device)

    trainable_params = list(model.vdm.parameters()) + list(model.proj.parameters())
    optimizer = AdamW(trainable_params, lr=float(args.lr), weight_decay=float(args.weight_decay))
    scheduler = StepLR(optimizer, step_size=args.step_size, gamma=args.gamma)

    print("Start Training...")
    for epoch in range(1, args.epochs + 1):
        loss = train_one_epoch(model, train_dataloader, optimizer, epoch, device, args)
        current_lr = optimizer.param_groups[0]['lr']

        print(f"Epoch {epoch} Loss: {loss:.4f} | LR: {current_lr}")

        # --- [修改4] 每个 Epoch 结束上传数据 ---
        wandb.log({
            "epoch": epoch,
            "loss_train": loss,
            "learning_rate": current_lr
        })

        scheduler.step()

        if epoch % args.save_period == 0:
            save_path = os.path.join(args.save_dir, f"checkpoint_epoch_{epoch}.pth")
            if not os.path.exists(args.save_dir):
                os.makedirs(args.save_dir)

            state_dict = model.state_dict()
            trainable_state_dict = {k: v for k, v in state_dict.items() if "llm" not in k}
            torch.save(trainable_state_dict, save_path)
            print(f"Saved checkpoint: {save_path}")

    # --- [修改5] 结束 wandb ---
    wandb.finish()


if __name__ == '__main__':
    main()