import os
import torch
import numpy as np
from torch.utils.data import DataLoader
from tqdm import tqdm
from sklearn.cluster import MiniBatchKMeans
import argparse
from torchvision import transforms
from PIL import Image
import json
import types
from functools import partial
from unittest.mock import MagicMock
import transformers

# --- 1. 导入项目模块 ---
try:
    from utils.dataset import IuxrayMultiImageDataset, MimiccxrSingleImageDataset
except ImportError:
    from utils.dataloaders import IuxrayMultiImageDataset, MimiccxrSingleImageDataset
from utils.tokenizers import Tokenizer


# --- 2. 物理读取补丁 ---
def universal_vlci_collate_fn(batch, image_dir, transform):
    aligned_images = []
    for item in batch:
        raw_data = item[0]
        processed_imgs = []
        if isinstance(raw_data, (str, list)):
            path_list = [raw_data] if isinstance(raw_data, str) else raw_data
            for p in path_list:
                full_path = os.path.join(image_dir, p)
                if not os.path.exists(full_path):
                    for ext in ['.png', '.jpg', '.jpeg']:
                        if os.path.exists(full_path + ext):
                            full_path = full_path + ext;
                            break
                try:
                    img = Image.open(full_path).convert('RGB')
                    processed_imgs.append(transform(img))
                except:
                    continue
        elif isinstance(raw_data, torch.Tensor):
            processed_imgs = [img for img in (raw_data if raw_data.ndim == 4 else raw_data.unsqueeze(0))]

        if len(processed_imgs) == 0:
            final_tensor = torch.zeros((2, 3, 224, 224))
        elif len(processed_imgs) == 1:
            final_tensor = torch.stack([processed_imgs[0], processed_imgs[0]], dim=0)
        else:
            final_tensor = torch.stack(processed_imgs[:2], dim=0)
        aligned_images.append(final_tensor)
    return torch.stack(aligned_images, dim=0)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image_dir', type=str, required=True)
    parser.add_argument('--ann_path', type=str, required=True)
    parser.add_argument('--dataset_name', type=str, default='iu_xray')
    parser.add_argument('--checkpoint', type=str, default='/root/autodl-tmp/Stage1ckpt.pth')
    parser.add_argument('--save_path', type=str, default='visual_memory_bank_iu.npy')
    parser.add_argument('--cfg', type=str, required=True)
    parser.add_argument('--n_clusters', type=int, default=2048)
    parser.add_argument('--batch_size', type=int, default=8)
    parser.add_argument('--num_workers', type=int, default=4)
    args = parser.parse_args()

    device = torch.device('cuda')

    # 配置劫持
    import SwinCheX.config as swin_config_module
    from yacs.config import CfgNode as CN
    def patched_update_config(config, args_obj):
        config.defrost()
        if not hasattr(config, 'NIH'): config.NIH = CN()
        config.NIH.num_mlp_heads = 1
        config.NIH.num_classes = 14
        config.freeze()
        return config

    swin_config_module.update_config = patched_update_config

    with open(args.cfg, 'r') as f:
        full_config = json.load(f)

    tok_config = full_config['data'].copy()
    tok_config.update({'threshold': 3, 'ann_path': args.ann_path, 'dataset_name': args.dataset_name})
    tokenizer = Tokenizer(tok_config)
    tokenizer.encode = tokenizer.__call__

    # 初始化 CMNet
    transformers.AutoModelForCausalLM.from_pretrained = classmethod(lambda *a, **k: torch.nn.Module())
    transformers.AutoConfig.from_pretrained = classmethod(lambda *a, **k: MagicMock(hidden_size=4096))
    for k, v in full_config['model'].items(): setattr(args, k, v)
    from models.cmnet import CMNet
    model = CMNet(args, tokenizer)

    if os.path.exists(args.checkpoint):
        ckpt = torch.load(args.checkpoint, map_location='cpu')
        sd = ckpt.get('state_dict', ckpt)
        new_sd = {(k[7:] if k.startswith('module.') else k): v for k, v in sd.items() if 'llm' not in k}
        model.load_state_dict(new_sd, strict=False)

    model = model.to(device).eval()

    val_transform = transforms.Compose([
        transforms.Resize((224, 224)), transforms.ToTensor(),
        transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
    ])
    dataset = IuxrayMultiImageDataset(tok_config, tokenizer, split='train', transform=val_transform)
    my_collate = partial(universal_vlci_collate_fn, image_dir=args.image_dir, transform=val_transform)
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers,
                        collate_fn=my_collate)

    # 将 n_init 设为 1，因为 partial_fit 是增量更新，不需要多次初始化
    # VLCI 流式聚类：将 n_init 设为 1 解决之前的 TypeError
    kmeans = MiniBatchKMeans(n_clusters=args.n_clusters, batch_size=2048, random_state=42, n_init=1)

    print(f">>> [VLCI] 正在通过流式采样构建视觉记忆库 Z...")

    # 用于缓存初始样本的列表
    init_buffer = []
    initialized = False

    with torch.no_grad():
        for images in tqdm(loader):
            B = images.shape[0]
            V = images.shape[1]
            images = images.to(device).view(B * V, 3, 224, 224)

            # --- 1. 物理穿透 Swin 流程 ---
            ve = model.visual_encoder
            x = ve.patch_embed(images)
            if getattr(ve, 'ape', False): x = x + ve.absolute_pos_embed
            x = ve.pos_drop(x)
            for layer in ve.layers: x = layer(x)
            v_feat = ve.norm(x)  # [B*V, 49, 768]

            # --- 2. 维度对齐与 Mining ---
            v_feat = v_feat.contiguous().view(B, -1, 768)
            m_feat = model.visual_mining(v_feat)  # 提取中介因子 M

            # --- 3. 样本收集与聚类逻辑 (解决 n_samples < n_clusters) ---
            flat_m = m_feat.reshape(-1, m_feat.size(-1)).cpu().numpy()

            if not initialized:
                init_buffer.append(flat_m)
                current_total = np.concatenate(init_buffer, axis=0)
                if current_total.shape[0] >= args.n_clusters:
                    # 样本够了，执行第一次 fit
                    kmeans.partial_fit(current_total)
                    initialized = True
                    init_buffer = []  # 清空缓存
                    print(f"\n>>> [VLCI] 聚类中心已初始化 (已收集 {current_total.shape[0]} 个样本)")
            else:
                # 已经初始化过了，直接增量更新
                kmeans.partial_fit(flat_m)

    # 4. 保存
    np.save(args.save_path, kmeans.cluster_centers_)
    print(f"\n>>> [Success] 视觉记忆库 Z 已成功保存至: {args.save_path}")


if __name__ == '__main__':
    main()
