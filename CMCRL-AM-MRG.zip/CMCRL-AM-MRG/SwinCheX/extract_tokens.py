import os
import argparse
import torch
import numpy as np
import torch.distributed as dist  # [新增] 引入分布式库
from tqdm import tqdm
from models import build_model
from data.build import build_loader
from config import get_config


def parse_option():
    parser = argparse.ArgumentParser('SwinCheX Token Extraction script', add_help=False)

    # 核心参数
    parser.add_argument('--cfg', type=str, required=True, metavar="FILE", help='path to config file')
    parser.add_argument("--opts", help="Modify config options", default=None, nargs='+')
    parser.add_argument('--resume', help='resume from checkpoint', required=True)
    parser.add_argument('--batch-size', type=int, default=32, help="batch size")
    parser.add_argument('--data-path', type=str, help='path to dataset')
    parser.add_argument('--output-dir', type=str, required=True, help='path to save .npy features')
    parser.add_argument('--tag', help='tag of experiment')
    parser.add_argument('--eval', action='store_true', help='Perform evaluation only')
    parser.add_argument('--throughput', action='store_true', help='Test throughput only')

    # --- 补全 config.py 需要的参数 ---
    parser.add_argument('--zip', action='store_true', help='use zipped dataset instead of folder dataset')
    parser.add_argument('--cache-mode', type=str, default='part', choices=['no', 'full', 'part'],
                        help='no: no cache, full: cache all data, part: sharding the dataset into nonoverlapping pieces')
    parser.add_argument('--accumulation-steps', type=int, help="gradient accumulation steps")
    parser.add_argument('--use-checkpoint', action='store_true',
                        help="whether to use gradient checkpointing to save memory")
    parser.add_argument('--amp-opt-level', type=str, default='O1', choices=['O0', 'O1', 'O2'],
                        help='mixed precision opt level, if O0, no amp is used')
    parser.add_argument('--output', default='output', type=str, metavar='PATH',
                        help='root of output folder, the full path is <output>/<model_name>/<tag> (default: output)')
    parser.add_argument('--qformer', action='store_true', help='Using Q-Former')
    parser.add_argument('--local_rank', type=int, default=0, help='local rank for DistributedDataParallel')

    # NIH/MIMIC 特定参数
    parser.add_argument('--trainset', type=str, default='')
    parser.add_argument('--validset', type=str, default='')
    parser.add_argument('--testset', type=str, default='')
    parser.add_argument('--train_csv_path', type=str, default='/root/projects/CMCRL-main/SwinCheX/configs/mimic_chexpert_train.csv')
    parser.add_argument('--valid_csv_path', type=str, default='/root/projects/CMCRL-main/SwinCheX/configs/mimic_chexpert_val.csv')
    parser.add_argument('--test_csv_path', type=str, default='/root/projects/CMCRL-main/SwinCheX/configs/mimic_chexpert_test.csv')
    parser.add_argument('--num_mlp_heads', type=int, default=3)

    args = parser.parse_args()
    config = get_config(args)
    return args, config


def extract_features(data_loader, model, output_dir):
    model.eval()
    print(f"Start extracting features to {output_dir} ...")

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    with torch.no_grad():
        for idx, batch_data in enumerate(tqdm(data_loader)):
            # 兼容性解包
            if len(batch_data) == 3:
                images, targets, paths = batch_data
            elif len(batch_data) == 2:
                print("Error: DataLoader only returned 2 values. Please modify custom_image_folder.py to return path!")
                return
            else:
                # 某些情况下 DataLoader 可能返回 index 等其他信息
                images, targets, paths = batch_data[0], batch_data[1], batch_data[2]

            images = images.cuda(non_blocking=True)

            # 1. 获取特征
            if hasattr(model, 'module'):
                features = model.module.forward_features(images)
            else:
                features = model.forward_features(images)

            features = features.cpu().numpy()  # [B, L, C]

            # 2. 按文件名保存
            for i in range(features.shape[0]):
                if isinstance(paths[i], (list, tuple)):
                    p = paths[i][0]
                else:
                    p = paths[i]

                file_name = os.path.splitext(os.path.basename(str(p)))[0]
                save_path = os.path.join(output_dir, f"{file_name}.npy")
                np.save(save_path, features[i])

    print(f"Finished. Features saved in {output_dir}")


def main():
    # [核心修复] 初始化单卡分布式环境
    # build_loader 依赖 dist.get_rank()，所以必须初始化
    if not dist.is_initialized():
        os.environ['MASTER_ADDR'] = 'localhost'
        os.environ['MASTER_PORT'] = '12355'
        # 如果有 GPU 用 nccl，没有用 gloo
        backend = 'nccl' if torch.cuda.is_available() else 'gloo'
        dist.init_process_group(backend=backend, rank=0, world_size=1)

    args, config = parse_option()

    # 1. 构建 Loader
    res = build_loader(config)
    # build_loader 返回: (dataset_train, dataset_val, dataset_test, loader_train, loader_val, loader_test, mixup)
    data_loader_train = res[3]
    data_loader_val = res[4]
    data_loader_test = res[5]

    # 2. 构建模型
    print(f"Creating model: {config.MODEL.NAME}")
    model = build_model(config)
    model.cuda()

    # 3. 加载权重
    print(f"Loading checkpoint from {config.MODEL.RESUME} ...")
    if os.path.isfile(config.MODEL.RESUME):
        checkpoint = torch.load(config.MODEL.RESUME, map_location='cpu')

        if 'model' in checkpoint:
            state_dict = checkpoint['model']
        else:
            state_dict = checkpoint

        msg = model.load_state_dict(state_dict, strict=False)
        print(f"Load status: {msg}")
    else:
        print(f"Error: Checkpoint file {config.MODEL.RESUME} not found!")
        return

    # 4. 执行提取
    # 提取测试集
    if data_loader_test:
        print("Extracting Test Set...")
        extract_features(data_loader_test, model, os.path.join(args.output_dir, 'test'))

    # 提取验证集
    if data_loader_val:
        print("Extracting Val Set...")
        extract_features(data_loader_val, model, os.path.join(args.output_dir, 'val'))

    # 提取训练集
    if data_loader_train:
        print("Extracting Train Set...")
        extract_features(data_loader_train, model, os.path.join(args.output_dir, 'train'))


if __name__ == '__main__':
    main()