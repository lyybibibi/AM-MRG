import json
import pandas as pd
import os

# ================= 配置 =================
# 1. IU X-ray 的标注文件路径
ANN_PATH = '/root/autodl-tmp/iu_xray/annotation.json'

# 2. IU X-ray 的图片根目录 (请务必确认这个路径是正确的！)
# 通常是 /root/autodl-tmp/iu_xray/images
IMAGE_ROOT = '/root/autodl-tmp/iu_xray/images'

# 3. 输出目录
OUTPUT_DIR = 'configs'


# =======================================

def generate_csv():
    if not os.path.exists(ANN_PATH):
        print(f"Error: 找不到标注文件 {ANN_PATH}")
        return

    print(f"Reading {ANN_PATH}...")
    with open(ANN_PATH, 'r') as f:
        data = json.load(f)

    # SwinCheX 需要至少一列标签列 (用 0 填充)
    dummy_labels = [0] * 14
    cols = ["Image Index"] + [f"Label_{i}" for i in range(14)]

    for split in ['train', 'val', 'test']:
        rows = []
        if split not in data:
            continue

        print(f"Processing {split} set...")
        for example in data[split]:
            image_paths = example.get('image_path', [])

            for img_name in image_paths:
                # 核心修正：直接在这里拼接成绝对路径
                # 这样 DataLoader 读取到的就是完整路径，不会再拼错
                full_path = os.path.join(IMAGE_ROOT, img_name)

                # 检查文件是否存在，不存在就不写进 CSV，防止报错
                if os.path.exists(full_path):
                    rows.append([full_path] + dummy_labels)
                else:
                    print(f"Warning: Image not found: {full_path}")

        # 保存 CSV
        df = pd.DataFrame(rows, columns=cols)
        save_path = os.path.join(OUTPUT_DIR, f'iuxray_{split}.csv')
        df.to_csv(save_path, index=False)
        print(f"[{split}] Saved {len(df)} images to {save_path}")


if __name__ == '__main__':
    generate_csv()