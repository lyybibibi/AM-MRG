import json
import pandas as pd
import os

# ================= 配置区域 =================
# 1. 下载好的标签文件路径 (来自 AM-MRG)
json_file_path = '/root/autodl-tmp/mimic_chexpert_label.json'

# 2. 您本地 MIMIC-CXR 图片的根目录
# 请修改为您实际存放图片的路径，例如: 'data/mimic_cxr/images'
# 确保该目录下能通过 "p10/p10000032/..." 这种结构找到图片
image_root_dir = '/root/autodl-tmp/mimic_cxr/images'

# 3. 输出路径 (生成的CSV将保存在 configs 目录下)
output_dir = 'configs'
if not os.path.exists(output_dir):
    os.makedirs(output_dir)
# ===========================================

# 定义 CSV 列名 (对应 CheXpert 的14个病症 + Image Path)
columns = [
    "Image Index", "Enlarged Cardiomediastinum", "Cardiomegaly", "Lung Opacity", "Lung Lesion",
    "Edema", "Consolidation", "Pneumonia", "Atelectasis", "Pneumothorax",
    "Pleural Effusion", "Pleural Other", "Fracture", "Support Devices", "No Finding"
]


def process_data(data_list, split_name):
    processed_list = []
    missing_count = 0

    for item in data_list:
        # 1. 获取相对路径
        # 原 JSON 中的 image_path 通常是一个列表，如 ["p10/p10000032/s50414267/view1_frontal.jpg"]
        # 有些版本可能是绝对路径，我们需要取相对部分
        raw_path = item['image_path'][0]

        # 这里的处理取决于 mimic_chexpert_label.json 里的具体格式
        # 假设它是 "files/p10/..." 或 "p10/..."
        # 我们只保留 "p10/..." 之后的部分
        if 'files/' in raw_path:
            rel_path = raw_path.split('files/')[-1]
        else:
            rel_path = raw_path

        # 2. 拼接您的本地根目录
        full_path = os.path.join(image_root_dir, rel_path)

        # (可选) 检查文件是否存在，防止训练报错
        # if not os.path.exists(full_path):
        #     missing_count += 1
        #     continue

        # 3. 获取标签
        label = item['label']

        # 组合数据: [路径, 标签1, 标签2, ...]
        processed_list.append([full_path] + label)

    print(f"[{split_name}] Processed {len(processed_list)} images.")
    if missing_count > 0:
        print(f"[{split_name}] Warning: {missing_count} images not found locally.")

    return pd.DataFrame(processed_list, columns=columns)


# 读取 JSON
print(f"Loading {json_file_path}...")
with open(json_file_path, 'r') as f:
    data = json.load(f)

# 处理并保存
splits = ['train', 'val', 'test']
for split in splits:
    if split in data:
        df = process_data(data[split], split)
        save_path = os.path.join(output_dir, f'mimic_chexpert_{split}.csv')
        df.to_csv(save_path, index=False)
        print(f"Saved: {save_path}")

print("\nDone! 现在可以使用生成的 CSV 进行训练了。")