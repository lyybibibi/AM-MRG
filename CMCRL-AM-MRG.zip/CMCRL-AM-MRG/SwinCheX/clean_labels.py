import pandas as pd
import os

# 定义 CSV 文件所在的目录
CSV_DIR = 'configs'

# 定义文件名列表
files = ['mimic_chexpert_train.csv', 'mimic_chexpert_val.csv', 'mimic_chexpert_test.csv']


def clean_csv():
    print("开始清洗标签文件中的 -1.0 值...")

    for filename in files:
        path = os.path.join(CSV_DIR, filename)
        if not os.path.exists(path):
            print(f"警告: 找不到文件 {path}，跳过。")
            continue

        # 读取 CSV
        df = pd.read_csv(path)

        # 1. 检查是否存在 -1
        # 我们只检查标签列（排除第一列 Image Index）
        label_cols = df.columns[1:]

        # 统计 -1 的数量
        count_uncertain = (df[label_cols] == -1).sum().sum()

        if count_uncertain > 0:
            print(f"[{filename}] 发现 {count_uncertain} 个 '-1' (Uncertain) 标签。")

            # 2. 执行替换: -1.0 -> 0.0 (U-Zeros 策略)
            # 也可以改为 .replace(-1, 1) 使用 U-Ones 策略
            df[label_cols] = df[label_cols].replace(-1, 0)
            df[label_cols] = df[label_cols].replace(-1.0, 0.0)

            # 3. 确保所有标签都是 0 或 1 的浮点数
            # 这一步是为了防止后续类型错误
            df[label_cols] = df[label_cols].astype(float)

            # 4. 保存回原文件
            df.to_csv(path, index=False)
            print(f"[{filename}] 已修复并保存。")
        else:
            print(f"[{filename}] 标签正常，无需修改。")


if __name__ == '__main__':
    clean_csv()