import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm
import argparse
import os
import json
import numpy as np
from torch.optim import Adam
from torchvision import transforms
from PIL import Image

# 导入项目组件
from models.cmnet import CMNet
from utils.tokenizers import Tokenizer

# 强制开启 CUDA 调试
os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

# 兼容性导入
try:
    from utils.dataset import IuxrayMultiImageDataset
except ImportError:
    pass


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--image_dir', type=str, required=True)
    parser.add_argument('--ann_path', type=str, required=True)
    parser.add_argument('--cfg', type=str, required=True)
    parser.add_argument('--checkpoint', type=str, required=True)
    parser.add_argument('--vis_mem_path', type=str, default='visual_memory_bank_iu.npy')
    parser.add_argument('--lr', type=float, default=5e-5)
    parser.add_argument('--epochs', type=int, default=50)
    parser.add_argument('--batch_size', type=int, default=2)  # 默认设为2防止OOM
    parser.add_argument('--save_dir', type=str, default='checkpoints/stage2')
    args = parser.parse_args()

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f">>> [System] Training on device: {device}")

    # 加载配置
    with open(args.cfg, 'r') as f:
        full_config = json.load(f)

    # 劫持 Swin 配置
    import SwinCheX.config as swin_config_module
    from yacs.config import CfgNode as CN
    def patched_update_config(config, args_obj):
        config.defrost()
        if not hasattr(config, 'NIH'): config.NIH = CN()
        config.NIH.num_mlp_heads = 1
        config.NIH.num_classes = 14
        config.freeze()
        return config

    swin_config_module.update_config = patched_update_config

    # 初始化 Tokenizer
    data_config = full_config['data']
    data_config["threshold"] = data_config.get("threshold", 3)
    data_config["ann_path"] = args.ann_path

    print(">>> [Tokenizer] Building Vocabulary...")
    tokenizer = Tokenizer(data_config)
    if not hasattr(tokenizer, 'encode'): tokenizer.encode = tokenizer.__call__

    vocab_len = len(tokenizer.token2idx)
    print(f">>> [Tokenizer] Vocab Size: {vocab_len}")

    # 初始化模型
    for k, v in full_config['model'].items():
        setattr(args, k, v)

    model = CMNet(args, tokenizer)

    # 修正 Embedding
    if model.tgt_embed.num_embeddings != vocab_len:
        print(f">>> [Model Fix] Resizing Embedding from {model.tgt_embed.num_embeddings} to {vocab_len}")
        d_model = getattr(args, 'd_model', 768)
        model.tgt_embed = nn.Embedding(vocab_len, d_model).to(device)
        model.fc_out = nn.Linear(d_model, vocab_len).to(device)

    # 加载权重
    if os.path.exists(args.checkpoint):
        print(f">>> [VLCI] 继承 Stage 1 权重: {args.checkpoint}")
        ckpt = torch.load(args.checkpoint, map_location='cpu')
        state_dict = ckpt.get('state_dict', ckpt)
        new_sd = {k.replace('module.', ''): v for k, v in state_dict.items() if 'llm' not in k}
        model.load_state_dict(new_sd, strict=False)

    model = model.to(device)

    # 数据准备
    val_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
    ])

    train_dataset = IuxrayMultiImageDataset(data_config, tokenizer, split='train', transform=val_transform)

    # --- 强力 Collate Function ---
    def causal_collate_fn(batch):
        from torch.utils.data.dataloader import default_collate
        max_seq_len = 60
        new_batch = []
        pad_id = 0

        for item in batch:
            # item结构: (id, image, report_ids, mask, seq_len)
            # 我们需要 item[1] (Image) 和 item[2] (Report IDs)
            img_tensor = item[1]
            report_ids = item[2]

            # 报告处理：截断/填充
            if len(report_ids) > max_seq_len:
                report_ids = report_ids[:max_seq_len]
            else:
                report_ids = report_ids + [pad_id] * (max_seq_len - len(report_ids))

            new_batch.append((img_tensor, torch.LongTensor(report_ids)))

        return default_collate(new_batch)

    train_loader = DataLoader(
        train_dataset, batch_size=args.batch_size, shuffle=True,
        num_workers=4, collate_fn=causal_collate_fn, drop_last=True
    )

    optimizer = Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=args.lr)
    criterion = nn.CrossEntropyLoss(ignore_index=0)

    print(f">>> [Stage 2] Training Start (Batch Size: {args.batch_size})...")

    for epoch in range(args.epochs):
        model.train()
        model.visual_encoder.eval()
        pbar = tqdm(train_loader, desc=f"Epoch {epoch + 1}")

        for batch_idx, batch in enumerate(pbar):
            optimizer.zero_grad()

            # 数据解包
            images = batch[0].to(device)
            reports = batch[1].to(device)

            # Debug: 打印一次形状，确认数据对了
            if batch_idx == 0:
                tqdm.write(f"\n[Debug] Batch 0 Images: {images.shape}, Reports: {reports.shape}")
                tqdm.write(f"[Debug] Reports Sample: {reports[0][:10].tolist()}...")

            # 钳位
            if reports.max() >= vocab_len:
                reports = torch.clamp(reports, max=vocab_len - 1)

            inputs = reports[:, :-1]
            targets = reports[:, 1:]

            # 跳过空数据
            if (targets != 0).sum() == 0:
                continue

            # --- [关键修改] 移除 try-except，让错误直接爆出来 ---
            # 前向传播
            logits = model(images, targets=inputs, mode='train')

            # Loss 计算
            loss = criterion(logits.reshape(-1, vocab_len), targets.reshape(-1))

            if torch.isnan(loss):
                tqdm.write(f"!!! [NaN Error] Batch {batch_idx} Loss is NaN")
                # 这里不 continue，让它反向传播报错，或者直接停下来检查
                break

                # 反向传播
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            # 更新进度条
            pbar.set_postfix({"Loss": f"{loss.item():.4f}"})

        # 保存模型
        if (epoch + 1) % 5 == 0:
            os.makedirs(args.save_dir, exist_ok=True)
            path = f"{args.save_dir}/epoch_{epoch + 1}.pth"
            torch.save(model.state_dict(), path)
            print(f">>> Model saved: {path}")


if __name__ == '__main__':
    main()