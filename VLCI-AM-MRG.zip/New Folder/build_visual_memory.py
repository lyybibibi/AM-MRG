import os
import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm
from sklearn.cluster import MiniBatchKMeans
import argparse
from torchvision import transforms
from PIL import Image
import json
import types
from functools import partial
from unittest.mock import MagicMock
import transformers
from utils.tokenizers import Tokenizer


# ==============================================================================
# [核心修复] 专用的混合提取 Dataset (完美替代 utils/dataset.py)
# ==============================================================================
class MixedExtractionDataset(Dataset):
    def __init__(self, iu_ann_path, iu_image_dir, mimic_ann_path, mimic_image_dir, transform):
        self.transform = transform
        self.samples = []

        # 1. 加载 IU X-ray 数据
        print(f"Loading IU X-ray from: {iu_ann_path}")
        with open(iu_ann_path, 'r') as f:
            iu_data = json.load(f)
            # 兼容 split 结构
            if isinstance(iu_data, dict) and 'train' in iu_data: iu_data = iu_data['train']

        for item in iu_data:
            # 标记来源为 IU，方便后面找图
            self.samples.append({
                'source': 'iu',
                'root': iu_image_dir,
                'paths': item.get('image_path', [])
            })

        # 2. 加载 MIMIC-CXR 数据
        print(f"Loading MIMIC-CXR from: {mimic_ann_path}")
        with open(mimic_ann_path, 'r') as f:
            mimic_data = json.load(f)
            if isinstance(mimic_data, dict) and 'train' in mimic_data: mimic_data = mimic_data['train']

        for item in mimic_data:
            self.samples.append({
                'source': 'mimic',
                'root': mimic_image_dir,
                'paths': item.get('image_path', [])
            })

        print(f"Total samples: {len(self.samples)} (IU + MIMIC)")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        item = self.samples[index]
        image_root = item['root']
        path_list = item['paths']

        # 统一转 list
        if isinstance(path_list, str): path_list = [path_list]

        images = []
        for p in path_list:
            try:
                # 拼接绝对路径
                full_path = os.path.join(image_root, p)

                # 容错：如果找不到，尝试加后缀
                if not os.path.exists(full_path):
                    for ext in ['.jpg', '.png', '.jpeg']:
                        if os.path.exists(full_path + ext):
                            full_path = full_path + ext
                            break

                if os.path.exists(full_path):
                    img = Image.open(full_path).convert('RGB')
                    if self.transform:
                        img = self.transform(img)
                    images.append(img)
            except Exception:
                pass

        # --- 统一 Tensor 格式 [2, 3, 224, 224] ---
        # 1. 如果一张图都没读到 (坏数据)，返回全0
        if len(images) == 0:
            return torch.zeros((2, 3, 224, 224))

        # 2. 堆叠
        img_tensor = torch.stack(images, dim=0)  # [N, 3, H, W]

        # 3. Padding / Cutting 到固定 2 张
        if img_tensor.size(0) == 1:
            # 只有1张图 (MIMIC 常见)，复制一遍
            img_tensor = torch.cat([img_tensor, img_tensor], dim=0)
        elif img_tensor.size(0) > 2:
            # 超过2张，取前2张
            img_tensor = img_tensor[:2]

        return img_tensor


# ==============================================================================
# [依赖补全] Mining & CMNet (保持不变)
# ==============================================================================
class DiseaseAwareTokenMining(nn.Module):
    def __init__(self, dim=768, num_tokens=32, num_heads=8, dropout=0.1):
        super(DiseaseAwareTokenMining, self).__init__()
        self.num_tokens = num_tokens
        self.dim = dim
        self.disease_query = nn.Parameter(torch.randn(1, num_tokens, dim))
        self.attention = nn.MultiheadAttention(
            embed_dim=dim, num_heads=num_heads, dropout=dropout, batch_first=True
        )
        self.layer_norm = nn.LayerNorm(dim)

    def forward(self, image_features):
        B = image_features.size(0)
        queries = self.disease_query.expand(B, -1, -1)
        out, _ = self.attention(query=queries, key=image_features, value=image_features)
        return self.layer_norm(out)


class CMNet_Extractor(nn.Module):
    def __init__(self, args):
        super(CMNet_Extractor, self).__init__()
        self.args = args
        try:
            from SwinCheX.models.build import build_model as build_swin
            from SwinCheX.config import get_config
            swin_config = get_config(args)
            self.visual_encoder = build_swin(swin_config)
        except Exception as e:
            print(f"[Warning] SwinCheX fallback: {e}")
            import timm
            self.visual_encoder = timm.create_model('resnet101', pretrained=True, num_classes=0)

        v_dim = getattr(self.visual_encoder, 'num_features', 768)
        if hasattr(self.visual_encoder, 'num_features') and self.visual_encoder.num_features == 2048:
            v_dim = 2048
        self.visual_mining = DiseaseAwareTokenMining(dim=v_dim, num_tokens=32)

    def forward_visual_token_level(self, x):
        if hasattr(self.visual_encoder, 'patch_embed'):
            ve = self.visual_encoder
            x = ve.patch_embed(x)
            if getattr(ve, 'ape', False): x = x + ve.absolute_pos_embed
            x = ve.pos_drop(x)
            for layer in ve.layers: x = layer(x)
            x = ve.norm(x)
        else:
            x = self.visual_encoder(x)
            if len(x.shape) == 4: x = x.flatten(2).transpose(1, 2)
        return x

    def forward(self, images):
        v_tokens = self.forward_visual_token_level(images)
        m_feat = self.visual_mining(v_tokens)
        return m_feat


# ==============================================================================
# [主流程]
# ==============================================================================
def main():
    parser = argparse.ArgumentParser()
    # IU X-ray 参数
    parser.add_argument('--image_dir', type=str, required=True)
    parser.add_argument('--ann_path', type=str, required=True)
    # MIMIC 参数
    parser.add_argument('--mimic_image_dir', type=str, default='/root/autodl-tmp/mimic_cxr/images')
    parser.add_argument('--mimic_ann_path', type=str, default='/root/autodl-tmp/mimic_cxr/annotation.json')

    parser.add_argument('--dataset_name', type=str, default='iu_xray')
    parser.add_argument('--checkpoint', type=str, default='/root/autodl-tmp/Stage1ckpt.pth')
    parser.add_argument('--save_path', type=str, default='visual_memory_bank_mixed.npy')
    parser.add_argument('--cfg', type=str, required=True)
    parser.add_argument('--n_clusters', type=int, default=2048)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--num_workers', type=int, default=8)
    args = parser.parse_args()

    device = torch.device('cuda')

    # --- Config Hijack ---
    try:
        import SwinCheX.config as swin_config_module
        from yacs.config import CfgNode as CN
        def patched_update_config(config, args_obj):
            config.defrost()
            if not hasattr(config, 'NIH'): config.NIH = CN()
            config.NIH.num_mlp_heads = 1
            config.NIH.num_classes = 14
            config.freeze()
            return config

        swin_config_module.update_config = patched_update_config
    except:
        pass

    with open(args.cfg, 'r') as f:
        full_config = json.load(f)
    transformers.AutoModelForCausalLM.from_pretrained = classmethod(lambda *a, **k: torch.nn.Module())
    transformers.AutoConfig.from_pretrained = classmethod(lambda *a, **k: MagicMock(hidden_size=4096))
    for k, v in full_config['model'].items(): setattr(args, k, v)

    # 1. 初始化模型
    print(f">>> Initializing CMNet Extractor...")
    model = CMNet_Extractor(args)
    if os.path.exists(args.checkpoint):
        print(f">>> Loading Stage1 Checkpoint: {args.checkpoint}")
        ckpt = torch.load(args.checkpoint, map_location='cpu')
        sd = ckpt.get('state_dict', ckpt)
        new_sd = {}
        for k, v in sd.items():
            k_clean = k.replace('module.', '')
            if 'visual_encoder' in k_clean or 'visual_mining' in k_clean:
                new_sd[k_clean] = v
        msg = model.load_state_dict(new_sd, strict=False)
        print(f">>> Weights Loaded. Missing: {len(msg.missing_keys)}")
    model = model.to(device).eval()

    # 2. 定义 Transform
    val_transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
    ])

    # 3. 初始化混合 Dataset (使用我们手写的 MixedExtractionDataset)
    print(f">>> Initializing Mixed Dataset...")
    dataset = MixedExtractionDataset(
        iu_ann_path=args.ann_path,
        iu_image_dir=args.image_dir,
        mimic_ann_path=args.mimic_ann_path,
        mimic_image_dir=args.mimic_image_dir,
        transform=val_transform
    )

    # 4. DataLoader
    # 因为 Dataset __getitem__ 已经返回了 Tensor，不需要特殊的 collate_fn
    loader = DataLoader(dataset, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers)

    # 5. 聚类
    kmeans = MiniBatchKMeans(n_clusters=args.n_clusters, batch_size=2048, random_state=42, n_init=1)

    print(f">>> [Memory] Start extracting...")
    init_buffer = []
    initialized = False

    with torch.no_grad():
        for i, images in tqdm(enumerate(loader), total=len(loader)):
            # images: [B, 2, 3, 224, 224] -> Flatten to [B*2, 3, 224, 224]
            # 因为我们已经在 Dataset 里强制堆叠了 2 张图
            B = images.shape[0]
            V = images.shape[1]
            images = images.to(device).view(B * V, 3, 224, 224)

            m_feat = model(images)
            flat_m = m_feat.reshape(-1, m_feat.size(-1)).cpu().numpy()

            if not initialized:
                init_buffer.append(flat_m)
                current_total = np.concatenate(init_buffer, axis=0)
                if current_total.shape[0] >= args.n_clusters * 10:
                    kmeans.partial_fit(current_total)
                    initialized = True
                    init_buffer = []
                    print(f"\n>>> [Memory] Initialized with {current_total.shape[0]} samples.")
            else:
                kmeans.partial_fit(flat_m)

            # MIMIC 跑 2000 个 batch (约 6.4万图) 足够
            if i > 2000: break

    # 保存
    np.save(args.save_path, kmeans.cluster_centers_)

    import pickle
    pkl_path = args.save_path.replace('.npy', '.pkl')
    memory_tensor = torch.from_numpy(kmeans.cluster_centers_).float()
    with open(pkl_path, 'wb') as f:
        pickle.dump(memory_tensor, f)

    print(f"\n>>> [Success] Mixed Memory saved to: {pkl_path}")


if __name__ == '__main__':
    main()