import torch
import torch.nn as nn
import os
import numpy as np
import torch.nn.functional as F
from modules.modules4cmnet import DiseaseAwareTokenMining, CausalInterventionLayer


class CMNet(nn.Module):
    def __init__(self, args, tokenizer):
        super(CMNet, self).__init__()
        self.args = args
        self.tokenizer = tokenizer

        # ====================================================================
        # 1. 视觉基座 (Swin Transformer)
        # ====================================================================
        from SwinCheX.models.build import build_model as build_swin
        from SwinCheX.config import get_config
        swin_config = get_config(args)
        self.visual_encoder = build_swin(swin_config)

        # 训练时全量微调
        self.visual_encoder.train()
        for param in self.visual_encoder.parameters():
            param.requires_grad = True

        v_dim = getattr(self.visual_encoder, 'num_features', 768)
        d_model = getattr(args, 'd_model', 768)
        vocab_size = len(tokenizer.token2idx)
        dropout_prob = getattr(args, 'dropout', 0.1)

        # ====================================================================
        # 2. 原始 VLCI 模块 (保留用于生成 Query)
        # ====================================================================
        self.visual_mining = DiseaseAwareTokenMining(dim=v_dim, num_tokens=32)
        self.causal_intervention = CausalInterventionLayer(dim=v_dim)

        # ====================================================================
        # 3. AM-MRG Memory 模块 (保留用于生成 Key/Value)
        # ====================================================================
        self.mem_norm = nn.LayerNorm(v_dim)
        self.query_conv = nn.Linear(v_dim, v_dim, bias=False)
        self.key_conv = nn.Linear(v_dim, v_dim, bias=False)
        self.val_conv = nn.Linear(v_dim, v_dim, bias=False)

        vis_mem_path = getattr(args, 'vis_mem_path', 'visual_memory_bank_iu.npy')
        if os.path.exists(vis_mem_path):
            print(f">>> [CMNet] Loading Memory from: {vis_mem_path}")
            vmb_data = np.load(vis_mem_path)
            vmb_data = np.nan_to_num(vmb_data, nan=0.0, posinf=1.0, neginf=-1.0)
            self.register_buffer('visual_memory_bank', torch.from_numpy(vmb_data).float())
        else:
            self.register_buffer('visual_memory_bank', torch.randn(2048, v_dim))

        # ====================================================================
        # 4. [关键创新点] Cross-Attention Fusion Layer
        # ====================================================================
        # 这是一个标准的 Attention 模块，用于让 VLCI 和 Memory "对话"
        # Query: VLCI Features (What I see)
        # Key/Value: Memory Features (What I know)
        self.cross_fusion = nn.MultiheadAttention(
            embed_dim=v_dim,
            num_heads=8,
            dropout=dropout_prob,
            batch_first=True
        )

        # 融合后的残差门控 (LayerNorm + Gate)
        self.fusion_norm = nn.LayerNorm(v_dim)
        self.fusion_gate = nn.Sequential(
            nn.Linear(v_dim * 2, v_dim),
            nn.Sigmoid()
        )

        # ====================================================================
        # 5. 解码器
        # ====================================================================
        self.vis_proj = nn.Linear(v_dim, d_model) if v_dim != d_model else nn.Identity()

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=d_model, nhead=8, dim_feedforward=2048,
            dropout=dropout_prob,
            batch_first=True, norm_first=True
        )
        self.decoder = nn.TransformerDecoder(decoder_layer, num_layers=3)
        self.tgt_embed = nn.Embedding(vocab_size, d_model)
        self.fc_out = nn.Linear(d_model, vocab_size)

    def forward_visual_token_level(self, x):
        ve = self.visual_encoder
        x = ve.patch_embed(x)
        if getattr(ve, 'ape', False): x = x + ve.absolute_pos_embed
        x = ve.pos_drop(x)
        for layer in ve.layers: x = layer(x)
        x = ve.norm(x)
        return x

    def forward(self, images, targets=None, mode='train'):
        B, V = images.shape[0], images.shape[1]
        images = images.view(B * V, 3, 224, 224)

        # 1. 基础特征
        v_tokens = self.forward_visual_token_level(images)
        v_tokens = v_tokens.contiguous().view(B, -1, v_tokens.size(-1))

        # 2. 挖掘 (Mining)
        m_feat_raw = self.visual_mining(v_tokens)  # [B, 32, v_dim]

        # -----------------------------------------------------------
        # Stream 1: VLCI (生成 Query)
        # -----------------------------------------------------------
        # 这里的 confounder 仍然使用 Batch Mean，保持原汁原味
        batch_confounder = torch.mean(m_feat_raw, dim=0, keepdim=True).expand(B, -1, -1)
        m_feat_vlci = self.causal_intervention(m_feat_raw, batch_confounder)
        # m_feat_vlci 是纯净的病灶特征，作为 Query

        # -----------------------------------------------------------
        # Stream 2: Memory (生成 Key/Value)
        # -----------------------------------------------------------
        if hasattr(self, 'visual_memory_bank'):
            # 用含背景的 raw feat 去检索，定位更准
            M_norm = self.mem_norm(m_feat_raw)
            Z_raw = self.visual_memory_bank

            q = self.query_conv(M_norm)
            k = self.key_conv(Z_raw)
            v_mem = self.val_conv(Z_raw)

            # 标准检索过程
            scale = q.size(-1) ** -0.5
            scores = torch.matmul(q, k.T) * scale
            attn_weights = torch.softmax(scores, dim=-1)

            # 这里的 retrieved_memory 包含了相似病例的模版信息
            m_feat_memory = torch.matmul(attn_weights, v_mem)  # [B, 32, v_dim]

            # -----------------------------------------------------------
            # Fusion: Cross-Attention (Query-Key Interaction)
            # -----------------------------------------------------------
            # 这一步是核心：用 VLCI 去“质询” Memory
            # Q = VLCI (去噪后的特征)
            # K, V = Memory (知识库)

            # m_feat_memory 作为 KV，m_feat_vlci 作为 Q
            # attn_output 形状 [B, 32, v_dim]
            attn_output, _ = self.cross_fusion(
                query=m_feat_vlci,
                key=m_feat_memory,
                value=m_feat_memory
            )

            # 残差连接 + 门控
            # 融合特征 = VLCI + Gate * (VLCI 查到的 Memory 知识)
            gate = self.fusion_gate(torch.cat([m_feat_vlci, attn_output], dim=-1))
            m_final = m_feat_vlci + gate * attn_output
            m_final = self.fusion_norm(m_final)

        else:
            m_final = m_feat_vlci

        # 3. 解码
        memory = self.vis_proj(m_final)
        memory = F.layer_norm(memory, [memory.size(-1)])

        if mode == 'train' and targets is not None:
            tgt_mask = self.generate_square_subsequent_mask(targets.size(1)).to(targets.device)
            tgt_embedded = self.tgt_embed(targets)
            output = self.decoder(tgt_embedded, memory, tgt_mask=tgt_mask)
            logits = self.fc_out(output)
            return logits
        else:
            return self.beam_search(memory, beam_size=3)

    def generate_square_subsequent_mask(self, sz):
        mask = (torch.triu(torch.ones(sz, sz)) == 1).transpose(0, 1)
        mask = mask.float().masked_fill(mask == 0, -1e9).masked_fill(mask == 1, float(0.0))
        return mask

    def beam_search(self, memory, beam_size=3, max_len=60, length_penalty=1.0):
        # 保持原代码
        batch_size = memory.size(0)
        device = memory.device
        SOS_TOKEN = 1
        EOS_TOKEN = 2
        memory = memory.repeat_interleave(beam_size, dim=0)
        seq = torch.full((batch_size * beam_size, 1), SOS_TOKEN, dtype=torch.long, device=device)
        top_k_scores = torch.zeros((batch_size, beam_size), device=device)
        top_k_scores[:, 1:] = -1e9
        top_k_scores = top_k_scores.view(-1)
        for t in range(max_len):
            tgt_emb = self.tgt_embed(seq)
            output = self.decoder(tgt_emb, memory)
            output = output[:, -1, :]
            log_probs = F.log_softmax(self.fc_out(output), dim=-1)
            scores = top_k_scores.unsqueeze(1) + log_probs
            scores = scores.view(batch_size, -1)
            best_scores, best_indices = scores.topk(beam_size, dim=1)
            vocab_size = log_probs.size(1)
            beam_indices = best_indices.div(vocab_size, rounding_mode='floor')
            token_indices = best_indices % vocab_size
            new_seq = []
            for b in range(batch_size):
                for k in range(beam_size):
                    prev_beam_idx = b * beam_size + beam_indices[b, k]
                    prev_sequence = seq[prev_beam_idx]
                    new_token = token_indices[b, k].unsqueeze(0)
                    new_seq.append(torch.cat([prev_sequence, new_token]))
            seq = torch.stack(new_seq)
            top_k_scores = best_scores.view(-1)
        final_sequences = seq.view(batch_size, beam_size, -1)
        final_scores = top_k_scores.view(batch_size, beam_size)
        lengths = torch.tensor([len(s) for s in seq]).to(device).view(batch_size, beam_size)
        penalty = torch.pow(lengths.float(), length_penalty)
        final_scores = final_scores / penalty
        best_beam_idx = final_scores.argmax(dim=1)
        best_sequences = []
        for b in range(batch_size):
            best_sequences.append(final_sequences[b, best_beam_idx[b]])
        best_sequences = torch.stack(best_sequences)
        output_cleaned = []
        for i in range(batch_size):
            s = best_sequences[i]
            eos_indices = (s == EOS_TOKEN).nonzero(as_tuple=True)[0]
            if len(eos_indices) > 0:
                s = s[:eos_indices[0]]
            output_cleaned.append(s)
        max_actual_len = max([len(x) for x in output_cleaned]) if output_cleaned else 1
        final_tensor = torch.zeros((batch_size, max_actual_len), dtype=torch.long, device=device)
        for i in range(batch_size):
            length = len(output_cleaned[i])
            if length > 0:
                final_tensor[i, :length] = output_cleaned[i]
        return final_tensor