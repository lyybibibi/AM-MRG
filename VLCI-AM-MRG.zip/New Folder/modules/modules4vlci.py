"""
Visual-Linguistics Causal Intervention Modules with AM-MRG Memory Enhancement

核心修改：
1. 添加 Modern Hopfield Network 实现真正的 Memory 检索
2. 使用可学习的门控机制替代固定的 0.01 系数
3. 保持与原有 VLCI 架构的完全兼容
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
from modules.modules4transformer import LayerNorm


# ============================================================================
# Modern Hopfield Network - AM-MRG 的核心组件
# ============================================================================

class ModernHopfieldNetwork(nn.Module):
    """
    Modern Hopfield Network for Memory Retrieval

    基于论文: "Hopfield Networks is All You Need" (ICLR 2021)
    用于从 Memory Bank 中检索相关的医学知识

    维度说明 (适配 VLCI):
    - query_dim: 512 (VLCI 的 embed_dim)
    - memory_dim: 768 (Bio_ClinicalBERT 的输出维度)
    - output_dim: 512 (与 VLCI 对齐)
    """
    def __init__(self, query_dim, memory_dim, output_dim, beta=4.0, dropout=0.1):
        """
        Args:
            query_dim: 查询向量维度 (512)
            memory_dim: Memory Bank 中每个条目的维度 (768)
            output_dim: 输出维度 (512)
            beta: 温度参数，控制检索的锐度，越大越尖锐
            dropout: Dropout 率
        """
        super().__init__()
        self.query_dim = query_dim
        self.memory_dim = memory_dim
        self.output_dim = output_dim
        self.beta = beta

        # Memory Bank (延迟初始化，由外部加载)
        self.register_buffer('memory', None)
        self.memory_initialized = False

        # 投影层：将 query (512) 投影到 memory 空间 (768) 进行匹配
        self.query_proj = nn.Sequential(
            nn.Linear(query_dim, memory_dim),
            nn.LayerNorm(memory_dim),
            nn.GELU()
        )

        # 输出投影层：将检索结果 (768) 投影回模型维度 (512)
        self.output_proj = nn.Sequential(
            nn.Linear(memory_dim, output_dim),
            nn.LayerNorm(output_dim),
            nn.Dropout(dropout)
        )

        # 可学习的缩放因子（替代固定的 0.01）
        self.scale = nn.Parameter(torch.tensor(0.1))

        self._init_weights()

    def _init_weights(self):
        for module in self.modules():
            if isinstance(module, nn.Linear):
                nn.init.xavier_uniform_(module.weight)
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    def init_memory(self, memory_tensor):
        """
        从外部加载 Memory Bank

        Args:
            memory_tensor: [N, memory_dim] Memory Bank 张量
        """
        if memory_tensor is None:
            print("[Hopfield] Warning: memory_tensor is None")
            return

        # 确保是 2D 张量
        if memory_tensor.dim() == 1:
            memory_tensor = memory_tensor.unsqueeze(0)

        # 检查并处理维度不匹配
        if memory_tensor.shape[-1] != self.memory_dim:
            print(f"[Hopfield] Projecting memory from {memory_tensor.shape[-1]} to {self.memory_dim}")
            proj = nn.Linear(memory_tensor.shape[-1], self.memory_dim)
            nn.init.xavier_uniform_(proj.weight)
            with torch.no_grad():
                memory_tensor = proj(memory_tensor.float())

        # L2 归一化，提升检索稳定性
        memory_tensor = F.normalize(memory_tensor.float(), p=2, dim=-1)

        self.register_buffer('memory', memory_tensor.detach())
        self.memory_initialized = True
        print(f"[Hopfield] Memory initialized: {self.memory.shape}")

    def forward(self, query):
        """
        Hopfield 检索

        Args:
            query: [B, L, query_dim] 查询特征

        Returns:
            retrieved: [B, L, output_dim] 检索增强特征
        """
        if not self.memory_initialized or self.memory is None:
            # Memory 未初始化时，返回零向量
            return torch.zeros(query.shape[0], query.shape[1], self.output_dim,
                             device=query.device, dtype=query.dtype)

        # 确保 memory 在正确的设备上
        if self.memory.device != query.device:
            self.memory = self.memory.to(query.device)

        B, L, D = query.shape

        # 1. 投影 query 到 memory 空间
        q = self.query_proj(query)  # [B, L, memory_dim]
        q = F.normalize(q, p=2, dim=-1)  # L2 归一化

        # 2. 计算 Hopfield 能量（注意力分数）
        # memory: [N, memory_dim]
        scores = torch.einsum('bld,nd->bln', q, self.memory)  # [B, L, N]

        # 应用温度缩放
        scores = scores * self.beta

        # 3. Softmax 得到检索权重
        attn_weights = F.softmax(scores, dim=-1)  # [B, L, N]

        # 4. 加权求和得到检索结果
        retrieved = torch.einsum('bln,nd->bld', attn_weights, self.memory)  # [B, L, memory_dim]

        # 5. 投影回模型维度
        retrieved = self.output_proj(retrieved)  # [B, L, output_dim]

        # 6. 应用可学习缩放因子
        retrieved = torch.sigmoid(self.scale) * retrieved

        return retrieved


class MemoryGate(nn.Module):
    """
    可学习的门控机制，用于融合原始特征和 Memory 增强特征
    替代固定的 0.01 系数，让模型自己学习最优的融合比例
    """
    def __init__(self, embed_dim, dropout=0.1):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.Sigmoid()
        )
        self.dropout = nn.Dropout(dropout)

    def forward(self, original, memory_out):
        """
        Args:
            original: [B, L, D] 原始特征
            memory_out: [B, L, D] Memory 增强特征

        Returns:
            fused: [B, L, D] 融合后的特征
        """
        # 拼接原始特征和 memory 特征
        gate_input = torch.cat([original, memory_out], dim=-1)  # [B, L, 2D]
        # 计算门控权重 (每个维度独立的 gate)
        gate_weight = self.gate(gate_input)  # [B, L, D]
        # 门控融合
        fused = original + gate_weight * self.dropout(memory_out)
        return fused


# ============================================================================
# Visual Deconfounding Module (VDM) - 视觉端因果干预 + Memory 增强
# ============================================================================

class VDM(nn.Module):
    """
    Visual Deconfounding Module with AM-MRG Memory Enhancement

    核心逻辑（按您的策略）：
    1. 接收 Local (fl) 和 Global (fg) 视觉特征
    2. 用 Global 特征检索 Disease Memory（全局优先注入）
    3. Local-Global Fusion (LGFM)
    4. 因果前门干预
    5. 残差连接保留原始特征

    维度说明：
    - 输入 h: [B, 99, 512] (98 patches + 1 cls token)
    - 输入 fl: [B, 6, 512] (top-k local regions)
    - 输入 fg: [B, 1, 512] (global feature)
    - 输出: [B, 99, 512]
    """
    def __init__(self, embed_dim, num_heads, ff_dim, dropout,
                 use_memory=True, memory_size=154, memory_dim=768, beta=4.0):
        """
        Args:
            embed_dim: 特征维度 (512)
            num_heads: 注意力头数 (8)
            ff_dim: FFN 隐藏层维度 (2048)
            dropout: Dropout 率
            use_memory: 是否使用 Memory 增强
            memory_size: Disease Memory 条目数 (14 diseases * 11 templates = 154)
            memory_dim: Memory 向量维度 (768, Bio_ClinicalBERT)
            beta: Hopfield 温度参数
        """
        super().__init__()
        self.embed_dim = embed_dim
        self.use_memory = use_memory

        # ============ Memory Augmentation (AM-MRG) ============
        if use_memory:
            self.hopfield = ModernHopfieldNetwork(
                query_dim=embed_dim,
                memory_dim=memory_dim,
                output_dim=embed_dim,
                beta=beta,
                dropout=dropout
            )
            self.memory_gate = MemoryGate(embed_dim, dropout)

        # ============ Local-Global Fusion Module (LGFM) ============
        # 融合 local 和 (memory-augmented) global 特征
        self.lgfm_proj = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

        # ============ Cross Attention: h attend to fused features ============
        self.cross_attn = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.cross_norm = LayerNorm(embed_dim)

        # ============ Feed-Forward Network ============
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, ff_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(ff_dim, embed_dim),
            nn.Dropout(dropout)
        )
        self.ffn_norm = LayerNorm(embed_dim)

        # ============ 残差连接权重 ============
        # 控制干预强度，防止过度修改原始特征
        self.residual_weight = nn.Parameter(torch.tensor(0.5))

    def init_memory(self, memory_tensor):
        """初始化 Disease Memory"""
        if self.use_memory and hasattr(self, 'hopfield'):
            self.hopfield.init_memory(memory_tensor)
            print(f"[VDM] Disease Memory initialized")

    def forward(self, h, fl, fg, mode='y', proj=False):
        """
        前向传播

        Args:
            h: [B, L, D] 完整视觉特征, L=99 (98+1), D=512
            fl: [B, K, D] Local 特征, K=6
            fg: [B, 1, D] Global 特征
            mode: 'y' 启用因果干预, 'n' 跳过
            proj: 是否使用投影（兼容原代码）

        Returns:
            out: [B, L, D] 去偏后的视觉特征
        """
        if mode == 'n':
            return h

        B, L, D = h.shape

        # ============ Step 1: Memory Augmentation (Global-First) ============
        if self.use_memory and hasattr(self, 'hopfield') and self.hopfield.memory_initialized:
            # 用 Global 特征检索 Disease Memory
            mem_out = self.hopfield(fg)  # [B, 1, D]
            # 门控融合
            fg_aug = self.memory_gate(fg, mem_out)  # [B, 1, D]
        else:
            fg_aug = fg

        # ============ Step 2: Local-Global Fusion (LGFM) ============
        # 将 global 扩展到与 local 相同的长度
        fg_expanded = fg_aug.expand(-1, fl.size(1), -1)  # [B, K, D]

        # 拼接并融合
        fused = torch.cat([fl, fg_expanded], dim=-1)  # [B, K, 2D]
        fused = self.lgfm_proj(fused)  # [B, K, D]

        # ============ Step 3: Cross Attention ============
        # h attend to fused local-global features
        h_norm = self.cross_norm(h)
        attn_out, _ = self.cross_attn(h_norm, fused, fused)  # [B, L, D]
        h = h + attn_out  # 残差连接

        # ============ Step 4: FFN ============
        h_norm = self.ffn_norm(h)
        ffn_out = self.ffn(h_norm)
        out = h + ffn_out  # 残差连接

        return out


# ============================================================================
# Linguistic Deconfounding Module (LDM) - 语言端因果干预 + Memory 增强
# ============================================================================

class LDM(nn.Module):
    """
    Linguistic Deconfounding Module with AM-MRG Memory Enhancement

    核心逻辑（按您的策略）：
    1. 计算 Mediator (文本 attend to 词汇表 + 视觉局部特征)
    2. 用 Mediator 检索 Report Memory（干预前注入）
    3. 因果干预

    维度说明：
    - 输入 ht: [B, S, 512] 文本特征
    - 输入 z: [B, V, 512] 词汇表嵌入
    - 输入 fl: [B, K, 512] 视觉局部特征
    - 输出: [B, S, 512]
    """
    def __init__(self, embed_dim, num_heads, dropout,
                 use_memory=True, memory_size=2000, memory_dim=768, beta=4.0):
        """
        Args:
            embed_dim: 特征维度 (512)
            num_heads: 注意力头数 (8)
            dropout: Dropout 率
            use_memory: 是否使用 Memory 增强
            memory_size: Report Memory 条目数 (2000)
            memory_dim: Memory 向量维度 (768, Bio_ClinicalBERT)
            beta: Hopfield 温度参数
        """
        super().__init__()
        self.embed_dim = embed_dim
        self.use_memory = use_memory

        # ============ Mediator Generation ============
        # 文本特征 attend to 词汇表，生成语言先验
        self.z_attn = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.z_norm = LayerNorm(embed_dim)

        # 文本特征 attend to 视觉局部特征，生成视觉-语言 mediator
        self.fl_attn = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.fl_norm = LayerNorm(embed_dim)

        # Mediator 融合
        self.mediator_proj = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

        # ============ Memory Augmentation (AM-MRG) ============
        if use_memory:
            self.hopfield = ModernHopfieldNetwork(
                query_dim=embed_dim,
                memory_dim=memory_dim,
                output_dim=embed_dim,
                beta=beta,
                dropout=dropout
            )
            self.memory_gate = MemoryGate(embed_dim, dropout)

        # ============ Causal Intervention ============
        self.intervene_attn = nn.MultiheadAttention(
            embed_dim, num_heads, dropout=dropout, batch_first=True
        )
        self.intervene_norm = LayerNorm(embed_dim)

    def init_memory(self, memory_tensor):
        """初始化 Report Memory"""
        if self.use_memory and hasattr(self, 'hopfield'):
            self.hopfield.init_memory(memory_tensor)
            print(f"[LDM] Report Memory initialized")

    def forward(self, ht, z, fl, mode='y', proj=False):
        """
        前向传播

        Args:
            ht: [B, S, D] 文本特征 (decoder input)
            z: [B, V, D] 词汇表嵌入
            fl: [B, K, D] 视觉局部特征
            mode: 'y' 启用因果干预, 'n' 跳过
            proj: 是否使用投影（兼容原代码）

        Returns:
            out: [B, S, D] 去偏后的文本特征
        """
        if mode == 'n' or z is None or fl is None:
            return ht

        B, S, D = ht.shape

        # ============ Step 1: Generate Mediator ============
        # 1a. 文本 attend to 词汇表
        ht_norm = self.z_norm(ht)
        z_out, _ = self.z_attn(ht_norm, z, z)  # [B, S, D]

        # 1b. 文本 attend to 视觉局部特征
        ht_norm = self.fl_norm(ht)
        fl_out, _ = self.fl_attn(ht_norm, fl, fl)  # [B, S, D]

        # 1c. 融合生成 Mediator
        mediator = torch.cat([z_out, fl_out], dim=-1)  # [B, S, 2D]
        mediator = self.mediator_proj(mediator)  # [B, S, D]

        # ============ Step 2: Memory Augmentation (Pre-Intervention) ============
        if self.use_memory and hasattr(self, 'hopfield') and self.hopfield.memory_initialized:
            # 用 Mediator 检索 Report Memory
            mem_out = self.hopfield(mediator)  # [B, S, D]
            # 门控融合
            mediator_aug = self.memory_gate(mediator, mem_out)  # [B, S, D]
        else:
            mediator_aug = mediator

        # ============ Step 3: Causal Intervention ============
        # 用增强后的 mediator 对原始文本特征进行干预
        ht_norm = self.intervene_norm(ht)
        out, _ = self.intervene_attn(ht_norm, mediator_aug, mediator_aug)  # [B, S, D]

        # 残差连接
        out = ht + out

        return out


# ============================================================================
# 原有模块（保持兼容）
# ============================================================================

class GlobalSample(nn.Module):
    """
    全局特征采样模块
    通过全局平均池化提取图像级特征
    """
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super().__init__()
        self.norm = LayerNorm(embed_dim)
        self.proj = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

    def forward(self, h):
        """
        Args:
            h: [B, L, D] 视觉特征, L=99

        Returns:
            fg: [B, 1, D] 全局特征
        """
        # 使用 CLS token 或者全局平均
        fg = h[:, 0:1, :]  # 使用 CLS token [B, 1, D]
        fg = self.norm(fg)
        fg = self.proj(fg)
        return fg


class LocalSample(nn.Module):
    """
    局部特征采样模块
    基于注意力权重选择 top-k 重要区域
    """
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super().__init__()
        self.norm = LayerNorm(embed_dim)
        self.proj = nn.Sequential(
            nn.Linear(embed_dim, embed_dim),
            nn.LayerNorm(embed_dim),
            nn.GELU(),
            nn.Dropout(dropout)
        )

    def forward(self, h, attn, k=6):
        """
        Args:
            h: [B, L, D] 视觉特征
            attn: List of attention weights from encoder layers
            k: 选择 top-k 个局部区域

        Returns:
            fl: [B, K, D] 局部特征
        """
        B, L, D = h.shape

        # 聚合所有层的注意力权重
        if len(attn) > 0 and attn[0] is not None:
            # attn[i]: [B, num_heads, L, L]
            attn_weights = torch.stack(attn, dim=0).mean(dim=0)  # [B, num_heads, L, L]
            attn_weights = attn_weights.mean(dim=1)  # [B, L, L]

            # 计算每个位置的重要性（被其他位置关注的程度）
            importance = attn_weights.sum(dim=1)  # [B, L]

            # 排除 CLS token，选择 top-k
            importance[:, 0] = -float('inf')  # 排除 CLS token
            _, top_indices = importance.topk(k, dim=1)  # [B, k]

            # 收集 top-k 特征
            top_indices = top_indices.unsqueeze(-1).expand(-1, -1, D)  # [B, k, D]
            fl = torch.gather(h, 1, top_indices)  # [B, k, D]
        else:
            # 如果没有注意力权重，随机选择
            indices = torch.randperm(L - 1)[:k] + 1  # 排除 CLS token
            fl = h[:, indices, :]  # [B, k, D]

        fl = self.norm(fl)
        fl = self.proj(fl)

        return fl
