#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
AM-MRG Memory Bank Generator (Mixed Dataset)
同时生成：
1. Disease Memory: 视觉特征聚类中心 (用于 VDM)
2. Report Memory: 文本语义嵌入 (用于 LDM)
"""

import os
import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm
from sklearn.cluster import MiniBatchKMeans
import argparse
from torchvision import transforms
from PIL import Image
import json
import pickle
from functools import partial
from unittest.mock import MagicMock
import transformers
from transformers import AutoTokenizer, AutoModel


# ==============================================================================
# [Dataset] 混合数据集 - 同时提取图像和报告文本
# ==============================================================================
class MixedExtractionDataset(Dataset):
    """用于视觉特征提取的 Dataset"""

    def __init__(self, iu_ann_path, iu_image_dir, mimic_ann_path, mimic_image_dir, transform):
        self.transform = transform
        self.samples = []

        # 1. 加载 IU X-ray 数据
        print(f"Loading IU X-ray from: {iu_ann_path}")
        with open(iu_ann_path, 'r') as f:
            iu_data = json.load(f)
            if isinstance(iu_data, dict) and 'train' in iu_data:
                iu_data = iu_data['train']

        for item in iu_data:
            self.samples.append({
                'source': 'iu',
                'root': iu_image_dir,
                'paths': item.get('image_path', [])
            })

        # 2. 加载 MIMIC-CXR 数据
        print(f"Loading MIMIC-CXR from: {mimic_ann_path}")
        with open(mimic_ann_path, 'r') as f:
            mimic_data = json.load(f)
            if isinstance(mimic_data, dict) and 'train' in mimic_data:
                mimic_data = mimic_data['train']

        for item in mimic_data:
            self.samples.append({
                'source': 'mimic',
                'root': mimic_image_dir,
                'paths': item.get('image_path', [])
            })

        print(f"Total samples: {len(self.samples)} (IU + MIMIC)")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        item = self.samples[index]
        image_root = item['root']
        path_list = item['paths']

        if isinstance(path_list, str):
            path_list = [path_list]

        images = []
        for p in path_list:
            try:
                full_path = os.path.join(image_root, p)
                if not os.path.exists(full_path):
                    for ext in ['.jpg', '.png', '.jpeg']:
                        if os.path.exists(full_path + ext):
                            full_path = full_path + ext
                            break

                if os.path.exists(full_path):
                    img = Image.open(full_path).convert('RGB')
                    if self.transform:
                        img = self.transform(img)
                    images.append(img)
            except Exception:
                pass

        if len(images) == 0:
            return torch.zeros((2, 3, 224, 224))

        img_tensor = torch.stack(images, dim=0)

        if img_tensor.size(0) == 1:
            img_tensor = torch.cat([img_tensor, img_tensor], dim=0)
        elif img_tensor.size(0) > 2:
            img_tensor = img_tensor[:2]

        return img_tensor


# ==============================================================================
# [视觉模型] Disease-Aware Token Mining
# ==============================================================================
class DiseaseAwareTokenMining(nn.Module):
    def __init__(self, dim=768, num_tokens=32, num_heads=8, dropout=0.1):
        super(DiseaseAwareTokenMining, self).__init__()
        self.num_tokens = num_tokens
        self.dim = dim
        self.disease_query = nn.Parameter(torch.randn(1, num_tokens, dim))
        self.attention = nn.MultiheadAttention(
            embed_dim=dim, num_heads=num_heads, dropout=dropout, batch_first=True
        )
        self.layer_norm = nn.LayerNorm(dim)

    def forward(self, image_features):
        B = image_features.size(0)
        queries = self.disease_query.expand(B, -1, -1)
        out, _ = self.attention(query=queries, key=image_features, value=image_features)
        return self.layer_norm(out)


class CMNet_Extractor(nn.Module):
    def __init__(self, args):
        super(CMNet_Extractor, self).__init__()
        self.args = args
        try:
            from SwinCheX.models.build import build_model as build_swin
            from SwinCheX.config import get_config
            swin_config = get_config(args)
            self.visual_encoder = build_swin(swin_config)
        except Exception as e:
            print(f"[Warning] SwinCheX fallback: {e}")
            import timm
            self.visual_encoder = timm.create_model('resnet101', pretrained=True, num_classes=0)

        v_dim = getattr(self.visual_encoder, 'num_features', 768)
        if hasattr(self.visual_encoder, 'num_features') and self.visual_encoder.num_features == 2048:
            v_dim = 2048
        self.visual_mining = DiseaseAwareTokenMining(dim=v_dim, num_tokens=32)

    def forward_visual_token_level(self, x):
        if hasattr(self.visual_encoder, 'patch_embed'):
            ve = self.visual_encoder
            x = ve.patch_embed(x)
            if getattr(ve, 'ape', False):
                x = x + ve.absolute_pos_embed
            x = ve.pos_drop(x)
            for layer in ve.layers:
                x = layer(x)
            x = ve.norm(x)
        else:
            x = self.visual_encoder(x)
            if len(x.shape) == 4:
                x = x.flatten(2).transpose(1, 2)
        return x

    def forward(self, images):
        v_tokens = self.forward_visual_token_level(images)
        m_feat = self.visual_mining(v_tokens)
        return m_feat


# ==============================================================================
# [Report Memory] 文本语义嵌入生成
# ==============================================================================
def extract_sentences_from_annotations(iu_ann_path, mimic_ann_path, max_sentences=50000):
    """从 IU X-Ray 和 MIMIC-CXR 的训练集提取报告句子"""
    all_sentences = []

    # 1. 加载 IU X-Ray
    print(f"[Report] Loading IU X-Ray from {iu_ann_path}...")
    if os.path.exists(iu_ann_path):
        with open(iu_ann_path, 'r') as f:
            iu_data = json.load(f)

        for split in ['train', 'val']:  # 包含验证集以增加多样性
            if split in iu_data:
                for item in iu_data[split]:
                    report = item.get('report', '')
                    # 按句号分割
                    sentences = report.replace('\n', ' ').split('.')
                    for sent in sentences:
                        sent = sent.strip()
                        # 过滤太短的句子
                        if len(sent) > 15 and len(sent) < 300:
                            all_sentences.append(sent + '.')
        print(f"  IU X-Ray: {len(all_sentences)} sentences")

    # 2. 加载 MIMIC-CXR
    print(f"[Report] Loading MIMIC-CXR from {mimic_ann_path}...")
    if os.path.exists(mimic_ann_path):
        with open(mimic_ann_path, 'r') as f:
            mimic_data = json.load(f)

        count_before = len(all_sentences)
        for split in ['train']:
            if split in mimic_data:
                for item in mimic_data[split]:
                    report = item.get('report', '')
                    sentences = report.replace('\n', ' ').split('.')
                    for sent in sentences:
                        sent = sent.strip()
                        if len(sent) > 15 and len(sent) < 300:
                            all_sentences.append(sent + '.')

                    # MIMIC 太大，采样部分
                    if len(all_sentences) > max_sentences:
                        break
        print(f"  MIMIC-CXR: {len(all_sentences) - count_before} sentences")

    print(f"[Report] Total collected: {len(all_sentences)} sentences")

    # 去重
    all_sentences = list(set(all_sentences))
    print(f"[Report] After dedup: {len(all_sentences)} unique sentences")

    return all_sentences


def generate_report_memory(sentences, output_path, n_clusters=2048, batch_size=64):
    """使用 Bio_ClinicalBERT 编码报告句子，然后聚类"""
    print(f"\n[Report Memory] Generating with {len(sentences)} sentences...")

    # 加载 Bio_ClinicalBERT
    print("[Report] Loading Bio_ClinicalBERT...")
    try:
        tokenizer = AutoTokenizer.from_pretrained("emilyalsentzer/Bio_ClinicalBERT")
        model = AutoModel.from_pretrained("emilyalsentzer/Bio_ClinicalBERT")
    except Exception as e:
        print(f"[Warning] Bio_ClinicalBERT failed: {e}, using bert-base-uncased")
        tokenizer = AutoTokenizer.from_pretrained("bert-base-uncased")
        model = AutoModel.from_pretrained("bert-base-uncased")

    model.eval()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)
    print(f"[Report] Using device: {device}")

    # 编码所有句子
    all_embeddings = []

    with torch.no_grad():
        for i in tqdm(range(0, len(sentences), batch_size), desc="Encoding reports"):
            batch = sentences[i:i + batch_size]

            inputs = tokenizer(
                batch,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=128
            )

            inputs = {k: v.to(device) for k, v in inputs.items()}

            outputs = model(**inputs)
            # 使用 [CLS] token 的输出
            embeddings = outputs.last_hidden_state[:, 0, :].cpu().numpy()
            all_embeddings.append(embeddings)

    all_embeddings = np.concatenate(all_embeddings, axis=0)
    print(f"[Report] Embeddings shape: {all_embeddings.shape}")

    # 聚类到固定大小
    if all_embeddings.shape[0] > n_clusters:
        print(f"[Report] Clustering {all_embeddings.shape[0]} -> {n_clusters} centers...")
        kmeans = MiniBatchKMeans(
            n_clusters=n_clusters,
            batch_size=min(2048, all_embeddings.shape[0] // 4),
            random_state=42,
            n_init=3
        )
        kmeans.fit(all_embeddings)
        report_memory = torch.from_numpy(kmeans.cluster_centers_).float()
    else:
        # 如果句子数量不足，直接使用所有嵌入
        report_memory = torch.from_numpy(all_embeddings).float()

    # 保存
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'wb') as f:
        pickle.dump(report_memory, f)

    print(f"[Report Memory] Saved: {report_memory.shape} -> {output_path}")
    return report_memory


# ==============================================================================
# [Disease Memory] 视觉特征聚类
# ==============================================================================
def generate_disease_memory(args, model, loader, output_path, n_clusters=2048, max_batches=2000):
    """提取视觉特征并聚类"""
    print(f"\n[Disease Memory] Generating from visual features...")
    device = torch.device('cuda')

    kmeans = MiniBatchKMeans(
        n_clusters=n_clusters,
        batch_size=2048,
        random_state=42,
        n_init=1
    )

    init_buffer = []
    initialized = False

    with torch.no_grad():
        for i, images in tqdm(enumerate(loader), total=min(len(loader), max_batches), desc="Extracting visual"):
            B = images.shape[0]
            V = images.shape[1]
            images = images.to(device).view(B * V, 3, 224, 224)

            m_feat = model(images)
            flat_m = m_feat.reshape(-1, m_feat.size(-1)).cpu().numpy()

            if not initialized:
                init_buffer.append(flat_m)
                current_total = np.concatenate(init_buffer, axis=0)
                if current_total.shape[0] >= n_clusters * 10:
                    kmeans.partial_fit(current_total)
                    initialized = True
                    init_buffer = []
                    print(f"\n[Disease] Initialized with {current_total.shape[0]} samples.")
            else:
                kmeans.partial_fit(flat_m)

            if i >= max_batches:
                break

    # 保存
    disease_memory = torch.from_numpy(kmeans.cluster_centers_).float()
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, 'wb') as f:
        pickle.dump(disease_memory, f)

    print(f"[Disease Memory] Saved: {disease_memory.shape} -> {output_path}")
    return disease_memory


# ==============================================================================
# [主流程]
# ==============================================================================
def main():
    parser = argparse.ArgumentParser(description="Generate AM-MRG Memory Banks (Disease + Report)")

    # IU X-ray 参数
    parser.add_argument('--image_dir', type=str, required=True,
                        help='IU X-ray image directory')
    parser.add_argument('--ann_path', type=str, required=True,
                        help='IU X-ray annotation path')

    # MIMIC 参数
    parser.add_argument('--mimic_image_dir', type=str,
                        default='/root/autodl-tmp/mimic_cxr/images',
                        help='MIMIC-CXR image directory')
    parser.add_argument('--mimic_ann_path', type=str,
                        default='/root/autodl-tmp/mimic_cxr/annotation.json',
                        help='MIMIC-CXR annotation path')

    # 模型参数
    parser.add_argument('--checkpoint', type=str,
                        default='/root/autodl-tmp/Stage1ckpt.pth',
                        help='Stage1 pretrained checkpoint')
    parser.add_argument('--cfg', type=str, required=True,
                        help='Config JSON file path')

    # 输出参数
    parser.add_argument('--output_dir', type=str,
                        default='data/iu_xray',
                        help='Output directory for memory banks')
    parser.add_argument('--disease_memory_name', type=str,
                        default='disease_memory_mixed.pkl',
                        help='Disease memory filename')
    parser.add_argument('--report_memory_name', type=str,
                        default='report_memory_mixed.pkl',
                        help='Report memory filename')

    # Memory 参数
    parser.add_argument('--n_clusters', type=int, default=2048,
                        help='Number of cluster centers')
    parser.add_argument('--batch_size', type=int, default=32,
                        help='Batch size for visual extraction')
    parser.add_argument('--num_workers', type=int, default=8,
                        help='DataLoader workers')
    parser.add_argument('--max_batches', type=int, default=2000,
                        help='Max batches for visual extraction')

    # 跳过选项
    parser.add_argument('--skip_disease', action='store_true',
                        help='Skip disease memory generation')
    parser.add_argument('--skip_report', action='store_true',
                        help='Skip report memory generation')

    args = parser.parse_args()

    # 输出路径
    disease_output = os.path.join(args.output_dir, args.disease_memory_name)
    report_output = os.path.join(args.output_dir, args.report_memory_name)

    print("=" * 60)
    print("AM-MRG Memory Bank Generator")
    print("=" * 60)
    print(f"IU X-Ray: {args.ann_path}")
    print(f"MIMIC-CXR: {args.mimic_ann_path}")
    print(f"Output Dir: {args.output_dir}")
    print(f"Disease Memory -> {disease_output}")
    print(f"Report Memory -> {report_output}")
    print("=" * 60)

    # ========================================================================
    # 1. 生成 Report Memory (文本语义嵌入)
    # ========================================================================
    if not args.skip_report:
        print("\n" + "=" * 60)
        print("STEP 1: Generating Report Memory (Text Embeddings)")
        print("=" * 60)

        sentences = extract_sentences_from_annotations(
            iu_ann_path=args.ann_path,
            mimic_ann_path=args.mimic_ann_path,
            max_sentences=100000
        )

        generate_report_memory(
            sentences=sentences,
            output_path=report_output,
            n_clusters=args.n_clusters,
            batch_size=64
        )
    else:
        print("\n[Skip] Report Memory generation skipped.")

    # ========================================================================
    # 2. 生成 Disease Memory (视觉特征聚类)
    # ========================================================================
    if not args.skip_disease:
        print("\n" + "=" * 60)
        print("STEP 2: Generating Disease Memory (Visual Features)")
        print("=" * 60)

        device = torch.device('cuda')

        # Config Hijack
        try:
            import SwinCheX.config as swin_config_module
            from yacs.config import CfgNode as CN
            def patched_update_config(config, args_obj):
                config.defrost()
                if not hasattr(config, 'NIH'):
                    config.NIH = CN()
                config.NIH.num_mlp_heads = 1
                config.NIH.num_classes = 14
                config.freeze()
                return config

            swin_config_module.update_config = patched_update_config
        except:
            pass

        with open(args.cfg, 'r') as f:
            full_config = json.load(f)

        transformers.AutoModelForCausalLM.from_pretrained = classmethod(
            lambda *a, **k: torch.nn.Module()
        )
        transformers.AutoConfig.from_pretrained = classmethod(
            lambda *a, **k: MagicMock(hidden_size=4096)
        )

        for k, v in full_config.get('model', {}).items():
            setattr(args, k, v)

        # 初始化模型
        print("[Disease] Initializing CMNet Extractor...")
        model = CMNet_Extractor(args)

        if os.path.exists(args.checkpoint):
            print(f"[Disease] Loading checkpoint: {args.checkpoint}")
            ckpt = torch.load(args.checkpoint, map_location='cpu')
            sd = ckpt.get('state_dict', ckpt)
            new_sd = {}
            for k, v in sd.items():
                k_clean = k.replace('module.', '')
                if 'visual_encoder' in k_clean or 'visual_mining' in k_clean:
                    new_sd[k_clean] = v
            msg = model.load_state_dict(new_sd, strict=False)
            print(f"[Disease] Weights loaded. Missing: {len(msg.missing_keys)}")

        model = model.to(device).eval()

        # Transform
        val_transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))
        ])

        # Dataset
        print("[Disease] Initializing Mixed Dataset...")
        dataset = MixedExtractionDataset(
            iu_ann_path=args.ann_path,
            iu_image_dir=args.image_dir,
            mimic_ann_path=args.mimic_ann_path,
            mimic_image_dir=args.mimic_image_dir,
            transform=val_transform
        )

        loader = DataLoader(
            dataset,
            batch_size=args.batch_size,
            shuffle=True,
            num_workers=args.num_workers
        )

        generate_disease_memory(
            args=args,
            model=model,
            loader=loader,
            output_path=disease_output,
            n_clusters=args.n_clusters,
            max_batches=args.max_batches
        )
    else:
        print("\n[Skip] Disease Memory generation skipped.")

    # ========================================================================
    # 3. 验证结果
    # ========================================================================
    print("\n" + "=" * 60)
    print("VERIFICATION")
    print("=" * 60)

    if os.path.exists(disease_output):
        with open(disease_output, 'rb') as f:
            d_mem = pickle.load(f)
        print(f"✓ Disease Memory: {d_mem.shape}")
    else:
        print(f"✗ Disease Memory not found: {disease_output}")

    if os.path.exists(report_output):
        with open(report_output, 'rb') as f:
            r_mem = pickle.load(f)
        print(f"✓ Report Memory: {r_mem.shape}")
    else:
        print(f"✗ Report Memory not found: {report_output}")

    # 检查是否相同
    if os.path.exists(disease_output) and os.path.exists(report_output):
        same_check = torch.allclose(d_mem, r_mem)
        if same_check:
            print("⚠ WARNING: Disease and Report Memory are identical!")
        else:
            print("✓ Disease and Report Memory are different (correct)")

    print("\n" + "=" * 60)
    print("DONE! Memory banks generated successfully.")
    print("=" * 60)
    print(f"\nUpdate your config with:")
    print(f'  "disease_memory_path": "{disease_output}"')
    print(f'  "report_memory_path": "{report_output}"')
    print(f'  "disease_mem_size": {args.n_clusters}')
    print(f'  "report_mem_size": {args.n_clusters}')
    print(f'  "memory_dim": 768')


if __name__ == '__main__':
    main()
