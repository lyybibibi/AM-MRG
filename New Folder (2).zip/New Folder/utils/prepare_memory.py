import torch
import pickle
import numpy as np
import argparse
import random
import os


def process_disease_memory(ckpt_path, cam_path, save_path, maps_num=10):
    """
    合并 Stage1 的 Disease Tokens 和 CAM 特征，构建视觉记忆库 (Visual Memory)
    逻辑参考: AM-MRG/models/AM_MRG.py
    """
    print(f"[1/2] Processing Disease Memory...")

    # 1. 提取 Disease Tokens (从 Stage1 Checkpoint)
    disease_tokens = None
    if os.path.exists(ckpt_path):
        print(f"Loading checkpoint: {ckpt_path}")
        try:
            checkpoint = torch.load(ckpt_path, map_location='cpu')
            state_dict = checkpoint['model'] if 'model' in checkpoint else checkpoint

            # 查找 disease_tokens 权重
            for k, v in state_dict.items():
                if 'disease_tokens' in k:
                    disease_tokens = v
                    # [修复关键点] 如果是 3维 [1, 14, 768]，需要压缩成 2维 [14, 768]
                    if disease_tokens.dim() == 3:
                        disease_tokens = disease_tokens.squeeze(0)
                    print(f"  - Found disease_tokens: {disease_tokens.shape}")
                    break
        except Exception as e:
            print(f"  ! Error loading checkpoint: {e}")
    else:
        print(f"  ! Warning: Checkpoint not found at {ckpt_path}")

    # 2. 提取 CAM Features
    cam_features = None
    if os.path.exists(cam_path):
        print(f"Loading CAM: {cam_path}")
        try:
            with open(cam_path, 'rb') as f:
                cam_dict = pickle.load(f)

            # 采样并堆叠 (参考 AM_MRG.py 的逻辑)
            all_arrays = []
            for label, val_list in cam_dict.items():
                # 如果样本数不够，就取全部；否则随机采样 maps_num 个
                if len(val_list) > 0:
                    selected = random.sample(list(val_list), maps_num) if len(val_list) > maps_num else list(val_list)
                    all_arrays.extend(selected)

            if len(all_arrays) > 0:
                cam_features = torch.from_numpy(np.stack(all_arrays))  # [N, 768]
                # 确保是 Float 类型
                cam_features = cam_features.float()
                print(f"  - Processed CAM features: {cam_features.shape}")
        except Exception as e:
            print(f"  ! Error loading CAM: {e}")
    else:
        print(f"  ! Warning: CAM file not found at {cam_path}")

    # 3. 合并
    final_memory = []
    if disease_tokens is not None:
        final_memory.append(disease_tokens)
    if cam_features is not None:
        final_memory.append(cam_features)

    if len(final_memory) > 0:
        # 拼接成一个大的 Memory Bank [M, D]
        # 现在两个 tensor 应该都是 2维 [N, 768] 了
        try:
            memory_tensor = torch.cat(final_memory, dim=0)

            # 保存前再次确认目录存在
            os.makedirs(os.path.dirname(save_path), exist_ok=True)

            with open(save_path, 'wb') as f:
                pickle.dump(memory_tensor, f)
            print(f"  -> Saved Disease Memory to {save_path} (Shape: {memory_tensor.shape})")
        except Exception as e:
            print(f"  ! Error during concatenation: {e}")
            print(f"  ! Shapes: {[t.shape for t in final_memory]}")
    else:
        print("  ! Error: Failed to create disease memory.")


def process_report_memory(report_path, save_path, max_samples=2000):
    """
    处理 Report Memory，构建语言记忆库 (Linguistic Memory)
    逻辑参考: AM-MRG/models/report_memory_generation.py
    """
    print(f"\n[2/2] Processing Report Memory...")

    if os.path.exists(report_path):
        try:
            with open(report_path, 'rb') as f:
                data = pickle.load(f)

            # data 是一个 dict {label: numpy_array([N, D])}
            all_feats = []
            if isinstance(data, dict):
                for k, v in data.items():
                    if len(v) > 0:
                        all_feats.append(v)

            if len(all_feats) > 0:
                # 堆叠所有报告特征
                combined = np.vstack(all_feats)
                combined = torch.from_numpy(combined).float()  # 确保转为 float Tensor

                # 随机采样以控制显存占用
                if combined.shape[0] > max_samples:
                    indices = torch.randperm(combined.shape[0])[:max_samples]
                    combined = combined[indices]

                # 保存前再次确认目录存在
                os.makedirs(os.path.dirname(save_path), exist_ok=True)

                with open(save_path, 'wb') as f:
                    pickle.dump(combined, f)
                print(f"  -> Saved Report Memory to {save_path} (Shape: {combined.shape})")
            else:
                print("  ! Error: Report memory dict is empty.")
        except Exception as e:
            print(f"  ! Error processing report memory: {e}")
    else:
        print(f"  ! Error: Report memory file not found at {report_path}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    # 输入路径 (下载的文件)
    parser.add_argument('--ckpt', type=str, required=True, help='Path to AM-MRG Stage1ckpt.pth')
    parser.add_argument('--cam', type=str, required=True, help='Path to AM-MRG CAM.pkl')
    parser.add_argument('--report', type=str, required=True, help='Path to AM-MRG Report_Memory.pkl')

    # 输出路径 (处理后的文件)
    parser.add_argument('--out_dir', type=str, default='data/mimic_cxr', help='Directory to save processed memories')

    args = parser.parse_args()

    process_disease_memory(args.ckpt, args.cam, os.path.join(args.out_dir, 'disease_memory_processed.pkl'))
    process_report_memory(args.report, os.path.join(args.out_dir, 'report_memory_processed.pkl'))