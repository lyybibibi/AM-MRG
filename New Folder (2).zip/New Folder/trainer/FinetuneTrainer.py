"""
Finetune trainer for report generation
"""
import pandas as pd
from .BaseTrainer import BaseTrainer
import numpy as np
import torch
import time
from trainer.PretrainTrainer import unpatchify, vis_heatmap
from utils.loss import patchify
import os
from tqdm import tqdm

# [修改 1] 类名改为 FinetuneTrainer
class FinetuneTrainer(BaseTrainer):
    def __init__(self, model, criterion, metric_ftns, optimizer, args, lr_scheduler, train_dataloader, val_dataloader,
                 test_dataloader):
        super(FinetuneTrainer, self).__init__(model, criterion, metric_ftns, optimizer, args)
        self.lr_scheduler = lr_scheduler
        self.train_dataloader = train_dataloader
        self.val_dataloader = val_dataloader
        self.test_dataloader = test_dataloader
        self.best_score = 0.

        # [修改 2] 安全加载权重（防止空路径报错）
        if args["load_model_path"] and args["load_model_path"] != "":
            print(f"Loading pretrained model from: {args['load_model_path']}")
            try:
                checkpoint = torch.load(args["load_model_path"], map_location='cuda')
                if 'state_dict' in checkpoint:
                    pretrained_dict = checkpoint['state_dict']
                else:
                    pretrained_dict = checkpoint

                # 过滤不匹配的参数
                model_dict = self.model.state_dict()
                pretrained_dict = {k: v for k, v in pretrained_dict.items() if k in model_dict and model_dict[k].shape == v.shape}

                self.model.load_state_dict(pretrained_dict, strict=False)
                print(f"Pretrained weights loaded successfully! ({len(pretrained_dict)} keys)")
            except Exception as e:
                print(f"[Error] Failed to load weights: {e}")
        else:
            print("[Info] No 'load_model_path' provided. Training from scratch (Cold Start).")

    def _train_epoch(self, epoch):
        train_loss = 0
        self.model.train()
        start_time = time.time()

        with tqdm(self.train_dataloader, desc=f"Epoch {epoch}", ncols=120) as pbar:
            for batch_idx, (images_id, images, reports_ids, reports_masks) in enumerate(pbar):
                images, reports_ids, reports_masks = images.cuda(), reports_ids.cuda(), reports_masks.cuda()

                # [修改 3] 删除了 B=... 参数！这是导致 TypeError 的元凶
                output = self.model(images, reports_ids, mode='train')

                nll_loss = self.criterion(output, reports_ids, reports_masks)
                loss = nll_loss
                self.optimizer.zero_grad()
                loss.backward()
                train_loss += loss.item()
                torch.nn.utils.clip_grad_value_(self.model.parameters(), 0.1)
                self.optimizer.step()

                pbar.set_postfix(loss=f"{loss.item():.3f}")

                if self.args["lr_scheduler"] != 'StepLR':
                    self.lr_scheduler.step()

        if self.args["lr_scheduler"] == 'StepLR':
            self.lr_scheduler.step()

        log = {'train_loss': train_loss / len(self.train_dataloader)}
        print("\tEpoch {}\tmean_loss: {:.4f}\ttime: {:.4f}s".format(epoch, log['train_loss'], time.time() - start_time))

        # === 验证 ===
        self.model.eval()
        with torch.no_grad():
            val_gts, val_res = [], []
            print("Validating...")
            for batch_idx, (images_id, images, reports_ids, reports_masks) in enumerate(tqdm(self.val_dataloader, desc="Val")):
                images, reports_ids, reports_masks = images.cuda(), reports_ids.cuda(), reports_masks.cuda()
                output = self.model(images, mode='sample')
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())
                val_res.extend(reports)
                val_gts.extend(ground_truths)

            val_met = self.metric_ftns({i: [gt] for i, gt in enumerate(val_gts)},
                                       {i: [re] for i, re in enumerate(val_res)})
            for k, v in val_met.items():
                self.monitor.logkv(key='val_' + k, val=v)
            log.update(**{'val_' + k: v for k, v in val_met.items()})

        # === 测试 ===
        self.model.eval()
        with torch.no_grad():
            test_gts, test_res = [], []
            print("Testing...")
            for batch_idx, (images_id, images, reports_ids, reports_masks) in enumerate(tqdm(self.test_dataloader, desc="Test")):
                images, reports_ids, reports_masks = images.cuda(), reports_ids.cuda(), reports_masks.cuda()
                output = self.model(images, mode='sample')
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())
                test_res.extend(reports)
                test_gts.extend(ground_truths)

            test_met = self.metric_ftns({i: [gt] for i, gt in enumerate(test_gts)},
                                        {i: [re] for i, re in enumerate(test_res)})
            for k, v in test_met.items():
                self.monitor.logkv(key='test_' + k, val=v)
            log.update(**{'test_' + k: v for k, v in test_met.items()})

        if self.args['monitor_metric_curves']:
            self.monitor.plot_current_metrics(epoch, self.monitor.name2val)
        self.monitor.dumpkv(epoch)
        return log

    def test_epoch(self):
        self.model.eval()
        with torch.no_grad():
            test_gts, test_res, img_ids = [], [], []
            for batch_idx, (images_id, images, reports_ids, reports_masks) in enumerate(self.test_dataloader):
                images, reports_ids, reports_masks = images.cuda(), reports_ids.cuda(), reports_masks.cuda()
                output = self.model(images, mode='sample')
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())
                test_res.extend(reports)
                test_gts.extend(ground_truths)
                print(f"\rTest Processing: [{int((batch_idx + 1) / len(self.test_dataloader) * 100)}%]", end='', flush=True)

            test_met = self.metric_ftns({i: [gt] for i, gt in enumerate(test_gts)},
                                        {i: [re] for i, re in enumerate(test_res)})
            save_report(test_res, test_gts, img_ids, os.path.join(self.checkpoint_dir, 'report.csv'))
            print(test_met)

    # 保留其他辅助函数...
    def local_feature(self, idx): pass
    def keyword_feature(self, idx): pass
    def extract(self): pass
    def select_feature(self, h, images_id): pass

def count_p(p): return torch.unique(p, dim=0), torch.unique(p, dim=0).size(0)
def mark_local(img, inx): pass
def encoder_heatmap(img, attn): pass
def decoder_heatmap(img, attn): pass
def save_report(inference, reference, ids, output_dir):
    df = pd.DataFrame({'Report Impression': inference})
    df.to_csv(output_dir)