# modules/knowledge_retriever_radar.py
import json
import os
from typing import Dict, List, Any, Optional, Tuple

import torch
import torch.nn as nn


class RadarJsonlIndex(object):
    """
    Load RADAR-style retrieval results:
    each line: {"id": <sample_id>, "retrieved": [<id1>, <id2>, ...]}

    This is exactly the output format in:
    RADAR-main/annotate_retrieve/retrieve.py  (you uploaded)
    """
    def __init__(self, jsonl_path: str):
        if not os.path.exists(jsonl_path):
            raise FileNotFoundError(
                f"[RadarJsonlIndex] jsonl not found: {jsonl_path}\n"
                f"RADAR retrieval script produces: knowledge_[split].jsonl"
            )
        self.jsonl_path = jsonl_path
        self.map: Dict[str, List[str]] = {}
        self._load()

    def _load(self):
        with open(self.jsonl_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                sid = str(obj["id"])
                retrieved = obj.get("retrieved", [])
                retrieved = [str(x) for x in retrieved]
                self.map[sid] = retrieved

    def get(self, sample_id: str, topk: int) -> List[str]:
        ids = self.map.get(str(sample_id), [])
        if topk <= 0:
            return []
        return ids[:topk]


class AnnotationReportBank(object):
    """
    Minimal report bank from your dataset annotation.json.
    Requirement:
      - must be able to map sample_id -> report string (or token list).
    Your IU-Xray annotation.json usually has something like:
      ann["train"][i]["id"] and ann["train"][i]["report"] / "report"
    But different repos vary, so this class supports a few common keys.
    """
    def __init__(self, ann_path: str):
        if not os.path.exists(ann_path):
            raise FileNotFoundError(f"[AnnotationReportBank] annotation not found: {ann_path}")
        self.ann_path = ann_path
        self.id2report: Dict[str, str] = {}
        self._load()

    def _load(self):
        with open(self.ann_path, "r", encoding="utf-8") as f:
            ann = json.load(f)

        # Common patterns:
        # 1) {"train":[{...}], "val":[...], "test":[...]}
        # 2) {"annotations":[{...}]} etc.
        candidates = []
        if isinstance(ann, dict):
            if "train" in ann and isinstance(ann["train"], list):
                candidates.extend(ann["train"])
            if "val" in ann and isinstance(ann["val"], list):
                candidates.extend(ann["val"])
            if "test" in ann and isinstance(ann["test"], list):
                candidates.extend(ann["test"])
            if "annotations" in ann and isinstance(ann["annotations"], list):
                candidates.extend(ann["annotations"])
        elif isinstance(ann, list):
            candidates = ann

        def pick_report(obj: Dict[str, Any]) -> Optional[str]:
            # Try common keys without simplifying logic.
            for k in ["report", "caption", "findings", "impression", "text"]:
                if k in obj and isinstance(obj[k], str) and len(obj[k]) > 0:
                    return obj[k]
            # Some datasets store as list of sentences
            for k in ["report", "caption", "text"]:
                if k in obj and isinstance(obj[k], list):
                    try:
                        return " ".join([str(x) for x in obj[k]])
                    except Exception:
                        pass
            return None

        for obj in candidates:
            if not isinstance(obj, dict):
                continue
            # id keys
            sid = None
            for k in ["id", "image_id", "study_id", "uid"]:
                if k in obj:
                    sid = str(obj[k])
                    break
            if sid is None:
                continue
            rep = pick_report(obj)
            if rep is None:
                continue
            self.id2report[sid] = rep

    def get_report(self, sample_id: str) -> str:
        return self.id2report.get(str(sample_id), "")


class RadarKnowledgeRetriever(nn.Module):
    """
    RADAR-style retriever used at *training/inference time*:
    - read precomputed retrieved ids from knowledge_[split].jsonl
    - fetch the corresponding reports from annotation.json
    - encode reports to K tensor for evidence injection

    Note:
    - This retriever does NOT implement the ExpertModel+KL retrieval online
      (RADAR does that offline to generate jsonl).
    - That is consistent with RADAR pipeline.
    """
    def __init__(
        self,
        knowledge_jsonl_path: str,
        ann_path: str,
        text_embed: nn.Module,
        max_seq_length: int,
        pad_idx: int,
        topk: int = 4,
    ):
        super(RadarKnowledgeRetriever, self).__init__()
        self.index = RadarJsonlIndex(knowledge_jsonl_path)
        self.bank = AnnotationReportBank(ann_path)

        self.text_embed = text_embed
        self.max_seq_length = int(max_seq_length)
        self.pad_idx = int(pad_idx)
        self.topk = int(topk)

        # if you want a small projection/gate later, keep it in caller (decoder side)
        # Here we only produce K in embed space.

    def _encode_report_with_project_tokenizer(
        self,
        tokenizer,
        report_text: str,
        device: torch.device
    ) -> torch.Tensor:
        """
        Encode report text into token ids using YOUR project tokenizer (mix tokenizer in your repo).
        Return shape: [L]
        """
        # Your project tokenizer usually has encode() / __call__ output ids.
        # Keep defensive checks without simplifying:
        if report_text is None:
            report_text = ""
        if hasattr(tokenizer, "encode"):
            ids = tokenizer.encode(report_text)
        elif callable(tokenizer):
            out = tokenizer(report_text)
            # out may be dict or list
            if isinstance(out, dict) and "input_ids" in out:
                ids = out["input_ids"]
            else:
                ids = out
        else:
            ids = []

        # ids -> list[int]
        if isinstance(ids, torch.Tensor):
            ids = ids.detach().cpu().tolist()
        if not isinstance(ids, list):
            try:
                ids = list(ids)
            except Exception:
                ids = []

        # truncate/pad
        ids = ids[: self.max_seq_length]
        if len(ids) < self.max_seq_length:
            ids = ids + [self.pad_idx] * (self.max_seq_length - len(ids))
        return torch.tensor(ids, dtype=torch.long, device=device)

    def forward(
        self,
        sample_ids: List[str],
        split: str,
        tokenizer,
        device: torch.device,
    ) -> torch.Tensor:
        """
        Return K: [B, topk, D]
        Each retrieved report is mean-pooled into one vector (no simplification of batch logic).

        sample_ids: list of str, len=B
        split: "train"/"val"/"test" used to load corresponding knowledge file
              (you can instantiate different retrievers per split; here we assume one jsonl path per instance)
        """
        B = len(sample_ids)
        topk = self.topk

        # Prepare tensor container
        # We'll create [B, topk, L] token ids, then embed -> [B, topk, L, D] -> mean -> [B, topk, D]
        all_token_ids = []
        for sid in sample_ids:
            retrieved_ids = self.index.get(str(sid), topk=topk)
            # if not enough retrieved, pad with itself / empty
            if len(retrieved_ids) < topk:
                retrieved_ids = retrieved_ids + [str(sid)] * (topk - len(retrieved_ids))

            sid_token_ids = []
            for rid in retrieved_ids:
                rep = self.bank.get_report(str(rid))
                token_ids = self._encode_report_with_project_tokenizer(tokenizer, rep, device=device)
                sid_token_ids.append(token_ids)
            sid_token_ids = torch.stack(sid_token_ids, dim=0)  # [topk, L]
            all_token_ids.append(sid_token_ids)

        token_ids_batch = torch.stack(all_token_ids, dim=0)  # [B, topk, L]
        B2, K, L = token_ids_batch.shape
        if B2 != B or K != topk or L != self.max_seq_length:
            raise RuntimeError(
                f"[RadarKnowledgeRetriever] token_ids shape unexpected: {token_ids_batch.shape}"
            )

        # Embed using project text_embed: expects [*, L] -> [*, L, D]
        token_ids_flat = token_ids_batch.reshape(B * topk, L)  # [B*topk, L]
        emb = self.text_embed(token_ids_flat)  # [B*topk, L, D]
        D = emb.size(-1)
        emb = emb.reshape(B, topk, L, D)

        # attention mask for padding
        mask = (token_ids_batch != self.pad_idx).float()  # [B, topk, L]
        mask_sum = mask.sum(dim=-1, keepdim=True).clamp(min=1.0)  # [B, topk, 1]

        # mean pooling (keep it explicit)
        emb = emb * mask.unsqueeze(-1)  # [B, topk, L, D]
        pooled = emb.sum(dim=2) / mask_sum  # [B, topk, D]

        return pooled
