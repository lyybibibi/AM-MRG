import torch
import torch.nn as nn
import torch.nn.functional as F
from modules.modules4transformer import EncoderLayer, SublayerConnection, \
    MultiHeadedAttention, LayerNorm, PositionwiseFeedForward, clones
from modules.coatnet import Transformer as DownSamplingTrans
import math


# ... (AF, FDIntervention, LGFM, CrossLayer, PartAttention, LocalSample, GlobalSample, CausalAttention, CaaMSublayerConnection, CaaM, VDM, LDM 保持原样) ...
# 请确保保留上面的所有类定义

class AF(nn.Module):
    def __init__(self, embed_dim):
        super(AF, self).__init__()
        self.embed_dim = embed_dim
        self.q = nn.Linear(embed_dim, embed_dim)
        self.out = nn.Linear(embed_dim, embed_dim)

    def forward(self, q, k, v, proj=False):
        if proj:
            q = self.q(q)
            qk = torch.matmul(q, k.transpose(-1, -2)) / math.sqrt(self.embed_dim)
            score = qk.softmax(dim=-1)
            out = score.matmul(v)
            out = self.out(out)
        else:
            qk = torch.matmul(q, k.transpose(-1, -2))
            score = qk.softmax(dim=-1)
            out = score.matmul(v)
        return out


class FDIntervention(nn.Module):
    def __init__(self, embed_dim):
        super(FDIntervention, self).__init__()
        self.embed_dim = embed_dim
        self.af_1 = AF(embed_dim)
        self.af_2 = AF(embed_dim)

    def forward(self, feature, mediator, proj=False):
        v = self.af_1(mediator, feature, feature, proj)
        out = self.af_2(feature, mediator, v, proj)
        return out


class LGFM(nn.Module):
    def __init__(self, embed_dim):
        super(LGFM, self).__init__()
        self.embed_dim = embed_dim
        self.norm_l = LayerNorm(embed_dim)
        self.norm_g = LayerNorm(embed_dim)
        self.gelu = nn.GELU()
        self.llf = MultiHeadedAttention(8, embed_dim)
        self.lgf = MultiHeadedAttention(8, embed_dim)
        self.proj = nn.Linear(embed_dim * 2, embed_dim)
        self.norm = LayerNorm(embed_dim)
        self.fc = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 4),
            nn.Linear(embed_dim * 4, embed_dim),
        )

    def forward(self, fl, fg):
        fl = self.norm_l(fl)
        fg = self.norm_g(fg)
        fll = fl + self.llf(fl, fl, fl)
        flg = fl + self.lgf(fl, fg, fg)
        out = self.proj(torch.cat([fll, flg], dim=-1))
        out = self.norm(out)
        out = out + self.fc(out)
        return out


class CrossLayer(EncoderLayer):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super(CrossLayer, self).__init__(embed_dim, num_heads, ff_dim, dropout)

    def forward(self, x, y):
        x = self.sublayer_attn(x, lambda x: self.attn(x, y, y, None))
        x = self.sublayer_ff(x, self.feed_forward)
        return x


class PartAttention(nn.Module):
    def __init__(self):
        super(PartAttention, self).__init__()

    def forward(self, x, k=6):
        length = len(x)
        last_map = x[0]
        for i in range(1, length):
            last_map = torch.matmul(x[i], last_map)
        last_map = last_map[:, :, 0, 1:]
        max_attn, max_inx = last_map.sort(2, descending=True)
        max_inx = max_inx[:, :, :k].reshape([last_map.size(0), -1])
        max_attn = max_attn[:, :, :k].reshape([last_map.size(0), -1])
        return max_attn, max_inx


class LocalSample(nn.Module):
    def __init__(
            self,
            embed_dim,
            num_heads,
            ff_dim,
            dropout=0.,
            use_cmqfl=False,
            cmqfl_num_query_token=6,
            cmqfl_vision_width=None,
            cmqfl_cross_attention_freq=2,
            cmqfl_freeze=True,
            cmqfl_fuse="replace",
            cmqfl_use_caam=True,
    ):
        super(LocalSample, self).__init__()
        self.part_select = PartAttention()
        self.causal_layer = CaaM(embed_dim, num_heads, ff_dim, dropout)

        self.use_cmqfl = bool(use_cmqfl)

        self._cmqfl_available = False
        self.cmqfl = None
        self.query_tokens = None
        self.cmqfl_proj = None

        if self.use_cmqfl:
            try:
                from modules.inverge_qformer import BertConfig, BertLMHeadModel
                self._cmqfl_available = True
            except ImportError:
                print("Warning: CMQFL modules not found, stitching disabled.")
                self.use_cmqfl = False

            if self._cmqfl_available:
                if cmqfl_vision_width is None:
                    cmqfl_vision_width = embed_dim

                encoder_config = BertConfig.from_pretrained("bert-large-uncased")
                encoder_config.encoder_width = int(cmqfl_vision_width)
                encoder_config.add_cross_attention = True
                encoder_config.cross_attention_freq = int(cmqfl_cross_attention_freq)
                encoder_config.query_length = int(cmqfl_num_query_token)

                self.cmqfl = BertLMHeadModel(config=encoder_config)
                self.query_tokens = nn.Parameter(
                    torch.zeros(1, int(cmqfl_num_query_token), encoder_config.hidden_size)
                )
                self.query_tokens.data.normal_(mean=0.0, std=encoder_config.initializer_range)

                if encoder_config.hidden_size != embed_dim:
                    self.cmqfl_proj = nn.Linear(encoder_config.hidden_size, embed_dim)
                else:
                    self.cmqfl_proj = nn.Identity()

                if bool(cmqfl_freeze):
                    for param in self.cmqfl.parameters():
                        param.requires_grad = False
                    self.cmqfl.eval()
                    self.query_tokens.requires_grad = False

                self.concat_proj = nn.Linear(embed_dim * 2, embed_dim)
                self.gate_norm = LayerNorm(embed_dim * 2)
                self.gate_fc = nn.Sequential(
                    nn.Linear(embed_dim * 2, embed_dim),
                    nn.GELU(),
                    nn.Linear(embed_dim, 1),
                    nn.Sigmoid()
                )

        self.cmqfl_fuse = str(cmqfl_fuse)
        self.cmqfl_use_caam = bool(cmqfl_use_caam)

    def _forward_original(self, x, attn, k):
        part_attn, part_inx = self.part_select(attn, k)
        part_inx = part_inx + 1
        parts = []
        B, num = part_inx.shape
        for i in range(B):
            parts.append(x[i, part_inx[i, :]])
        fl = torch.stack(parts).squeeze(1)
        fl = torch.cat([x[:, :1], fl], dim=1)
        fl = self.causal_layer(fl)[:, 1:]
        return fl

    def _forward_cmqfl(self, x, k):
        img = x[:, 1:, :]
        B, Lm1, D = img.size()
        image_atts = torch.ones(img.size()[:-1], dtype=torch.long, device=img.device)
        query_tokens = self.query_tokens.expand(B, -1, -1).to(img.device)

        query_output = self.cmqfl.bert(
            query_embeds=query_tokens,
            encoder_hidden_states=img,
            encoder_attention_mask=image_atts,
            return_dict=True
        )
        fl_new = query_output.last_hidden_state
        fl_new = self.cmqfl_proj(fl_new)

        if fl_new.size(1) != k:
            fl_new = fl_new[:, :k, :]

        if self.cmqfl_use_caam:
            fl_caam = torch.cat([x[:, :1], fl_new], dim=1)
            fl_new = self.causal_layer(fl_caam)[:, 1:]
        return fl_new

    def _fuse(self, fl_old, fl_new):
        if self.cmqfl_fuse == "replace":
            fl = fl_new
        elif self.cmqfl_fuse == "concat":
            fl = self.concat_proj(torch.cat([fl_old, fl_new], dim=-1))
        elif self.cmqfl_fuse == "gate":
            cat = torch.cat([fl_old, fl_new], dim=-1)
            cat = self.gate_norm(cat)
            g = self.gate_fc(cat)
            fl = g * fl_new + (1.0 - g) * fl_old
        else:
            fl = fl_old
        return fl

    def _align_k(self, fl, k):
        if fl is None: return fl
        if fl.dim() != 3: return fl
        B, T, D = fl.size()
        if T == k: return fl
        if T > k: return fl[:, :k, :]
        pad_num = k - T
        pad_token = fl[:, -1:, :].repeat(1, pad_num, 1)
        fl = torch.cat([fl, pad_token], dim=1)
        return fl

    def forward(self, x, attn, k):
        fl_old = self._forward_original(x, attn, k)
        if self.use_cmqfl:
            fl_new = self._forward_cmqfl(x, k)
            fl = self._fuse(fl_old, fl_new)
        else:
            fl = fl_old
        fl = self._align_k(fl, k)
        return fl


class GlobalSample(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super(GlobalSample, self).__init__()
        self.global_sample = DownSamplingTrans(embed_dim, embed_dim, (7, 7), downsample=True)

    def forward(self, x):
        img = x[:, 1:, :]
        B, L, N = img.size()
        img = img.reshape([-1, 14, 14, N])
        img = img.permute(0, 3, 1, 2)
        img = self.global_sample(img)
        img = img.permute(0, 2, 3, 1)
        fg = img.reshape([B, -1, N])
        return fg


class CausalAttention(nn.Module):
    def __init__(self, h, d_model, dropout=0.1):
        super(CausalAttention, self).__init__()
        assert d_model % h == 0
        self.d_k = d_model // h
        self.h = h
        self.linears = clones(nn.Linear(d_model, d_model), 4)
        self.attn = None
        self.dropout = nn.Dropout(p=dropout)

    def forward(self, x):
        q = x
        k = x
        v = x
        nbatches = q.size(0)
        q, k, v = \
            [l(x).view(nbatches, -1, self.h, self.d_k).transpose(1, 2)
             for l, x in zip(self.linears, (q, k, v))]
        d_k = q.size(-1)
        scores = torch.matmul(q, k.transpose(-2, -1)) / math.sqrt(d_k)
        p_attn = F.softmax(-scores, dim=-1)
        p_attn_comp = F.softmax(scores, dim=-1)
        self.attn = p_attn
        p_attn = self.dropout(p_attn)
        p_attn_comp = self.dropout(p_attn_comp)
        out = torch.matmul(p_attn, v)
        out = out.transpose(1, 2).contiguous().view(nbatches, -1, self.h * self.d_k)
        out = self.linears[-1](out)
        out_comp = torch.matmul(p_attn_comp, v)
        out_comp = out_comp.transpose(1, 2).contiguous().view(nbatches, -1, self.h * self.d_k)
        out_comp = self.linears[-1](out_comp)
        return out, out_comp


class CaaMSublayerConnection(nn.Module):
    def __init__(self, embed_dim, dropout):
        super(CaaMSublayerConnection, self).__init__()
        self.norm = LayerNorm(embed_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x, sublayer):
        attn, attn_comp = sublayer(self.norm(x))
        attn = self.dropout(attn)
        attn_comp = self.dropout(attn_comp)
        return x + attn, attn_comp


class CaaM(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout):
        super(CaaM, self).__init__()
        self.attn = CausalAttention(num_heads, embed_dim, dropout)
        self.feed_forward = PositionwiseFeedForward(embed_dim, ff_dim, dropout)
        self.sublayer_attn = CaaMSublayerConnection(embed_dim, dropout)
        self.sublayer_ff = SublayerConnection(embed_dim, dropout)

    def forward(self, x, mask=None):
        x, x_comp = self.sublayer_attn(x, lambda x: self.attn(x))
        x = self.sublayer_ff(x, self.feed_forward)
        x = x + self.sublayer_ff(x_comp, self.feed_forward)
        return x


class VDM(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout=.1):
        super(VDM, self).__init__()
        self.fuse = LGFM(embed_dim)
        self.intervene = FDIntervention(embed_dim)

    def forward(self, x, fl=None, fg=None, mode='y', proj=False):
        if mode == 'y':
            mt = self.fuse(fl, fg)
            out = self.intervene(x, mt, proj)
        else:
            out = 0
        return out + x


class LDM(nn.Module):
    def __init__(self, embed_dim):
        super(LDM, self).__init__()
        self.embed_dim = embed_dim
        self.fuse_v = CrossLayer(embed_dim, 8, 4 * embed_dim, .1)
        self.fuse_t = CrossLayer(embed_dim, 8, 4 * embed_dim, .1)
        self.norm = LayerNorm(embed_dim)
        self.intervene = FDIntervention(embed_dim)

    def forward(self, x, text, vis, mode, proj):
        if mode == 'n':
            out = 0
        else:
            mediator = self.fuse_t(vis, text)
            mediator = self.fuse_v(mediator, vis) + mediator
            mediator = self.norm(mediator)
            if mode == 'y':
                out = self.intervene(x, mediator, proj)
            else:
                out = 0
        return out + x


import torch
import torch.nn as nn
import torch.nn.functional as F
from modules.modules4transformer import EncoderLayer, SublayerConnection, \
    MultiHeadedAttention, LayerNorm, PositionwiseFeedForward, clones
from modules.coatnet import Transformer as DownSamplingTrans
import math


# [保留 AF, FDIntervention, LGFM, CrossLayer, PartAttention, LocalSample, GlobalSample, CaaM 等类...]
# ... (为了节省篇幅，请保留原文件的前半部分，只覆盖下面的 EvidenceIntervention)

class EvidenceIntervention(nn.Module):
    def __init__(self, embed_dim, num_heads, ff_dim, dropout=0.1, warmup_epochs=5):
        super(EvidenceIntervention, self).__init__()
        self.embed_dim = embed_dim
        self.warmup_epochs = warmup_epochs

        # 1. Evidence Injection Branch
        self.evidence_attn = MultiHeadedAttention(num_heads, embed_dim, dropout)
        self.evidence_norm1 = LayerNorm(embed_dim)
        self.evidence_dropout1 = nn.Dropout(dropout)
        self.evidence_ffn = PositionwiseFeedForward(embed_dim, ff_dim, dropout)
        self.evidence_norm2 = LayerNorm(embed_dim)
        self.evidence_dropout2 = nn.Dropout(dropout)

        # 2. Confounder Discovery Branch
        self.confound_attn = MultiHeadedAttention(num_heads, embed_dim, dropout)
        self.confound_norm1 = LayerNorm(embed_dim)
        self.confound_dropout1 = nn.Dropout(dropout)
        self.confound_ffn = PositionwiseFeedForward(embed_dim, ff_dim, dropout)
        self.confound_norm2 = LayerNorm(embed_dim)
        self.confound_dropout2 = nn.Dropout(dropout)

        # 3. Gating
        self.gate_layer = nn.Sequential(
            nn.Linear(embed_dim * 2, embed_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim, 1),
            nn.Sigmoid()
        )

        self.out_proj = nn.Linear(embed_dim, embed_dim)
        self.out_dropout = nn.Dropout(dropout)
        self.final_norm = LayerNorm(embed_dim)

    def forward(self, x, k=None, fl=None, mode='y', proj=False, epoch=None):
        if mode != 'y' or k is None:
            return x

        # Step 1: Evidence Injection (Add K)
        q_evidence = self.evidence_norm1(x)

        # 【关键确认】不要解包！MultiHeadedAttention 只返回一个 tensor
        evidence = self.evidence_attn(q_evidence, k, k)

        x_enriched = x + self.evidence_dropout1(evidence)
        x_enriched_norm = self.evidence_norm2(x_enriched)
        x_enriched = x_enriched + self.evidence_dropout2(self.evidence_ffn(x_enriched_norm))

        # Step 2: Blind Confounder Discovery
        x_blind = x.mean(dim=1, keepdim=True).expand_as(x)
        q_confound = self.confound_norm1(x_blind)

        # 【关键确认】不要解包！
        confounder = self.confound_attn(q_confound, k, k)

        c_hidden = self.confound_dropout1(confounder)
        c_norm = self.confound_norm2(c_hidden)
        c_final = c_hidden + self.confound_dropout2(self.confound_ffn(c_norm))

        # Step 3: Gated Intervention with Warmup
        gate_input = torch.cat([x_enriched, c_final], dim=-1)
        gate = self.gate_layer(gate_input)

        alpha = 1.0
        if epoch is not None and self.warmup_epochs > 0:
            alpha = min(1.0, float(epoch) / float(self.warmup_epochs))

        effective_gate = gate * alpha
        x_intervened = x_enriched - effective_gate * c_final

        out = self.out_proj(x_intervened)
        out = self.out_dropout(out)
        out = self.final_norm(x_enriched + out)

        return out