import pandas as pd
from .BaseTrainer import BaseTrainer
import numpy as np
import torch
import time
from utils.loss import patchify
import os
from tqdm import tqdm

# [WANDB] optional import
try:
    import wandb

    _WANDB_AVAILABLE = True
except Exception:
    wandb = None
    _WANDB_AVAILABLE = False


class Trainer(BaseTrainer):
    def __init__(self, model, criterion, metric_ftns, optimizer, args, lr_scheduler, train_dataloader, val_dataloader,
                 test_dataloader):
        super(Trainer, self).__init__(model, criterion, metric_ftns, optimizer, args)
        self.lr_scheduler = lr_scheduler
        self.train_dataloader = train_dataloader
        self.val_dataloader = val_dataloader
        self.test_dataloader = test_dataloader
        self.best_score = 0.

        # Load pretrained model if specified (usually for initialization)
        if args.get("load_model_path", ""):
            print(f"Loading pretrained model from {args['load_model_path']}")
            try:
                state = torch.load(args["load_model_path"], map_location='cuda')
                if 'state_dict' in state:
                    self.model.load_state_dict(state['state_dict'], strict=False)
                else:
                    self.model.load_state_dict(state, strict=False)
            except Exception as e:
                print(f"Warning: Failed to load pretrained model: {e}")

    def _train_epoch(self, epoch):
        # ---------------------------------------------------------
        # 1. Training Phase
        # ---------------------------------------------------------
        train_loss = 0
        self.model.train()

        # Training Progress Bar
        pbar = tqdm(enumerate(self.train_dataloader), total=len(self.train_dataloader), desc=f"Epoch {epoch} Training")

        for batch_idx, (images_id, images, reports_ids, reports_masks) in pbar:
            images, reports_ids, reports_masks = images.cuda(), reports_ids.cuda(), reports_masks.cuda()

            self.optimizer.zero_grad()

            # Forward (pass epoch for Warmup)
            output = self.model(images, reports_ids, mode='train', epoch=epoch)

            # Calculate Loss
            loss = self.criterion(output, reports_ids, reports_masks)
            loss.backward()

            # Clip Gradients
            torch.nn.utils.clip_grad_value_(self.model.parameters(), 0.1)
            self.optimizer.step()

            train_loss += loss.item()
            pbar.set_postfix({'loss': loss.item()})

        log = {'train_loss': train_loss / len(self.train_dataloader)}

        # ---------------------------------------------------------
        # 2. Validation Phase (【核心修复】新增验证逻辑)
        # ---------------------------------------------------------
        self.model.eval()
        with torch.no_grad():
            val_gts, val_res = [], []
            val_pbar = tqdm(enumerate(self.val_dataloader), total=len(self.val_dataloader),
                            desc=f"Epoch {epoch} Validation")

            for batch_idx, (images_id, images, reports_ids, reports_masks) in val_pbar:
                images = images.cuda()
                reports_ids = reports_ids.cuda()

                # Beam Search Inference
                # 注意：VLCI 的 mode='sample' 会调用 sample_forward
                output = self.model(images, mode='sample')

                # Decode Token IDs to Text
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())

                val_res.extend(reports)
                val_gts.extend(ground_truths)

            # Compute Metrics (BLEU, METEOR, ROUGE, CIDEr)
            val_met = self.metric_ftns({i: [gt] for i, gt in enumerate(val_gts)},
                                       {i: [re] for i, re in enumerate(val_res)})

            # Update log with val metrics (e.g., val_BLEU_4)
            # 这一步至关重要，它生成了 BaseTrainer 需要的 Key
            log.update(**{'val_' + k: v for k, v in val_met.items()})

        # ---------------------------------------------------------
        # 3. Scheduler Step
        # ---------------------------------------------------------
        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

        return log