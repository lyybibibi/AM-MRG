import os
from abc import abstractmethod
import time

import numpy as np
import torch
import pandas as pd
from numpy import inf
from utils.monitor import Monitor

# [WANDB] optional import
try:
    import wandb
    _WANDB_AVAILABLE = True
except Exception:
    wandb = None
    _WANDB_AVAILABLE = False


def _format_time(sec: float) -> str:
    sec = int(sec)
    h = sec // 3600
    m = (sec % 3600) // 60
    s = sec % 60
    if h > 0:
        return f"{h:02d}:{m:02d}:{s:02d}"
    return f"{m:02d}:{s:02d}"


class BaseTrainer(object):
    def __init__(self, model, criterion, metric_ftns, optimizer, args, monitor=True):
        self.args = args

        # setup GPU device if available, move model into configured device
        self.model = model
        # self.model = torch.nn.DataParallel(model)

        self.criterion = criterion
        self.metric_ftns = metric_ftns
        self.optimizer = optimizer

        self.epochs = self.args["epochs"]
        self.save_period = self.args["save_period"]

        self.mnt_mode = args["monitor_mode"]
        self.mnt_metric = 'val_' + args["monitor_metric"]
        self.mnt_metric_test = 'test_' + args["monitor_metric"]
        assert self.mnt_mode in ['min', 'max']

        self.mnt_best = inf if self.mnt_mode == 'min' else -inf
        # self.early_stop = getattr(self.args, 'early_stop', inf)
        self.early_stop = self.args["early_stop"]

        self.start_epoch = 1
        self.checkpoint_dir = args["result_dir"]

        if not os.path.exists(self.checkpoint_dir):
            os.makedirs(self.checkpoint_dir)

        if args["resume"] != "":
            self._resume_checkpoint(args["resume"])

        self.best_recorder = {'val': {self.mnt_metric: self.mnt_best},
                              'test': {self.mnt_metric_test: self.mnt_best}}

        # monitor
        if monitor:
            self.monitor = Monitor(args)

        # [WANDB] init (do not break if wandb missing)
        self.use_wandb = bool(self.args.get("use_wandb", False))
        self.wandb_project = self.args.get("wandb_project", "CMCRL")
        self.wandb_entity = self.args.get("wandb_entity", None)
        self.wandb_run_name = self.args.get("wandb_run_name", None)
        self.wandb_tags = self.args.get("wandb_tags", [])
        self.wandb_group = self.args.get("wandb_group", None)
        self.wandb_mode = self.args.get("wandb_mode", "online")  # online/offline/disabled

        self._wandb_inited = False
        if self.use_wandb:
            if not _WANDB_AVAILABLE:
                print("[WANDB] wandb is not available. Please `pip install wandb` or set use_wandb=False.")
                self.use_wandb = False
            else:
                # If user sets mode=disabled, wandb won't log.
                try:
                    wandb.init(
                        project=self.wandb_project,
                        entity=self.wandb_entity,
                        name=self.wandb_run_name,
                        tags=self.wandb_tags,
                        group=self.wandb_group,
                        config=self.args,
                        mode=self.wandb_mode
                    )
                    self._wandb_inited = True
                    # optionally watch model gradients/params (can be heavy)
                    if bool(self.args.get("wandb_watch", False)):
                        wandb.watch(self.model, log="all", log_freq=int(self.args.get("wandb_watch_freq", 100)))
                except Exception as e:
                    print(f"[WANDB] init failed: {e}")
                    self.use_wandb = False
                    self._wandb_inited = False

    @abstractmethod
    def _train_epoch(self, epoch):
        raise NotImplementedError

    def train(self):
        not_improved_count = 0

        # [TIME] overall timer
        train_start_time = time.perf_counter()

        for epoch in range(self.start_epoch, self.epochs + 1):
            # [TIME] epoch timer
            epoch_start_time = time.perf_counter()

            result = self._train_epoch(epoch)

            # [TIME] epoch end
            epoch_time = time.perf_counter() - epoch_start_time

            if result is None:
                # [WANDB]
                if self.use_wandb and self._wandb_inited:
                    wandb.log({
                        "epoch": epoch,
                        "time/epoch_seconds": epoch_time,
                        "time/epoch": _format_time(epoch_time),
                    }, step=epoch)
                self._save_checkpoint(epoch)
                continue

            # save logged informations into log dict
            log = {'epoch': epoch}
            log.update(result)

            # [TIME] attach epoch time into log
            log.update({
                "time/epoch_seconds": epoch_time,
                "time/epoch": _format_time(epoch_time),
            })

            self._record_best(log)

            # print logged informations to the screen
            for key, value in log.items():
                print('\t{:15s}: {}'.format(str(key), value))

            # [WANDB] log epoch-level metrics
            if self.use_wandb and self._wandb_inited:
                # flatten and log
                wandb_payload = {}
                for k, v in log.items():
                    # wandb handles int/float/str; keep strings too (time/epoch)
                    wandb_payload[k] = v
                wandb.log(wandb_payload, step=epoch)

            # evaluate model performance according to configured metric, save best checkpoint as model_best
            best = False
            if self.mnt_mode != 'off':
                try:
                    improved = (self.mnt_mode == 'min' and log[self.mnt_metric] <= self.mnt_best) or \
                               (self.mnt_mode == 'max' and log[self.mnt_metric] >= self.mnt_best)
                except KeyError:
                    print("Warning: Metric '{}' is not found. " "Model performance monitoring is disabled.".format(
                        self.mnt_metric))
                    self.mnt_mode = 'off'
                    improved = False

                if improved:
                    self.mnt_best = log[self.mnt_metric]
                    not_improved_count = 0
                    best = True
                else:
                    not_improved_count += 1

                if not_improved_count > self.early_stop:
                    print("Validation performance didn\'t improve for {} epochs. " "Training stops.".format(
                        self.early_stop))
                    break

            if epoch % self.save_period == 0:
                self._save_checkpoint(epoch, save_best=best)

        # [TIME] training done
        total_train_time = time.perf_counter() - train_start_time
        print(f"[TIME] Total training time: {_format_time(total_train_time)} ({total_train_time:.2f}s)")

        # [WANDB] summary
        if self.use_wandb and self._wandb_inited:
            try:
                wandb.summary["time/total_train_seconds"] = total_train_time
                wandb.summary["time/total_train"] = _format_time(total_train_time)
            except Exception:
                pass

        self._print_best()
        self._print_best_to_file()

        # [WANDB] finish
        if self.use_wandb and self._wandb_inited:
            try:
                wandb.finish()
            except Exception:
                pass

    def _print_best_to_file(self):
        crt_time = time.asctime(time.localtime(time.time()))
        self.best_recorder['val']['time'] = crt_time
        self.best_recorder['test']['time'] = crt_time
        self.best_recorder['val']['seed'] = self.args["seed"]
        self.best_recorder['test']['seed'] = self.args["seed"]
        self.best_recorder['val']['best_model_from'] = 'val'
        self.best_recorder['test']['best_model_from'] = 'test'

        if not os.path.exists(self.args["record_dir"]):
            os.makedirs(self.args["record_dir"])
        record_path = os.path.join(self.args["record_dir"], self.args["dataset_name"] + '.csv')
        if not os.path.exists(record_path):
            record_table = pd.DataFrame()
        else:
            record_table = pd.read_csv(record_path)
        record_table = record_table.append(self.best_recorder['val'], ignore_index=True)
        record_table = record_table.append(self.best_recorder['test'], ignore_index=True)
        record_table.to_csv(record_path, index=False)

    def _save_checkpoint(self, epoch, save_best=False):
        state = {
            'epoch': epoch,
            'state_dict': self.model.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'monitor_best': self.mnt_best,
            'seed': self.args['seed']
        }
        filename = os.path.join(self.checkpoint_dir, 'current_checkpoint.pth')
        torch.save(state, filename)
        print("Saving checkpoint: {} ...".format(filename))
        if save_best:
            best_path = os.path.join(self.checkpoint_dir, 'model_best.pth')
            torch.save(state, best_path)
            print("*************** Saving current best: model_best.pth ... ***************")

    def _resume_checkpoint(self, resume_path):
        resume_path = str(resume_path)
        print("Loading checkpoint: {} ...".format(resume_path))
        checkpoint = torch.load(resume_path)
        self.start_epoch = checkpoint['epoch'] + 1
        self.mnt_best = checkpoint['monitor_best']
        self.model.load_state_dict(checkpoint['state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])

        print("Checkpoint loaded. Resume training from epoch {}".format(self.start_epoch))

    def _record_best(self, log):
        improved_val = (self.mnt_mode == 'min' and log[self.mnt_metric] <= self.best_recorder['val'][
            self.mnt_metric]) or \
                       (self.mnt_mode == 'max' and log[self.mnt_metric] >= self.best_recorder['val'][self.mnt_metric])
        if improved_val:
            self.best_recorder['val'].update(log)

        improved_test = (self.mnt_mode == 'min' and log[self.mnt_metric_test] <= self.best_recorder['test'][
            self.mnt_metric_test]) or \
                        (self.mnt_mode == 'max' and log[self.mnt_metric_test] >= self.best_recorder['test'][
                            self.mnt_metric_test])
        if improved_test:
            self.best_recorder['test'].update(log)

    def _print_best(self):
        print('Best results (w.r.t {}) in validation set:'.format(self.args["monitor_metric"]))
        for key, value in self.best_recorder['val'].items():
            print('\t{:15s}: {}'.format(str(key), value))

        print('Best results (w.r.t {}) in test set:'.format(self.args["monitor_metric"]))
        for key, value in self.best_recorder['test'].items():
            print('\t{:15s}: {}'.format(str(key), value))


class Trainer(BaseTrainer):
    def __init__(self, model, criterion, metric_ftns, optimizer, args, lr_scheduler, train_dataloader, val_dataloader,
                 test_dataloader):
        super(Trainer, self).__init__(model, criterion, metric_ftns, optimizer, args)
        self.lr_scheduler = lr_scheduler
        self.train_dataloader = train_dataloader
        self.val_dataloader = val_dataloader
        self.test_dataloader = test_dataloader

        # [TIME] iter timing buffer for smooth avg
        self._iter_time_window = int(self.args.get("iter_time_window", 50))
        self._iter_times = []
        self._log_iter_interval = int(self.args.get("log_iter_interval", 50))

    def inference(self):
        # [TIME] inference timer
        infer_start_time = time.perf_counter()

        state = torch.load(self.args["load_model_path"], map_location='cuda')
        pretrained_dict = state['state_dict']
        self.model.load_state_dict(pretrained_dict, False)

        log = {'task_name': self.args['task_name']}
        self.model.eval()

        # ------------------- VAL -------------------
        val_start_time = time.perf_counter()
        with torch.no_grad():
            val_gts, val_res = [], []
            p = torch.zeros([1, self.args["max_seq_length"]]).cuda()
            for batch_idx, (images_id, images, reports_ids, reports_masks) in enumerate(self.val_dataloader):
                iter_t0 = time.perf_counter()
                images, reports_ids, reports_masks = images.cuda(), reports_ids.cuda(), reports_masks.cuda()
                output = self.model(images, mode='sample')
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())
                val_res.extend(reports)
                val_gts.extend(ground_truths)
                p = torch.cat([p, output])

                iter_cost = time.perf_counter() - iter_t0
                if self.use_wandb and self._wandb_inited:
                    wandb.log({"time/val_iter_seconds": iter_cost}, step=batch_idx)

                print(f"\rVal Processing: [{int((batch_idx + 1) / len(self.val_dataloader) * 100)}%]", end='',
                      flush=True)
            val_met = self.metric_ftns({i: [gt] for i, gt in enumerate(val_gts)},
                                       {i: [re] for i, re in enumerate(val_res)})
            # record val metrics
            log.update(**{'val_' + k: v for k, v in val_met.items()})

        val_time = time.perf_counter() - val_start_time
        log["time/val_seconds"] = val_time
        log["time/val"] = _format_time(val_time)

        # [WANDB] log val metrics
        if self.use_wandb and self._wandb_inited:
            wandb.log({**{'val_' + k: v for k, v in val_met.items()},
                       "time/val_seconds": val_time,
                       "time/val": _format_time(val_time)}, step=0)

        # ------------------- TEST -------------------
        test_start_time = time.perf_counter()
        self.model.eval()
        with torch.no_grad():
            test_gts, test_res, p = [], [], []
            p = torch.zeros([1, self.args["max_seq_length"]]).cuda()
            for batch_idx, (images_id, images, reports_ids, reports_masks) in enumerate(self.test_dataloader):
                iter_t0 = time.perf_counter()
                images, reports_ids, reports_masks = images.cuda(), reports_ids.cuda(), reports_masks.cuda()
                output = self.model(images, mode='sample')
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())
                test_res.extend(reports)
                test_gts.extend(ground_truths)
                p = torch.cat([p, output])

                iter_cost = time.perf_counter() - iter_t0
                if self.use_wandb and self._wandb_inited:
                    wandb.log({"time/test_iter_seconds": iter_cost}, step=batch_idx)

                print(f"\rTest Processing: [{int((batch_idx + 1) / len(self.test_dataloader) * 100)}%]", end='',
                      flush=True)
            test_met = self.metric_ftns({i: [gt] for i, gt in enumerate(test_gts)},
                                        {i: [re] for i, re in enumerate(test_res)})

            log.update(**{'test_' + k: v for k, v in test_met.items()})

        test_time = time.perf_counter() - test_start_time
        log["time/test_seconds"] = test_time
        log["time/test"] = _format_time(test_time)

        total_infer_time = time.perf_counter() - infer_start_time
        log["time/inference_total_seconds"] = total_infer_time
        log["time/inference_total"] = _format_time(total_infer_time)

        # [WANDB] log test metrics
        if self.use_wandb and self._wandb_inited:
            wandb.log({**{'test_' + k: v for k, v in test_met.items()},
                       "time/test_seconds": test_time,
                       "time/test": _format_time(test_time),
                       "time/inference_total_seconds": total_infer_time,
                       "time/inference_total": _format_time(total_infer_time)}, step=0)

        record_path = os.path.join(self.args["record_dir"], self.args["dataset_name"] + '.csv')
        record_table = pd.DataFrame()
        record_table = record_table.append(log, ignore_index=True)
        record_table.to_csv(record_path, index=False)
        print(log)
        return log
