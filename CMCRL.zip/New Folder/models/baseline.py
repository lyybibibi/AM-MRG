import torch
import torch.nn as nn
import torch.nn.functional as F
from modules.modules4vlp import VisEmbed, TextEmbed, get_ht_mask, get_hv_mask
from modules.modules4transformer import Decoder, Encoder
from modules.beam_search import BeamSearch


class Baseline(nn.Module):
    def __init__(self, args, tokenizer):
        super(Baseline, self).__init__()
        self.args = args
        self.vocab_size = len(tokenizer.idx2token)
        self.tokenizer = tokenizer

        self.en_num_layers = args["en_num_layers"]
        self.de_num_layers = args["de_num_layers"]
        self.embed_dim = args["embed_dim"]
        self.num_heads = args["num_heads"]
        self.ff_dim = args["embed_dim"] * 4
        self.dropout = args["dropout"]

        # Embedding
        self.vis_embed = VisEmbed(embed_dim=self.embed_dim, dropout=self.dropout)
        self.text_embed = TextEmbed(embed_dim=self.embed_dim, vocab_size=self.vocab_size + 1, dropout=self.dropout)

        # Encoder
        self.encoder = Encoder(embed_dim=self.embed_dim, num_layer=self.en_num_layers, num_heads=self.num_heads,
                               ff_dim=self.ff_dim, dropout=self.dropout)

        # Decoder (Baseline default)
        self.decoder = Decoder(embed_dim=self.embed_dim, num_layer=self.de_num_layers, num_heads=self.num_heads,
                               ff_dim=self.ff_dim, dropout=self.dropout)

        self.cls_token = nn.Parameter(torch.zeros(1, 1, self.embed_dim))
        self.logit = nn.Linear(self.embed_dim, self.vocab_size + 1)
        self.beam_search = BeamSearch(args, self.vocab_size + 1)

    # 【关键修改】增加 **kwargs 以接收 epoch 和其他参数
    def forward(self, images, targets=None, mode='train', **kwargs):
        # Generic forward (IU X-Ray etc)
        hv = self.vis_embed(images)
        # 将 kwargs (包含 epoch) 传递给 _forward
        outputs = self._forward(hv, targets, mode, images.size(0), **kwargs)
        return outputs

    def forward_mimic_cxr(self, images, targets=None, mode='train', **kwargs):
        hv = self.vis_embed(images)
        outputs = self._forward(hv, targets, mode, images.size(0), **kwargs)
        return outputs

    # 【关键修改】增加 **kwargs
    def _forward(self, hv, targets, mode, B, **kwargs):
        # append cls token
        hv = hv.reshape([B, -1, self.embed_dim])
        cls_token = self.cls_token + self.vis_embed.pos_embed[:, :1, :]
        cls_tokens = cls_token.expand(hv.shape[0], -1, -1)
        hv = torch.cat((cls_tokens, hv), dim=1)

        # encode
        hv_mask = get_hv_mask(hv)
        hv = self.encoder(hv, hv_mask)

        # decode
        if mode == 'train':
            ht_mask, targets = get_ht_mask(targets)
            ht = self.text_embed(targets)  # [B, L] -> [B, L, D]

            # Baseline Decoder 可能不需要 epoch，但这里接住了防止报错
            out = self.decoder(ht, hv, self_mask=ht_mask, cross_mask=hv_mask)

            outputs = [F.log_softmax(self.logit(out), dim=-1)]
        elif mode == 'sample':
            self.beam_search.load_model(self.sample_forward, self.logit)
            outputs, _ = self.beam_search.sample_beam(hv, hv_mask)
            self.beam_search.clean_model()

        return outputs

    def sample_forward(self, hv, ht, hv_mask, ht_mask):
        ht = self.text_embed(ht)
        out = self.decoder(ht, hv, self_mask=ht_mask, cross_mask=hv_mask)
        return out