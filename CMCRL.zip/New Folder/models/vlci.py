import torch
import torch.nn as nn
import torch.nn.functional as F
from modules.modules4vlp import get_ht_mask, get_hv_mask, get_cross_mask
from modules.modules4transformer import LayerNorm, Encoder, DecoderLayer, EncoderLayer
from models.baseline import Baseline
from utils import tensor_utils
from modules.modules4vlci import LDM, EvidenceIntervention, LocalSample, GlobalSample, VDM


# =============================================================================
# 1. CausalEncoder
# =============================================================================
class CausalEncoder(nn.Module):
    def __init__(self, embed_dim, num_layer, num_heads, ff_dim, dropout, mode='none'):
        super(CausalEncoder, self).__init__()
        self.mode = mode
        self.layers = nn.ModuleList(
            [EncoderLayer(embed_dim, num_heads, ff_dim, dropout) for _ in range(num_layer)])

        self.local_sample = LocalSample(embed_dim, num_heads, ff_dim, dropout)
        self.global_sample = GlobalSample(embed_dim, num_heads, ff_dim, dropout)
        self.do = VDM(embed_dim, num_heads, ff_dim, dropout)
        self.norm = LayerNorm(embed_dim)

    def forward(self, h, mask=None, proj=False):
        attn_list = []
        for layer in self.layers:
            h, attn = layer(h, mask, return_attn=True)
            attn_list.append(attn)

        fl = self.local_sample(h, attn_list, 6)
        fg = self.global_sample(h)

        mediator = {"local": fl, "global": fg}

        h = self.do(h, fl=fl, fg=fg, mode=self.mode, proj=proj)
        h = self.norm(h)

        return h, mediator


# =============================================================================
# 2. RADARRetriever
# =============================================================================
class RADARRetriever(nn.Module):
    def __init__(self, embed_dim, memory_size=1000, num_classes=14):
        super(RADARRetriever, self).__init__()
        self.observation_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Linear(embed_dim // 2, num_classes)
        )
        self.register_buffer('memory_logits', torch.randn(memory_size, num_classes))
        self.register_buffer('memory_knowledge', torch.randn(memory_size, 3, embed_dim))
        self.proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, visual_cls):
        B = visual_cls.size(0)
        curr_logits = self.observation_head(visual_cls)
        curr_probs = torch.sigmoid(curr_logits)

        curr_norm = F.normalize(curr_probs, p=2, dim=1)
        mem_norm = F.normalize(torch.sigmoid(self.memory_logits), p=2, dim=1)

        scores = torch.mm(curr_norm, mem_norm.t())
        _, topk_indices = torch.topk(scores, k=3, dim=1)

        k_emb = self.memory_knowledge[topk_indices]
        k_emb = k_emb.view(B, -1, k_emb.size(-1))

        return self.proj(k_emb)


# =============================================================================
# 3. CausalDecoder
# =============================================================================
class CausalDecoder(nn.Module):
    def __init__(self, embed_dim, num_layer, num_heads, ff_dim, dropout, mode='none', stitch=None):
        super(CausalDecoder, self).__init__()
        self.mode = mode
        self.norm = LayerNorm(embed_dim)

        self.do = LDM(embed_dim)
        self.ei = EvidenceIntervention(embed_dim, num_heads, ff_dim, dropout, warmup_epochs=5)

        self.layers = nn.ModuleList(
            [DecoderLayer(embed_dim, num_heads, ff_dim, dropout) for _ in range(num_layer)])
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)

    def forward(self, output, h, self_mask=None, cross_mask=None, z=None, fl=None, k=None, proj=False, epoch=None):
        # 1. Standard Decoding
        for layer in self.layers:
            output = layer(output, h, self_mask, cross_mask)

        # 2. Evidence Intervention (Add Knowledge)
        output = self.ei(output, k=k, fl=fl, mode=self.mode, proj=proj, epoch=epoch)

        # 3. Linguistic Deconfounding (Subtract Bias)
        output = self.do(output, z, fl, self.mode, proj=proj)

        output = self.norm(output)
        return output


# =============================================================================
# 4. VLCI Main Class
# =============================================================================
class VLCI(Baseline):
    def __init__(self, args, tokenizer):
        super(VLCI, self).__init__(args, tokenizer)
        self.retriever = RADARRetriever(self.embed_dim)

        self.encoder = CausalEncoder(embed_dim=self.embed_dim, num_layer=self.en_num_layers, num_heads=self.num_heads,
                                     ff_dim=self.ff_dim, dropout=self.dropout, mode=args["v_causal"])

        self.decoder = CausalDecoder(embed_dim=self.embed_dim, num_layer=self.de_num_layers,
                                     num_heads=self.num_heads, ff_dim=self.ff_dim,
                                     dropout=self.dropout, mode=args["l_causal"])

        self.register_buffer('vocab_indices', torch.arange(self.vocab_size + 1))

    def _forward(self, hv, targets, mode, B, epoch=None, **kwargs):
        # 1. Vision Encode
        hv = hv.reshape([B, -1, self.embed_dim])
        cls_token = self.cls_token + self.vis_embed.pos_embed[:, :1, :]
        cls_tokens = cls_token.expand(hv.shape[0], -1, -1)
        hv = torch.cat((cls_tokens, hv), dim=1)

        hv_mask = get_hv_mask(hv)
        hv, mediator = self.encoder(hv, hv_mask)

        # 2. Knowledge Retrieval
        k = None
        if hasattr(self, 'retriever'):
            k = self.retriever(hv[:, 0, :])

        # 3. Compute Z (Vocab Features)
        self.z = self.text_embed.embed(self.vocab_indices.unsqueeze(0))

        if mode == 'train':
            # Train mode: Batch Size is consistent
            z_expanded = self.z.expand(B, -1, -1)
            ht_mask, targets = get_ht_mask(targets)
            ht = self.text_embed(targets)

            out = self.decoder(ht, hv, self_mask=ht_mask, cross_mask=hv_mask,
                               z=z_expanded, fl=mediator.get('local', None), k=k, epoch=epoch)

            outputs = [F.log_softmax(self.logit(out), dim=-1)]
            return outputs

        elif mode == 'sample':
            # Sample mode (Beam Search): Batch Size expands dynamically
            self.beam_search.load_model(lambda *args: self.sample_forward(*args, k=k, fl=mediator.get('local', None)),
                                        self.logit)
            outputs, _ = self.beam_search.sample_beam(hv, hv_mask)
            self.beam_search.clean_model()
            return outputs

    def sample_forward(self, hv, ht, hv_mask, ht_mask, k=None, fl=None):
        """
        Robust sample_forward handles expansion of all tensors during Beam Search.
        """
        ht = self.text_embed(ht)

        # ht.size(0) reflects the current effective batch size (Original Batch * Beam Size)
        current_bs = ht.size(0)

        # 1. Expand HV (Image Features)
        if hv.size(0) != current_bs:
            beam_size = current_bs // hv.size(0)
            hv = tensor_utils.tile(hv, beam_size, 0)

        # 2. Expand HV_MASK (Cross Attention Mask) - CRITICAL FIX
        if hv_mask.size(0) != current_bs:
            beam_size = current_bs // hv_mask.size(0)
            hv_mask = tensor_utils.tile(hv_mask, beam_size, 0)

        # 3. Expand K (Knowledge)
        if k is not None and k.size(0) != current_bs:
            beam_size = current_bs // k.size(0)
            k = tensor_utils.tile(k, beam_size, 0)

        # 4. Expand FL (Local Features)
        if fl is not None and fl.size(0) != current_bs:
            beam_size = current_bs // fl.size(0)
            fl = tensor_utils.tile(fl, beam_size, 0)

        # 5. Expand Z (Vocab Features)
        if not hasattr(self, 'z'):
            self.z = self.text_embed.embed(self.vocab_indices.unsqueeze(0))
        z_expanded = self.z.expand(current_bs, -1, -1)

        out = self.decoder(ht, hv, self_mask=ht_mask, cross_mask=hv_mask, fl=fl, k=k, z=z_expanded, epoch=None)
        return out